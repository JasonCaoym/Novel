package com.zydm.statistics.motong

import com.zydm.base.data.base.MtMap

object MtStHelper {

    fun visit(): Boolean {
        MtStEventMgr.getInstance().onEvent(MtStConst.EVENT_VISIT, 0.0, null, true)
        return true
    }

    fun readBookChaper(bookId: String, chapterId: String, seqNum: Int) {
        val params = MtMap<String, String>()
        params[MtStConst.KEY_BOOK_ID] = bookId
        params[MtStConst.KEY_CHAPTER_ID] = chapterId
        params[MtStConst.KEY_SEQ_NUM] = seqNum.toString()
        MtStEventMgr.getInstance().onEvent(MtStConst.EVENT_READ_BOOKS, 0.0, params, false)
    }

    fun bookDetails(bookId: String, source: String) {
        val params = MtMap<String, String>()
        params[MtStConst.KEY_BOOK_ID] = bookId
        params[MtStConst.KEY_SOURCE] = source
        MtStEventMgr.getInstance().onEvent(MtStConst.EVENT_BOOK_DETAIL, 0.0, params, false)
    }
}
