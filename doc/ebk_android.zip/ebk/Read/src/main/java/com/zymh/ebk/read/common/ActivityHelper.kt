package com.zymh.ebk.read.common

import android.app.Activity
import android.content.Intent
import com.alibaba.android.arouter.launcher.ARouter
import com.zydm.base.R
import com.zydm.base.common.ParamKey
import com.zydm.base.ui.BaseActivityHelper
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.ui.activity.web.WebActivity
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.provider.router.RouterPath
import com.zymh.ebk.read.ui.read.ReadActivity
import com.zymh.ebk.read.dao.BookShelfBean
import com.zymh.ebk.read.data.bean.BookDetailBean
import com.zymh.ebk.read.ui.bookshelf.EditShelfActivity
import com.zymh.ebk.read.ui.catalogue.CatalogueActivity
import com.zymh.ebk.read.ui.detail.BookDetailsActivity

object ActivityHelper {

    fun gotoRead(activity: Activity, bookId: String, seqNum: Int, data: BaseData) {
        val intent = Intent(activity, ReadActivity::class.java)
        intent.putExtra(ParamKey.BOOK_ID, bookId)
        intent.putExtra(ParamKey.SEQ_NUM, seqNum)
        intent.putExtra(BaseActivity.DATA_KEY, data)
        startActivity(activity, intent)
    }

    fun gotoRead(activity: Activity, bookId: String, data: BaseData) {
        val intent = Intent(activity, ReadActivity::class.java)
        intent.putExtra(ParamKey.BOOK_ID, bookId)
        intent.putExtra(BaseActivity.DATA_KEY, data)
        startActivity(activity, intent)
    }

    private fun startActivity(activity: Activity, intent: Intent) {
        activity.startActivity(intent)
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    fun gotoCatalogue(activity: Activity, bookDetailBean: BookDetailBean) {
        val intent = Intent(activity, CatalogueActivity::class.java)
        intent.putExtra(BaseActivity.DATA_KEY, bookDetailBean)
        activity.startActivity(intent)
    }

    fun gotoEditShelf(activity: Activity, list: ArrayList<BookShelfBean>) {
        val intent = Intent(activity, EditShelfActivity::class.java)
        intent.putExtra(BaseActivity.DATA_KEY, list)
        startActivity(activity, intent)
    }

    fun gotoSearch(data: BaseData) {
        ARouter.getInstance().build(RouterPath.Book.PATH_SEARCH)
                .withParcelable(BaseActivity.DATA_KEY, data)
                .navigation()
    }

    fun gotoBookDetails(activity: Activity, bookId: String, data: BaseData) {
        val intent = Intent(activity, BookDetailsActivity::class.java)
        intent.putExtra(ParamKey.BOOK_ID, bookId)
        intent.putExtra(BaseActivity.DATA_KEY, data)
        startActivity(activity, intent)
    }

    fun gotoHome(activity: Activity, data: BaseData) {
        ARouter.getInstance().build(RouterPath.App.PATH_HOME)
                .withParcelable(BaseActivity.DATA_KEY, data)
                .navigation()
    }

    fun gotoWeb(activity: Activity, url: String) {
        BaseActivityHelper.gotoWebActivity(activity, WebActivity.Data(url, ""))
    }
}
