package com.zymh.ebk.read.ui.history

import android.view.View
import com.zydm.base.ext.loadUrl
import com.zydm.base.ext.setHtmlText
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.read.R
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.utils.StringUtils
import kotlinx.android.synthetic.main.history_item_view.view.*

class HistoryItemView : AbsItemView<BookRecordBean>() {

    override fun onCreate() {
        setContentView(R.layout.history_item_view)
        mItemView.setOnClickListener(this)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.book_cover.loadUrl(mItemData.bookCover)
        mItemView.book_author.setHtmlText(mItemData.author)
        mItemView.book_name.setHtmlText(mItemData.bookName)
        mItemData.chapterTitle = StringUtils.convertChapterTitle(mItemData.chapterTitle, mItemData.seqNum)
        mItemView.last_read.setHtmlText(mItemData.chapterTitle)
    }

    override fun onClick(view: View) {
        super.onClick(view)
        ActivityHelper.gotoRead(mActivity, mItemData.bookId, BaseData("阅读记录"))
        StatisHelper.onEvent().historyClick(mItemData.bookName);
    }
}
