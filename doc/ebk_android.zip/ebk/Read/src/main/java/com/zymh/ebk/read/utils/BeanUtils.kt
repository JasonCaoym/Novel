package com.zymh.ebk.read.utils

import com.zymh.ebk.read.dao.BookShelfBean

object BeanUtils {

 /*   fun convertShelfBeanList2BookBeanList(shelfBookList: List<BookShelfBean>): ArrayList<BookItemBean> {
        val list = ArrayList<BookItemBean>()
        for (bookShelfBean in shelfBookList) {
            val bookItemBean = convertShelfBean2BookBean2(bookShelfBean)
            list.add(bookItemBean)
        }
        return list
    }

    fun convertShelfBean2BookBean2(bookShelfBean: BookShelfBean): BookItemBean {
        val bookItemBean = BookItemBean()
        bookItemBean.bookId = bookShelfBean.bookId
        bookItemBean.bookName = bookShelfBean.bookName
        bookItemBean.bookCover = bookShelfBean.bookCover
        bookItemBean.resume = bookShelfBean.resume
        bookItemBean.chapterCount = bookShelfBean.chapterCount
        bookItemBean.isFinish = bookShelfBean.isFinish
        bookItemBean.updateTime = bookShelfBean.updateTime
        bookItemBean.currTime = bookShelfBean.currTime
        bookItemBean.author = bookShelfBean.author
        return bookItemBean
    }

    fun convertBookBeanList2ShelfBeanList(bookList: List<BookItemBean>): ArrayList<BookShelfBean> {
        val list = ArrayList<BookShelfBean>()
        for (bookItemBean in bookList) {
            val bookShelfBean = convertBookBean2ShelfBean(bookItemBean)
            list.add(bookShelfBean)
        }
        return list
    }

    fun convertBookBean2ShelfBean(bookItemBean: BookItemBean): BookShelfBean {
        val bookShelfBean = BookShelfBean()
        bookShelfBean.bookId = bookItemBean.bookId
        bookShelfBean.bookName = bookItemBean.bookName
        bookShelfBean.bookCover = bookItemBean.bookCover
        bookShelfBean.resume = bookItemBean.resume
        bookShelfBean.chapterCount = bookItemBean.chapterCount
        bookShelfBean.isFinish = bookItemBean.isFinish
        bookShelfBean.updateTime = bookItemBean.updateTime
        bookShelfBean.currTime = bookItemBean.currTime
        bookShelfBean.author = bookItemBean.author
        return bookShelfBean
    }*/
}
