package com.zymh.ebk.read.presenter.view

import com.zydm.base.presenter.view.IPageView
import com.zymh.ebk.read.data.bean.BookDetailBean

interface IBookDetailPage : IPageView {

    fun showPage(pageData: BookDetailBean)
    fun setReadBtnNext()
    fun addShelfSuccess()
    fun refreshChapter(pageData: BookDetailBean)
}
