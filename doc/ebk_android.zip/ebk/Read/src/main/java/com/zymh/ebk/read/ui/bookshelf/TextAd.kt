package com.zymh.ebk.read.ui.bookshelf

import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ToastUtils
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.read.R
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.data.bean.TextAdItemBean
import com.zymh.ebk.read.data.bean.TextAdListBean
import kotlinx.android.synthetic.main.book_shelf_ad_layout.view.*

class TextAd : AbsItemView<TextAdListBean>() {

    var mPageName: String = ""

    override fun onCreate() {
        setContentView(R.layout.book_shelf_ad_layout)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        if (!isDataChanged) {
            return
        }

        val textList = ArrayList<String>()
        for (textAdItemBean in mItemData.list) {
            textList.add(textAdItemBean.subject)
        }
        mItemView.marquee_view.startWithList(textList)
        mItemView.marquee_view.setOnItemClickListener { position, _ ->
            val bean: TextAdItemBean = mItemData.list[position]
            when (bean.linkType) {
                TextAdItemBean.LINK_TYPE_BOOK -> ActivityHelper.gotoBookDetails(mActivity, bean.link, BaseData(mPageName))
                TextAdItemBean.LINK_TYPE_WEB -> ActivityHelper.gotoWeb(mActivity, bean.link)
                else -> ToastUtils.showLimited(R.string.not_supported)
            }
        }
    }
}