package com.zymh.ebk.read.setting;

public interface ISettingProvider {
    boolean isBrightFollowSystem();
}
