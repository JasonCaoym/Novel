package com.zymh.ebk.read.ui.bookshelf

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import com.zydm.base.ext.onClick
import com.zydm.base.rx.MtSchedulers
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.ui.item.ItemListenerAdapter
import com.zydm.base.utils.CollectionUtils
import com.zydm.base.utils.ToastUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.read.R
import com.zymh.ebk.read.dao.BookShelfBean
import com.zymh.ebk.read.dao.BookShelfHelper
import com.zymh.ebk.read.dao.ShelfBookListBean
import kotlinx.android.synthetic.main.activity_edit_shelf.*

class EditShelfActivity : BaseActivity() {

    private var mBookLists: ArrayList<ShelfBookListBean> = ArrayList()
    private var mBooks: ArrayList<BookShelfBean> = ArrayList()
    private var mSelectedBooks: ArrayList<BookShelfBean> = ArrayList()
    private var mCount: Int = 0
    private val mAdapter by lazy {
        AdapterBuilder().putItemClass(EditShelfBooksView::class.java, getItemListener()).builderListAdapter(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_shelf)
        initView()
        initData()
    }

    private fun initData() {
        mBooks = intent.getParcelableArrayListExtra<BookShelfBean>(DATA_KEY)
        updateData(mBooks)
    }

    private fun updateData(list: java.util.ArrayList<BookShelfBean>) {
        mCount = list.size
        mBookLists.clear()
        val shelfBookLists = CollectionUtils.split(list, 3)
        if (shelfBookLists != null && shelfBookLists.size != 0) {
            for (subList in shelfBookLists) {
                val shelfBookListBean = ShelfBookListBean()
                shelfBookListBean.list = subList
                mBookLists.add(shelfBookListBean)
            }
        }
        mAdapter.setData(mBookLists)
        setSelectedCount()
    }

    private fun initView() {
        list_view.adapter = mAdapter
        mAdapter.setData(mBookLists)
        select_all.onClick(this)
        finish.onClick(this)
        delete_btn.onClick(this)
    }

    private fun setSelectedCount() {
        select_count.text = ViewUtils.getString(R.string.select_count, mSelectedBooks.size)
    }

    private fun getItemListener(): ItemListenerAdapter<EditShelfBooksView> {
        return object : ItemListenerAdapter<EditShelfBooksView>() {
            override fun onClick(v: EditShelfBooksView, view: View) {
                val listBean = mBookLists[v.mPosition]
                val bean = listBean.list[view.tag as Int]
                bean.mIsSelect = !bean.mIsSelect
                if (bean.mIsSelect) {
                    mSelectedBooks.add(bean)
                } else {
                    mSelectedBooks.remove(bean)
                }
                setSelectedCount()
                mAdapter.notifyDataSetChanged()
            }
        }
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.select_all -> selectAll()
            R.id.delete_btn -> removeBooksFromShelf()
            R.id.finish -> finish()
        }
    }

    @SuppressLint("CheckResult")
    private fun removeBooksFromShelf() {
        if (mSelectedBooks.size == 0) {
            ToastUtils.showLimited(R.string.none_book_selected)
            return
        }
        finish.isClickable = false
        BookShelfHelper.getsInstance().removeBooksInRx(mSelectedBooks, true).subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe {
            ToastUtils.showLimited(it)
            removeFromList(mSelectedBooks)
            mSelectedBooks.clear()
            updateData(mBooks)
            finish.isClickable = true
            if (mBooks.size == 0) {
                finish()
            }
        }
    }

    private fun removeFromList(changeList: ArrayList<BookShelfBean>) {
        for (bookShelfBean in changeList) {
            var y: Int = 0
            for (i in mBooks.indices) {
                val bookItemBean = mBooks[i - y]
                if (bookItemBean.bookId == bookShelfBean.bookId) {
                    mBooks.removeAt(i - y)
                    y++
                }
            }
        }
    }

    private fun selectAll() {
        for (shelfBookListBean in mBookLists) {
            for (bookShelfBean in shelfBookListBean.list) {
                bookShelfBean.mIsSelect = true
            }
        }
        mSelectedBooks.clear()
        mSelectedBooks.addAll(mBooks)
        setSelectedCount()
        mAdapter.notifyDataSetChanged()
    }
}
