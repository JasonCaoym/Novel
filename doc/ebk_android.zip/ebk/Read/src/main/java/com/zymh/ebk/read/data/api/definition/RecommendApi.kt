package com.zymh.ebk.read.data.api.definition

import android.support.annotation.IntRange
import com.zydm.base.data.net.*
import com.zydm.base.common.ParamKey
import com.zymh.ebk.read.dao.BookRecordListBean
import com.zymh.ebk.read.data.bean.TextAdListBean

/**
 * Created by yan on 2017/3/17.
 */
@BasePath("/Api/Recommend/")
interface RecommendApi {

    companion object {
        const val REC_BOOK_TYPE_SHELF = 1

        const val REC_TEXT_TYPE_SHELF = 1
    }

    fun recBooks(@Param(ParamKey.COUNT) count: Int, @Param(ParamKey.TYPE) type: Int): DataSrcBuilder<BookRecordListBean>

    fun similarBooks(@Param(ParamKey.BOOK_ID) bookId: String): DataSrcBuilder<BookRecordListBean>

    fun recTexts(@IntRange(from = 1, to = 5) @Param(ParamKey.COUNT) count: Int,
                 @Param(ParamKey.TYPE) type: Int): DataSrcBuilder<TextAdListBean>

}
