package com.zymh.ebk.read.presenter.view;

import com.zymh.ebk.read.dao.ChapterListBean;

import java.util.List;

public interface IReadPage {

    void loadBookChaptersSuccess(List<ChapterListBean> chapterListBean);

    void preLoadBookChaptersSuccess(ChapterListBean chapterListBean, int groupPos);

    void loadChapterContentsSuccess();

    void loadChapterContentsFailed();

    void loadCatalogueSuccess(ChapterListBean chapterBean, int groupPos, int type);

    void loadCatalogueFailed(int groupPos, int type);
}
