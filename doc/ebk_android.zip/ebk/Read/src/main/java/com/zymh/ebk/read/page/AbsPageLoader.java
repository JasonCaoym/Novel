package com.zymh.ebk.read.page;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.text.TextPaint;
import android.util.Log;
import android.widget.FrameLayout;

import com.zydm.base.rx.RxUtils;
import com.zydm.base.utils.ToastUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.ebk.read.R;
import com.zymh.ebk.read.dao.ChapterBean;
import com.zymh.ebk.read.dao.BookRecordBean;
import com.zymh.ebk.read.page.animation.Layer;
import com.zymh.ebk.read.utils.BookRecordHelper;
import com.zymh.ebk.read.utils.ReadConstant;
import com.zymh.ebk.read.utils.IOUtils;
import com.zymh.ebk.read.setting.ReadSettingManager;
import com.zymh.ebk.read.utils.ScreenUtils;
import com.zymh.ebk.read.utils.StringUtils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;
import io.reactivex.ObservableSource;
import io.reactivex.ObservableTransformer;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

import static com.zydm.base.common.BaseApplication.*;


public abstract class AbsPageLoader {

    public static final int STATUS_LOADING = 1;
    public static final int STATUS_FINISH = 2;
    public static final int STATUS_ERROR = 3;
    public static final int STATUS_EMPTY = 4;
    public static final int STATUS_PARSE = 5;
    public static final int STATUS_PARSE_ERROR = 6;

    private static final int DEFAULT_MARGIN_HEIGHT = 28;
    private static final int DEFAULT_MARGIN_WIDTH = 12;

    private static final int DEFAULT_TIP_SIZE = 12;
    private static final int EXTRA_TITLE_SIZE = 4;
    private static final int TIP_COLOR_NIGHT = Color.parseColor("#88BFBFBF");

    protected List<List<TxtChapter>> mChapterList;
    protected BookRecordBean mRecordBook;
    protected OnPageChangeListener mPageChangeListener;

    private PageView mPageView;
    private TxtPage mCurPage;
    private WeakReference<List<TxtPage>> mWeakPrePageList;
    private List<TxtPage> mCurPageList;
    private List<TxtPage> mNextPageList;
    private Bitmap mNextBitmap;

    private Paint mBatteryPaint;
    private Paint mTipPaint;
    private Paint mTitlePaint;
    private Paint mBgPaint;
    private TextPaint mTextPaint;
    private ReadSettingManager mSettingManager;
    private TxtPage mLastPage;
    protected int mStatus = STATUS_LOADING;
    protected int mCurPos = 0;
    protected boolean isBookOpen = false;
    private Disposable mPreLoadDisposable;
    private int mLastPos = 0;
    private int mVisibleWidth;
    private int mVisibleHeight;
    private int mDisplayWidth;
    private int mDisplayHeight;
    private int mMarginWidth;
    private int mMarginHeight;
    private int mTextColor;
    private int mTitleSize;
    private int mTextSize;
    private int mTextInterval;
    private int mTitleInterval;
    private int mTextPara;
    private int mTitlePara;
    private int mBatteryLevel;
    private int mBgTheme;
    private int mPageBg;
    private boolean isNightMode;
    protected boolean mSupportPageBetweenChapters;
    protected boolean mSupportPageAfterLastChapter;
    protected int mCurGroupPos;
    protected int mLastGroupPos;
    private TxtPage mPreLoadedTxtPage;

    public AbsPageLoader(PageView pageView) {
        mPageView = pageView;
        initData();
        initPaint();
        initPageView();
    }

    public boolean isNightMode() {
        return isNightMode;
    }

    private void initData() {
        mSettingManager = ReadSettingManager.getInstance();
        mTextSize = mSettingManager.getTextSize();
        mTitleSize = mTextSize + ScreenUtils.spToPx(EXTRA_TITLE_SIZE);
        isNightMode = mSettingManager.isNightMode();
        mBgTheme = mSettingManager.getReadBgTheme();

        if (isNightMode) {
            setBgColor(ReadSettingManager.NIGHT_MODE);
        } else {
            setBgColor(mBgTheme);
        }
        mMarginWidth = ScreenUtils.dpToPx(DEFAULT_MARGIN_WIDTH);
        mMarginHeight = ScreenUtils.dpToPx(DEFAULT_MARGIN_HEIGHT);
        mTextInterval = (int) (mTextSize * 0.681818f + 1.454545f);

        mTitleInterval = (int) (mTitleSize * 0.681818f + 1.454545f);

        mTextPara = (int) (mTextSize * 1.272727f + 2.181818f);
        mTitlePara = (int) (mTitleSize * 1.434343f + 10f);
    }

    private void initPaint() {
        mTipPaint = new Paint();
        mTipPaint.setColor(TIP_COLOR_NIGHT);
        mTipPaint.setTextAlign(Paint.Align.LEFT);
        mTipPaint.setTextSize(ScreenUtils.spToPx(DEFAULT_TIP_SIZE));
        mTipPaint.setAntiAlias(true);
        mTipPaint.setSubpixelText(true);

        mTextPaint = new TextPaint();
        mTextPaint.setColor(mTextColor);
        mTextPaint.setTextSize(mTextSize);
        mTextPaint.setAntiAlias(true);

        mTitlePaint = new TextPaint();
        mTitlePaint.setColor(mTextColor);
        mTitlePaint.setTextSize(mTitleSize);
        mTitlePaint.setStyle(Paint.Style.FILL_AND_STROKE);
        mTitlePaint.setTypeface(Typeface.DEFAULT_BOLD);
        mTitlePaint.setAntiAlias(true);

        mBgPaint = new Paint();
        mBgPaint.setColor(mPageBg);

        mBatteryPaint = new Paint();
        mBatteryPaint.setAntiAlias(true);
        mBatteryPaint.setColor(TIP_COLOR_NIGHT);
        setTipColor(mBgTheme);
    }

    private void initPageView() {
        mPageView.initSwitchAnim();
        mPageView.setBgColor(mPageBg);
    }

    public void skipToChapter(int groupPos, int pos) {
        mStatus = STATUS_LOADING;
        mCurPos = pos;
        mCurGroupPos = groupPos;
        mWeakPrePageList = null;
        if (mPreLoadDisposable != null) {
            mPreLoadDisposable.dispose();
        }
        mNextPageList = null;
        if (mPageChangeListener != null) {
            mPageChangeListener.onChapterChange(mCurGroupPos, mCurPos);
            preLoadCatalogue();
        }
        if (mCurPage != null) {
            mCurPage.position = 0;
        }
        mPageView.refreshPage();
    }

    public void skipToPage(int pos) {
        mCurPage = getCurPage(pos);
        mPageView.refreshPage();
    }

    public void updateTime() {
        if (mPageView.isPrepare() && mPageView.isRunning()) {
            mPageView.drawCurPage(true);
        }
    }

    public void updateBattery(int level) {
        mBatteryLevel = level;
        if (mPageView.isPrepare() && mPageView.isRunning()) {
            mPageView.drawCurPage(true);
        }
    }

    public void setTextSize(int textSize) {
        if (!isBookOpen) {
            return;
        }
        mTextSize = textSize;
        mTextInterval = (int) (mTextSize * 0.681818f + 1.454545f);
        mTextPara = (int) (mTextSize * 1.272727f + 2.181818f);
        mTitleSize = mTextSize + ScreenUtils.spToPx(EXTRA_TITLE_SIZE);
        mTitleInterval = (int) (mTitleSize * 0.681818f + 1.454545f);
        mTitlePara = (int) (mTitleSize * 1.434343f + 10f);

        mTextPaint.setTextSize(mTextSize);
        mTitlePaint.setTextSize(mTitleSize);
        mSettingManager.setTextSize(mTextSize);
        mWeakPrePageList = null;
        mNextPageList = null;
        if (mStatus == STATUS_FINISH) {
            mCurPageList = loadPageList(mCurGroupPos, mCurPos);
            if (mCurPage.position >= mCurPageList.size()) {
                mCurPage.position = mCurPageList.size() - 1;
            }
        }
        mCurPage = getCurPage(mCurPage.position);
        mPageView.refreshPage();
    }

    public void setNightMode(boolean nightMode) {
        isNightMode = nightMode;
        if (isNightMode) {
            setTipColor(ReadSettingManager.NIGHT_MODE);
            setBgColor(ReadSettingManager.NIGHT_MODE);
        } else {
            setTipColor(mBgTheme);
            setBgColor(mBgTheme);
        }
        mSettingManager.setNightMode(nightMode);
    }

    private void setTipColor(int theme) {
        if (mTipPaint == null || mBatteryPaint == null) {
            return;
        }
        int[] tipColors = ReadSettingManager.getInstance().colorTip;
        if (isNightMode && theme == ReadSettingManager.NIGHT_MODE) {
            mTipPaint.setColor(TIP_COLOR_NIGHT);
            mBatteryPaint.setColor(TIP_COLOR_NIGHT);
        } else if (isNightMode) {
            mTipPaint.setColor(TIP_COLOR_NIGHT);
            mBatteryPaint.setColor(TIP_COLOR_NIGHT);
        } else {
            mTipPaint.setColor(ContextCompat.getColor(context, tipColors[theme]));
            mBatteryPaint.setColor(ContextCompat.getColor(context, tipColors[theme]));
        }
    }

    public void setBgColor(int theme) {
        setTipColor(theme);
        mTextColor = ContextCompat.getColor(context, R.color.standard_black_second_level_color_c4);
        int[] colors = ReadSettingManager.getInstance().colorBg;
        if (isNightMode && theme == ReadSettingManager.NIGHT_MODE) {
            mPageBg = ContextCompat.getColor(context, R.color.black);
        } else if (isNightMode) {
            mBgTheme = theme;
            mSettingManager.setReadBackground(theme);
            mPageBg = ContextCompat.getColor(context, colors[theme]);
        } else {
            mSettingManager.setReadBackground(theme);
            mPageBg = ContextCompat.getColor(context, colors[theme]);
        }

        if (isBookOpen) {
            mPageView.setBgColor(mPageBg);
            mTextPaint.setColor(mTextColor);
            mPageView.refreshPage();
        }
    }

    public void setOnPageChangeListener(OnPageChangeListener listener) {
        mPageChangeListener = listener;
    }

    public int getPageStatus() {
        return mStatus;
    }

    public int getPagePos() {
        return mCurPage.position;
    }

    public int getCurrGroupPos() {
        return mCurGroupPos;
    }

    public int getCurrChapterPos() {
        return mCurPos;
    }

    public void saveRecord() {
        if (!isBookOpen) {
            return;
        }
        List<ChapterBean> curGroup = mRecordBook.bookChapterList.get(mCurGroupPos);
        mRecordBook.setSeqNum(mCurPos + curGroup.get(0).seqNum);
        mRecordBook.setChapterTitle(curGroup.get(mCurPos).chapterTitle);
        mRecordBook.setPagePos(mCurPage.isExtraAfterBook || mCurPage.isExtraAfterChapter ? mCurPage.position - 1 : mCurPage.position);
        mRecordBook.setLastRead(StringUtils.dateConvert(System.currentTimeMillis(), ReadConstant.FORMAT_BOOK_DATE));
        BookRecordHelper.getsInstance().saveRecordBook(mRecordBook, true);
    }

    public void openBook(BookRecordBean recordBean) {
        List<List<ChapterBean>> bookChapterList = recordBean.bookChapterList;
        if (bookChapterList == null || bookChapterList.size() == 0) {
            return;
        }
        mRecordBook = recordBean;
        int recordSeqNum = mRecordBook.getSeqNum();
        mCurGroupPos = recordSeqNum % 50 == 0 ? recordSeqNum / 50 - 1 : recordSeqNum / 50;
        mLastGroupPos = mCurGroupPos;
        List<ChapterBean> group = bookChapterList.get(mCurGroupPos);
        int firstSeqNum = group.get(0).seqNum;
        mCurPos = recordSeqNum - firstSeqNum;
        mLastPos = mCurPos;
        preLoadCatalogue();
    }

    public void showChapterContent() {
        mCurPageList = loadPageList(mCurGroupPos, mCurPos);
        preLoadNextChapter();
        mStatus = STATUS_FINISH;
        if (!isBookOpen) {
            isBookOpen = true;
            //定位到该章上一次打开的页面
            int position = mRecordBook.getPagePos();
            if (position >= mCurPageList.size()) {
                position = mCurPageList.size() - 1;
            }
            mCurPage = getCurPage(position);
            if (mCurPage.isExtraAfterBook || mCurPage.isExtraAfterChapter) {
                mCurPage = getCurPage(position - 1);
            }
            mLastPage = mCurPage;
            if (mPageChangeListener != null) {
                mPageChangeListener.onChapterChange(mCurGroupPos, mCurPos);
            }
        } else {
            mCurPage = getCurPage(0);
        }
        mPageView.drawCurPage(false);
    }

    public void showError() {
        mStatus = STATUS_ERROR;
        mPageView.drawCurPage(false);
    }

    public void closeBook() {
        isBookOpen = false;
        if (mPreLoadDisposable != null) {
            mPreLoadDisposable.dispose();
        }
    }

    @Nullable
    protected abstract List<TxtPage> loadPageList(int groupPos, int chapterPos);

    List<TxtPage> loadPages(TxtChapter chapter, BufferedReader br, int groupPos, int chapterPos) {
        List<TxtPage> pages = new ArrayList<>();
        List<String> lines = new ArrayList<>();
        int rHeight = mVisibleHeight;
        int titleLinesCount = 0;
        boolean isTitle = true;
        String paragraph = chapter.getTitle();
        try {
            while (isTitle || (paragraph = br.readLine()) != null) {
                if (!isTitle) {
                    paragraph = paragraph.replaceAll("\\s", "");
                    if (paragraph.equals("")) continue;
                    paragraph = StringUtils.halfToFull("  " + paragraph + "\n");
                } else {
                    rHeight -= mTitlePara;
                }

                int wordCount;
                String subStr;
                while (paragraph.length() > 0) {
                    if (isTitle) {
                        rHeight -= mTitlePaint.getTextSize();
                    } else {
                        rHeight -= mTextPaint.getTextSize();
                    }
                    if (rHeight < 0) {
                        TxtPage page = new TxtPage();
                        page.position = pages.size();
                        page.title = chapter.getTitle();
                        page.lines = new ArrayList<>(lines);
                        page.titleLines = titleLinesCount;
                        pages.add(page);
                        lines.clear();
                        rHeight = mVisibleHeight;
                        titleLinesCount = 0;
                        continue;
                    }

                    if (isTitle) {
                        wordCount = mTitlePaint.breakText(paragraph, true, mVisibleWidth, null);
                    } else {
                        wordCount = mTextPaint.breakText(paragraph, true, mVisibleWidth, null);
                    }

                    subStr = paragraph.substring(0, wordCount);
                    if (!subStr.equals("\n")) {
                        lines.add(subStr);
                        if (isTitle) {
                            titleLinesCount += 1;
                            rHeight -= mTitleInterval;
                        } else {
                            rHeight -= mTextInterval;
                        }
                    }
                    paragraph = paragraph.substring(wordCount);
                }

                if (!isTitle && lines.size() != 0) {
                    rHeight = rHeight - mTextPara + mTextInterval;
                }

                if (isTitle) {
                    rHeight = rHeight - mTitlePara + mTitleInterval;
                    isTitle = false;
                }
            }

            if (lines.size() != 0) {
                TxtPage page = new TxtPage();
                page.position = pages.size();
                page.title = chapter.getTitle();
                page.lines = new ArrayList<>(lines);
                page.titleLines = titleLinesCount;
                pages.add(page);
                lines.clear();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            IOUtils.close(br);
        }

        if (pages.size() == 0) {
            TxtPage page = new TxtPage();
            page.lines = new ArrayList<>(1);
            pages.add(page);

            mStatus = STATUS_EMPTY;
        }

        if (mSupportPageBetweenChapters) {
            if (pages.size() < mPageChangeListener.getExtraPageFrequency()) {
                TxtPage page = new TxtPage();
                page.isExtraAfterChapter = true;
                page.title = pages.get(pages.size() - 1).title;
                page.position = pages.size();
                pages.add(page);
            } else {
                ArrayList<TxtPage> txtPages = new ArrayList<>();
                int i = 0;
                for (TxtPage page : pages) {
                    if (i == mPageChangeListener.getExtraPageFrequency()) {
                        TxtPage page1 = new TxtPage();
                        page1.isExtraAfterChapter = true;
                        page1.title = page.title;
                        page1.position = txtPages.size();
                        txtPages.add(page1);
                        i = 0;
                    }
                    page.position = txtPages.size();
                    txtPages.add(page);
                    i++;
                }
                pages = txtPages;
                int length = 0;
                for (int j = pages.size() - 1; j > 0; j--) {
                    if (!pages.get(j).isExtraAfterChapter) {
                        length++;
                    } else {
                        break;
                    }
                }
                if (length >= (mPageChangeListener.getExtraPageFrequency() + 1) / 2) {
                    TxtPage page1 = new TxtPage();
                    page1.isExtraAfterChapter = true;
                    page1.title = pages.get(pages.size() - 1).title;
                    page1.position = txtPages.size();
                    pages.add(page1);
                }
            }
        }

        boolean isLastChapter = isLastChapter(groupPos, chapterPos);
        if (mSupportPageAfterLastChapter && isLastChapter) {
            if (pages.get(pages.size() - 1).isExtraAfterChapter) {
                pages.remove(pages.size() - 1);
            }
            TxtPage page = new TxtPage();
            page.isExtraAfterBook = true;
            page.title = pages.get(pages.size() - 1).title;
            page.position = pages.size();
            pages.add(page);
        }

        return pages;
    }

    protected boolean isLastChapter(int groupPos, int chapterPos) {
        List<List<ChapterBean>> groups = mRecordBook.bookChapterList;
        List<ChapterBean> chapters = groups.get(groupPos);
        if (groupPos == groups.size() - 1 && chapterPos == chapters.size() - 1) {
            return true;
        }
        return false;
    }

    void onDraw(Layer layer, boolean isUpdate) {
        drawBackground(mPageView.getBgBitmap(), isUpdate);
        if (!isUpdate) {
            drawContent(layer);
        }
        mPageView.invalidate();
    }

    private void drawBackground(Layer layer, boolean isUpdate) {
        Canvas canvas = new Canvas(layer.bitmap);
        int tipMarginHeight = ScreenUtils.dpToPx(3);
        if (!isUpdate) {
            canvas.drawColor(mPageBg);
            float tipTop = tipMarginHeight - mTipPaint.getFontMetrics().top;
            int visibleRight = mDisplayWidth - mMarginWidth;
            if (mStatus != STATUS_FINISH) {
                if (mChapterList != null && mChapterList.size() != 0) {
                    List<TxtChapter> list = mChapterList.get(mCurGroupPos);
                    if (list != null && list.size() != 0) {
                        String title = list.get(mCurPos).getTitle();
                        float x = visibleRight - mTipPaint.measureText(title);
                        canvas.drawText(title, x, tipTop, mTipPaint);
                    }
                }
            } else {
                String title = mCurPage.title;
                float x = visibleRight - mTipPaint.measureText(title);
                canvas.drawText(mCurPage.title, x, tipTop, mTipPaint);
            }
            if (mRecordBook != null) {
                canvas.drawText(mRecordBook.bookName, mMarginWidth, tipTop, mTipPaint);
            }
            float y = mDisplayHeight - mTipPaint.getFontMetrics().bottom - tipMarginHeight;
            if (mStatus == STATUS_FINISH) {
                String percent = (mCurPage.position + 1) + "/" + mCurPageList.size();
                canvas.drawText(percent, mMarginWidth, y, mTipPaint);
            }
        } else {
            mBgPaint.setColor(mPageBg);
            canvas.drawRect(mDisplayWidth / 2, mDisplayHeight - mMarginHeight + ScreenUtils.dpToPx(2), mDisplayWidth, mDisplayHeight, mBgPaint);
        }

        int outFrameLeft = drawBattery(canvas, tipMarginHeight);
        drawTime(canvas, tipMarginHeight, outFrameLeft);
    }

    private void drawTime(Canvas canvas, int tipMarginHeight, int outFrameLeft) {
        float y = mDisplayHeight - mTipPaint.getFontMetrics().bottom - tipMarginHeight;
        String time = StringUtils.dateConvert(System.currentTimeMillis(), ReadConstant.FORMAT_TIME);
        float x = outFrameLeft - mTipPaint.measureText(time) - ScreenUtils.dpToPx(4);
        canvas.drawText(time, x, y, mTipPaint);
    }

    private int drawBattery(Canvas canvas, int tipMarginHeight) {
        int visibleRight = mDisplayWidth - mMarginWidth;
        int visibleBottom = mDisplayHeight - tipMarginHeight;
        int outFrameWidth = (int) mTipPaint.measureText("xxx");
        int outFrameHeight = (int) mTipPaint.getTextSize();
        int polarHeight = ScreenUtils.dpToPx(6);
        int polarWidth = ScreenUtils.dpToPx(2);
        int border = 1;
        int innerMargin = 1;
        int polarLeft = visibleRight - polarWidth;
        int polarTop = visibleBottom - (outFrameHeight + polarHeight) / 2;
        Rect polar = new Rect(polarLeft, polarTop, visibleRight,
                polarTop + polarHeight - ScreenUtils.dpToPx(2));
        mBatteryPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(polar, mBatteryPaint);
        int outFrameLeft = polarLeft - outFrameWidth;
        int outFrameTop = visibleBottom - outFrameHeight;
        int outFrameBottom = visibleBottom - ScreenUtils.dpToPx(2);
        Rect outFrame = new Rect(outFrameLeft, outFrameTop, polarLeft, outFrameBottom);
        mBatteryPaint.setStyle(Paint.Style.STROKE);
        mBatteryPaint.setStrokeWidth(border);
        canvas.drawRect(outFrame, mBatteryPaint);
        float innerWidth = (outFrame.width() - innerMargin * 2 - border) * (mBatteryLevel / 100.0f);
        RectF innerFrame = new RectF(outFrameLeft + border + innerMargin, outFrameTop + border + innerMargin,
                outFrameLeft + border + innerMargin + innerWidth, outFrameBottom - border - innerMargin);
        mBatteryPaint.setStyle(Paint.Style.FILL);
        canvas.drawRect(innerFrame, mBatteryPaint);
        return outFrameLeft;
    }

    private void drawContent(Layer layer) {
        Canvas canvas = new Canvas(layer.bitmap);
        if (mCurPage != null && mCurPage.isExtraAfterBook) {
            layer.isExtraAfterBook = true;
            layer.isExtraAfterChapter = false;
            mPageChangeListener.onDrawPageAfterLastChapter(canvas, mTextColor, isNightMode, layer.rootLayoutForExtra);
            return;
        }
        if (mCurPage != null && mCurPage.isExtraAfterChapter) {
            layer.isExtraAfterChapter = true;
            layer.isExtraAfterBook = false;
            mPageChangeListener.onDrawPageAfterChapter(canvas, mTextColor, isNightMode, layer.rootLayoutForExtra);
            return;
        }

        layer.isExtraAfterBook = false;
        layer.isExtraAfterChapter = false;
        if (mStatus != STATUS_FINISH) {
            drawTips(canvas);
        } else {
            float top = mMarginHeight - mTextPaint.getFontMetrics().top;
            int interval = mTextInterval + (int) mTextPaint.getTextSize();
            int para = mTextPara + (int) mTextPaint.getTextSize();
            int titleInterval = mTitleInterval + (int) mTitlePaint.getTextSize();
            int titlePara = mTitlePara + (int) mTextPaint.getTextSize();
            String str;

            for (int i = 0; i < mCurPage.titleLines; ++i) {
                str = mCurPage.lines.get(i);
                if (i == 0) {
                    top += mTitlePara;
                }
                int start = mMarginWidth;
                canvas.drawText(str, start, top, mTitlePaint);

                if (i == mCurPage.titleLines - 1) {
                    top += titlePara;
                } else {
                    top += titleInterval;
                }
            }

            for (int i = mCurPage.titleLines; i < mCurPage.lines.size(); ++i) {
                str = mCurPage.lines.get(i);
                canvas.drawText(str, mMarginWidth, top, mTextPaint);
                if (str.endsWith("\n")) {
                    top += para;
                } else {
                    top += interval;
                }
            }
        }
    }

    private void drawTips(Canvas canvas) {
        String tip = "";
        switch (mStatus) {
            case STATUS_LOADING:
                tip = ViewUtils.getString(R.string.loading);
                break;
            case STATUS_ERROR:
                tip = ViewUtils.getString(R.string.load_failed);
                break;
            case STATUS_EMPTY:
                tip = ViewUtils.getString(R.string.no_content);
                break;
            case STATUS_PARSE:
                tip = ViewUtils.getString(R.string.parsing);
                break;
            case STATUS_PARSE_ERROR:
                tip = ViewUtils.getString(R.string.parsing_failed);
                break;
        }

        Paint.FontMetrics fontMetrics = mTextPaint.getFontMetrics();
        float textHeight = fontMetrics.top - fontMetrics.bottom;
        float textWidth = mTextPaint.measureText(tip);
        float pivotX = (mDisplayWidth - textWidth) / 2;
        float pivotY = (mDisplayHeight - textHeight) / 2;
        canvas.drawText(tip, pivotX, pivotY, mTextPaint);
    }

    void setDisplaySize(int w, int h) {
        mDisplayWidth = w;
        mDisplayHeight = h;
        mVisibleWidth = mDisplayWidth - mMarginWidth * 2;
        mVisibleHeight = mDisplayHeight - mMarginHeight * 2;
        mNextBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
        if (mStatus == STATUS_FINISH) {
            mCurPageList = loadPageList(mCurGroupPos, mCurPos);
            mCurPage = getCurPage(mCurPage.position);
        }
        mPageView.drawCurPage(false);
    }

    boolean pre() {
        if (checkStatus()) {
            return false;
        }
        TxtPage prevPage = getPrevPage();
        if (prevPage == null) {
            if (!preChapter()) {
                return false;
            } else {
                mLastPage = mCurPage;
                mCurPage = getPrevLastPage();
                mPageView.drawNextPage();
                return true;
            }
        }
        mLastPage = mCurPage;
        mCurPage = prevPage;
        mPageView.drawNextPage();
        return true;
    }

    boolean preChapter() {
        if (mCurPos == 0 && mCurGroupPos == 0) {
            return false;
        }
        int preGroupPos = mCurGroupPos;
        int prevChapter = mCurPos - 1;
        if (prevChapter < 0) {
            preGroupPos = mCurGroupPos - 1;
            if (mRecordBook.bookChapterList.get(preGroupPos).size() == 0) {
                return false;
            }
            prevChapter = mRecordBook.bookChapterList.get(preGroupPos).size() - 1;
        }
        mNextPageList = mCurPageList;
        if (mWeakPrePageList != null && mWeakPrePageList.get() != null) {
            mCurPageList = mWeakPrePageList.get();
            mWeakPrePageList = null;
        } else {
            mCurPageList = loadPageList(preGroupPos, prevChapter);
        }
        mLastPos = mCurPos;
        mCurPos = prevChapter;
        if (preGroupPos != mCurGroupPos) {
            mLastGroupPos = mCurGroupPos;
            mCurGroupPos = preGroupPos;
        }
        if (mCurPageList != null) {
            mStatus = STATUS_FINISH;
        } else {
            mStatus = STATUS_LOADING;
            mCurPage.position = 0;
            mPageView.drawNextPage();
        }

        if (mPageChangeListener != null) {
            mPageChangeListener.onChapterChange(mCurGroupPos, mCurPos);
            preLoadCatalogue();
        }
        return true;
    }

    private void preLoadCatalogue() {
        if (mCurPos % 50 > 42 && mCurGroupPos != mRecordBook.bookChapterList.size() - 1 && mRecordBook.bookChapterList.get(mCurGroupPos + 1).size() == 0) {
            mPageChangeListener.preLoadChaptersGroup(mCurGroupPos + 1);
        } else if (mCurPos % 50 < 8 && mCurGroupPos != 0 && mRecordBook.bookChapterList.get(mCurGroupPos - 1).size() == 0) {
            mPageChangeListener.preLoadChaptersGroup(mCurGroupPos - 1);
        }
    }

    boolean next() {
        if (checkStatus()) {
            return false;
        }
        TxtPage nextPage = getNextPage();

        if (nextPage == null) {
            if (!nextChapter()) {
                return false;
            } else {
                mLastPage = mCurPage;
                mCurPage = getCurPage(0);
                mPageView.drawNextPage();
                return true;
            }
        }

        mLastPage = mCurPage;
        mCurPage = nextPage;
        mPageView.drawNextPage();
        return true;
    }

    boolean nextChapter() {
        List<ChapterBean> currGroup = mRecordBook.bookChapterList.get(mCurGroupPos);
        if (mCurPos == currGroup.size() - 1 && mCurGroupPos == mRecordBook.bookChapterList.size() - 1) {
            return false;
        }

        int nextGroupPos = mCurGroupPos;
        int nextChapter = mCurPos + 1;
        if (nextChapter >= currGroup.size()) {
            nextGroupPos = mCurGroupPos + 1;
            if (mRecordBook.bookChapterList.get(nextGroupPos).size() == 0) {
                return false;
            }
            nextChapter = 0;
        }

        if (mCurPageList != null) {
            mWeakPrePageList = new WeakReference<List<TxtPage>>(new ArrayList<>(mCurPageList));
        }
        if (mNextPageList != null) {
            mCurPageList = mNextPageList;
            mNextPageList = null;
        } else {
            mCurPageList = loadPageList(nextGroupPos, nextChapter);
        }

        mLastPos = mCurPos;
        mCurPos = nextChapter;
        if (nextGroupPos != mCurGroupPos) {
            mLastGroupPos = mCurGroupPos;
            mCurGroupPos = nextGroupPos;
        }
        if (mCurPageList != null) {
            mStatus = STATUS_FINISH;
            preLoadNextChapter();
        } else {
            mStatus = STATUS_LOADING;
            mCurPage.position = 0;
            mPageView.drawNextPage();
        }

        if (mPageChangeListener != null) {
            mPageChangeListener.onChapterChange(mCurGroupPos, mCurPos);
            preLoadCatalogue();
        }

        return true;
    }

    private void preLoadNextChapter() {
        int groupPos = mCurGroupPos;
        int chapterPos = mCurPos;
        if (chapterPos + 1 >= mRecordBook.bookChapterList.get(mCurGroupPos).size()) {
            groupPos = mCurGroupPos + 1;
            if (groupPos >= mRecordBook.bookChapterList.size()) {
                return;
            }
            chapterPos = 0;
        } else {
            chapterPos = mCurPos + 1;
        }
        if (mPreLoadDisposable != null) {
            mPreLoadDisposable.dispose();
        }
        final int nextGroup = groupPos;
        final int nextChapter = chapterPos;
        Observable.create(new ObservableOnSubscribe<List<TxtPage>>() {
            @Override
            public void subscribe(ObservableEmitter<List<TxtPage>> e) throws Exception {
                e.onNext(loadPageList(nextGroup, nextChapter));
            }
        }).compose(new ObservableTransformer<List<TxtPage>, List<TxtPage>>() {
            @Override
            public ObservableSource<List<TxtPage>> apply(Observable<List<TxtPage>> upstream) {
                return RxUtils.toSimpleSingle(upstream);
            }
        }).subscribe(new Observer<List<TxtPage>>() {
            @Override
            public void onSubscribe(Disposable d) {
                mPreLoadDisposable = d;
            }

            @Override
            public void onNext(List<TxtPage> txtPages) {
                mNextPageList = txtPages;
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }

    void pageCancel() {
        if (mCurPage.position == 0 && (mCurGroupPos > mLastGroupPos || mCurPos > mLastPos)) {
            preChapter();
        } else if (mCurPageList == null ||
                (mCurPage.position == mCurPageList.size() - 1 && (mCurGroupPos < mLastGroupPos || mCurPos < mLastPos))) {
            nextChapter();
        }
        mCurPage = mLastPage;
    }

    private TxtPage getCurPage(int pos) {
        if (pos > mCurPageList.size() - 1) {
            pos = mCurPageList.size() - 1;
        }
        TxtPage txtPage = mCurPageList.get(pos);
        if (mPageChangeListener != null) {
            mPageChangeListener.onPageChange(pos, txtPage, false);
        }
        return txtPage;
    }


    private TxtPage getPrevPage() {
        int pos = mCurPage.position - 1;
        if (pos < 0) {
            return null;
        }
        TxtPage txtPage = mCurPageList.get(pos);
        if (mPageChangeListener != null) {
            boolean preLoadExtra = false;
            if (mCurPageList.get(mCurPage.position).isExtraAfterChapter) {
                preLoadExtra = (pos - 1 > -1 && mCurPageList.get(pos - 1).isExtraAfterChapter);
            } else {
                preLoadExtra = (pos - 2 > -1 && mCurPageList.get(pos - 2).isExtraAfterChapter);
            }
            mPageChangeListener.onPageChange(pos, txtPage, preLoadExtra || pos == 0);
        }
        return txtPage;
    }

    private TxtPage getNextPage() {
        if (null != mCurPage) {
            int pos = mCurPage.position + 1;
            if (pos >= mCurPageList.size()) {
                return null;
            }
            TxtPage txtPage = mCurPageList.get(pos);
            if (mPageChangeListener != null) {
                boolean preLoadExtra = (!mCurPageList.get(mCurPage.position).isExtraAfterChapter && mCurPage.position % (mPageChangeListener.getExtraPageFrequency() + 1) == 0);
               /* Log.i("ggg", "pre_cur:"+ mCurPageList.get(mCurPage.position).isExtraAfterChapter);
                if (mCurPageList.get(mCurPage.position).isExtraAfterChapter) {
                    Log.i("ggg", "pre_-2:"+ (pos - 1 > -1 && mCurPageList.get(pos - 1).isExtraAfterChapter));
                    preLoadExtra = (pos + 1 < mCurPageList.size() && mCurPageList.get(pos + 1).isExtraAfterChapter);
                } else {
                    preLoadExtra = (pos + 2 < mCurPageList.size() && mCurPageList.get(pos + 2).isExtraAfterChapter);
                }*/
                mPageChangeListener.onPageChange(pos, txtPage, preLoadExtra);
            }
            return txtPage;
        }
        return new TxtPage();
    }

    private TxtPage getPrevLastPage() {
        int pos = mCurPageList.size() - 1;
        TxtPage txtPage = mCurPageList.get(pos);
        if (mPageChangeListener != null) {
            mPageChangeListener.onPageChange(pos, txtPage, false);
        }
        return txtPage;
    }

    private boolean checkStatus() {
        if (mStatus == STATUS_LOADING) {
            ToastUtils.showLimited(ViewUtils.getString(R.string.please_wait));
            return true;
        } else if (mStatus == STATUS_ERROR) {
            mStatus = STATUS_LOADING;
            mPageView.drawCurPage(false);
            return true;
        }
        return false;
    }

    public abstract void onChaptersGroupUpdate(int groupPos);

    public void supportPageBetweenChapters(boolean support) {
        mSupportPageBetweenChapters = support;
    }

    public void supportPageAfterLastChapter(boolean support) {
        mSupportPageAfterLastChapter = support;
    }

    public interface OnPageChangeListener {
        void onChapterChange(int curGroupPos, int pos);

        void loadChapterContents(List<TxtChapter> chapters, int curGroupPos, int pos);

        void preLoadChaptersGroup(int groupPos);

        void onChaptersConverted(List<List<TxtChapter>> chapters, int curGroupPos, int groupPos);

        void onPageCountChange(int count);

        int getExtraPageFrequency();

        void onPageChange(int pos, TxtPage txtPage, boolean isCur);

        void onDrawPageAfterLastChapter(Canvas canvas, int textColor, boolean isNightMode, FrameLayout rootLayoutForExtra);

        void onDrawPageAfterChapter(Canvas canvas, int textColor, boolean isNightMode, FrameLayout rootLayoutForExtra);
    }
}
