package com.zymh.ebk.read.page;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import com.zymh.ebk.read.dao.BookRecordBean;
import com.zymh.ebk.read.dao.ChapterBean;
import com.zymh.ebk.read.utils.ReadConstant;
import com.zymh.ebk.read.utils.FileUtils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

public class PageLoader extends AbsPageLoader {

    PageLoader(PageView pageView) {
        super(pageView);
    }

    @Override
    public void openBook(BookRecordBean recordBean) {
        super.openBook(recordBean);
        isBookOpen = false;
        if (recordBean.bookChapterList == null) {
            return;
        }
        mChapterList = convertTxtChapterGroup(recordBean.bookChapterList);

        if (mPageChangeListener != null) {
            mPageChangeListener.onChaptersConverted(mChapterList, mCurGroupPos, mCurGroupPos);
        }

        loadCurrentChapter();
    }

    @Override
    public void onChaptersGroupUpdate(int groupPos) {
        List<ChapterBean> chapterBeans = mRecordBook.bookChapterList.get(groupPos);
        List<TxtChapter> txtChapters = convertTxtChapters(chapterBeans);
        mChapterList.set(groupPos, txtChapters);

        if (mPageChangeListener != null) {
            mPageChangeListener.onChaptersConverted(mChapterList, mCurGroupPos, groupPos);
        }
    }

    private List<List<TxtChapter>> convertTxtChapterGroup(List<List<ChapterBean>> bookChapters) {
        List<List<TxtChapter>> txtChapters = new ArrayList<>(bookChapters.size());
        for (List<ChapterBean> group : bookChapters) {
            List<TxtChapter> sub = convertTxtChapters(group);
            txtChapters.add(sub);
        }
        return txtChapters;
    }

    @NonNull
    private List<TxtChapter> convertTxtChapters(List<ChapterBean> group) {
        List<TxtChapter> sub = new ArrayList<>();
        for (ChapterBean bean : group) {
            TxtChapter chapter = new TxtChapter();
            chapter.bookId = bean.getBookId();
            chapter.title = bean.getChapterTitle();
            chapter.seqNum = bean.getSeqNum();
            chapter.chapterId = bean.getChapterId();
            chapter.isRead = bean.isRead;
            sub.add(chapter);
        }
        return sub;
    }

    @Nullable
    @Override
    protected List<TxtPage> loadPageList(int groupPos, int chapterPos) {
        if (mChapterList == null) {
            throw new IllegalArgumentException("chapter list must not null");
        }
        TxtChapter txtChapter = mChapterList.get(groupPos).get(chapterPos);
        File file = new File(ReadConstant.BOOK_CACHE_PATH + mRecordBook.getBookId()
                + File.separator + txtChapter.chapterId + FileUtils.SUFFIX_FILE);
        if (!file.exists()) return null;

        Reader reader = null;
        try {
            reader = new FileReader(file);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        BufferedReader br = new BufferedReader(reader);

        return loadPages(txtChapter, br, groupPos, chapterPos);
    }

    @Override
    boolean preChapter() {
        boolean hasPrev = super.preChapter();
        if (!hasPrev) return false;

        if (mStatus == STATUS_FINISH) {
            loadPreChapter();
            return true;
        } else if (mStatus == STATUS_LOADING) {
            loadCurrentChapter();
            return false;
        }
        return false;
    }

    @Override
    boolean nextChapter() {
        boolean hasNext = super.nextChapter();
        if (!hasNext) return false;

        if (mStatus == STATUS_FINISH) {
            loadNextChapter();
            return true;
        } else if (mStatus == STATUS_LOADING) {
            loadCurrentChapter();
            return false;
        }
        return false;
    }

    @Override
    public void skipToChapter(int groupPos, int chapterPos) {
        super.skipToChapter(groupPos, chapterPos);
        loadCurrentChapter();
    }

    private void loadCurrentChapter() {
        List<TxtChapter> bookChapters = new ArrayList<>(5);
        int currentPos = mCurPos;
        int currentGroupPos = mCurGroupPos;
        List<TxtChapter> currentGroup = mChapterList.get(currentGroupPos);
        List<TxtChapter> preGroup = currentGroupPos == 0 ? null : mChapterList.get(currentGroupPos - 1);
        List<TxtChapter> nextGroup = currentGroupPos == mChapterList.size() - 1 ? null : mChapterList.get(currentGroupPos + 1);
        bookChapters.add(currentGroup.get(currentPos));

        //后2
        if (currentPos <= currentGroup.size() - 3) {
            int begin = currentPos + 1;
            int next = begin + 2;
            if (next > currentGroup.size()) {
                next = currentGroup.size();
            }
            bookChapters.addAll(currentGroup.subList(begin, next));
        } else if (currentPos <= currentGroup.size() - 2) {
            bookChapters.add(currentGroup.get(currentPos + 1));
            if (nextGroup != null && nextGroup.size() != 0) {
                bookChapters.add(nextGroup.get(0));
            }
        } else {
            if (nextGroup != null && nextGroup.size() != 0) {
                int begin = 0;
                int next = begin + 2;
                if (next > nextGroup.size()) {
                    next = nextGroup.size();
                }
                bookChapters.addAll(nextGroup.subList(begin, next));
            }
        }

        //前2
        if (currentPos >= 2) {
            int prev = currentPos - 2;
            if (prev < 0) {
                prev = 0;
            }
            bookChapters.addAll(currentGroup.subList(prev, currentPos));
        } else if (currentPos >= 1) {
            bookChapters.add(currentGroup.get(currentPos - 1));
            if (preGroup != null && preGroup.size() != 0) {
                bookChapters.add(preGroup.get(preGroup.size() - 1));
            }
        } else {
            if (preGroup != null && preGroup.size() != 0) {
                int prev = preGroup.size() - 2;
                if (prev < 0) {
                    prev = 0;
                }
                bookChapters.addAll(preGroup.subList(prev, preGroup.size()));
            }
        }

        mPageChangeListener.loadChapterContents(bookChapters, mCurGroupPos, mCurPos);
    }

    private void loadPreChapter() {
        List<TxtChapter> bookChapters = new ArrayList<>(2);
        int currentPos = mCurPos;
        int currentGroupPos = mCurGroupPos;
        List<TxtChapter> currentGroup = mChapterList.get(currentGroupPos);
        List<TxtChapter> preGroup = currentGroupPos == 0 ? null : mChapterList.get(currentGroupPos - 1);

        //前2
        if (currentPos >= 2) {
            int prev = currentPos - 2;
            if (prev < 0) {
                prev = 0;
            }
            bookChapters.addAll(currentGroup.subList(prev, currentPos));
        } else if (currentPos >= 1) {
            bookChapters.add(currentGroup.get(currentPos - 1));
            if (preGroup != null && preGroup.size() != 0) {
                bookChapters.add(preGroup.get(preGroup.size() - 1));
            }
        } else {
            if (preGroup != null && preGroup.size() != 0) {
                int prev = preGroup.size() - 2;
                if (prev < 0) {
                    prev = 0;
                }
                bookChapters.addAll(preGroup.subList(prev, preGroup.size()));
            }
        }

        mPageChangeListener.loadChapterContents(bookChapters, currentGroupPos, currentPos);
    }

    private void loadNextChapter() {
        List<TxtChapter> bookChapters = new ArrayList<>(2);
        int currentPos = mCurPos;
        int currentGroupPos = mCurGroupPos;
        List<TxtChapter> currentGroup = mChapterList.get(currentGroupPos);
        List<TxtChapter> nextGroup = currentGroupPos == mChapterList.size() - 1 ? null : mChapterList.get(currentGroupPos + 1);

        //后2
        if (currentPos <= currentGroup.size() - 3) {
            int begin = currentPos + 1;
            int next = begin + 2;
            if (next > currentGroup.size()) {
                next = currentGroup.size();
            }
            bookChapters.addAll(currentGroup.subList(begin, next));
        } else if (currentPos <= currentGroup.size() - 2) {
            bookChapters.add(currentGroup.get(currentPos + 1));
            if (nextGroup != null && nextGroup.size() != 0) {
                bookChapters.add(nextGroup.get(0));
            }
        } else {
            if (nextGroup != null && nextGroup.size() != 0) {
                int begin = 0;
                int next = begin + 2;
                if (next > nextGroup.size()) {
                    next = nextGroup.size();
                }
                bookChapters.addAll(nextGroup.subList(0, next));
            }
        }
        mPageChangeListener.loadChapterContents(bookChapters, currentGroupPos, currentPos);
    }
}

