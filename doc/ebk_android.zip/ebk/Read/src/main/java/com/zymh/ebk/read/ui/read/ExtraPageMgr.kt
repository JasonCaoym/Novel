package com.zymh.ebk.read.ui.read

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Canvas
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import com.zydm.base.ext.setVisible
import com.zydm.base.rx.MtSchedulers
import com.zydm.base.statistics.umeng.StatisConst
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.ad.*
import com.zydm.ebk.provider.data.bean.AdConfig
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.read.R
import com.zymh.ebk.read.data.api.Api
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.setting.ReadSettingManager
import kotlinx.android.synthetic.main.end_page_layout.view.*

@SuppressLint("StaticFieldLeak")
class ExtraPageMgr {

    private var mBookEndPage: FrameLayout? = null
    private var mChapterEndPage: FrameLayout? = null
    private var mLastRecBooksView: LastRecBooksView? = null
    private var mAdParam: AdParam? = null

    fun onDrawPageAfterLastChapter(canvas: Canvas, textColor: Int, isNightMode: Boolean, rootLayoutForExtra: FrameLayout) {
        mChapterEndPage?.setVisible(false)
        mBookEndPage?.setVisible(true)
        mBookEndPage!!.not_end_tv.setTextColor(textColor)
        mBookEndPage!!.please_wait_update.setTextColor(textColor)
        mBookEndPage!!.finished.setTextColor(textColor)
        if (mBookEndPage!!.parent != null) {
            return
        }
        rootLayoutForExtra.addView(mBookEndPage)
    }

    fun onDrawPageAfterChapter(canvas: Canvas, textColor: Int, isNightMode: Boolean, rootLayoutForExtra: FrameLayout) {
        mBookEndPage?.setVisible(false)
        mChapterEndPage?.setVisible(true)
        if (mChapterEndPage!!.parent != null) {
            return
        }
        rootLayoutForExtra.addView(mChapterEndPage)
    }

    fun init(adHelper: IAdHelper?, activity: Activity, book: BookRecordBean) {
        initBookEndPage(book, activity)
        if (adHelper != null) {
            mAdParam = AdMgr.getAdParam(AdMgr.AD_READ_INTER_CUT)
            initChapterEndPage(adHelper, activity)
        }
    }

    private fun initChapterEndPage(adHelper: IAdHelper, activity: Activity) {
        if (mAdParam == null) {
            return;
        }
        mChapterEndPage = FrameLayout(activity)
        val width = ViewUtils.getPhonePixels()[0]
        var height = if (mAdParam!!.mConfig.isOriginal_()) ViewGroup.LayoutParams.WRAP_CONTENT else width * 2 / 3
        if (mAdParam!!.mConfig.source == AdConfig.SOURCE_GDT) {
            height = ViewUtils.dp2px(300.0f)
        }
        val params = FrameLayout.LayoutParams(width, height)
        params.gravity = Gravity.CENTER
        mChapterEndPage!!.layoutParams = params
        adHelper.loadAdWhitContainer(mAdParam!!, mChapterEndPage!!, activity, object : OnAdLoadedListener {
            override fun onAdLoad(imageMode: Int) {
                val isNightMode = ReadSettingManager.getInstance().isNightMode();
                setNightMode(isNightMode)
            }
        })

    }

    public fun setNightMode(nightMode: Boolean) {
        if (mAdParam == null) {
            return
        }

        val config = mAdParam?.mConfig ?: return

        if (!config.isOriginal_()) {
            return
        }

        if (config.source == AdConfig.SOURCE_GDT) {
            return
        }

        if (mChapterEndPage == null) {
            return
        }
        setColor(mChapterEndPage, nightMode)
    }

    private fun setColor(mChapterEndPage: FrameLayout?, isNightMode: Boolean) {
        try {
            val titleSmallSingle = mChapterEndPage!!.findViewById<TextView>(R.id.ad_small_title_tv)
            val adlayoutSmallSingle = mChapterEndPage.findViewById<ViewGroup>(R.id.ad_small_single_layout)
            val resume = mChapterEndPage.findViewById<TextView>(R.id.ad_small_resume_tv)

            val titleBigSingle = mChapterEndPage.findViewById<TextView>(R.id.ad_big_title_tv)
            val adlayoutBigSingle = mChapterEndPage.findViewById<ViewGroup>(R.id.ad_big_single_layout)

            val adlayoutSmallThree = mChapterEndPage.findViewById<ViewGroup>(R.id.ad_small_three_layout)
            val titleSmallThree = mChapterEndPage.findViewById<TextView>(R.id.ad_three_title_tv)

            titleSmallSingle?.setTextColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_third_level_color_c5 else R.color.standard_black_first_level_color_c3))
            titleBigSingle?.setTextColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_third_level_color_c5 else R.color.standard_black_first_level_color_c3))
            titleSmallThree?.setTextColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_third_level_color_c5 else R.color.standard_black_first_level_color_c3))

            resume?.setTextColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_third_level_color_c5 else R.color.standard_black_second_level_color_c4))
            adlayoutSmallSingle?.setBackgroundColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_second_level_color_c4 else R.color.white))
            adlayoutBigSingle?.setBackgroundColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_second_level_color_c4 else R.color.white))
            adlayoutSmallThree?.setBackgroundColor(ViewUtils.getColor(if (isNightMode) R.color.standard_black_second_level_color_c4 else R.color.white))
        } catch (e: Exception) {

        }
    }


    @SuppressLint("CheckResult")
    private fun initBookEndPage(book: BookRecordBean, activity: Activity) {
        mBookEndPage = ViewUtils.inflateView(activity, R.layout.end_page_layout, null) as FrameLayout?
        if (book.isFinish) {
            mBookEndPage!!.not_end_tv.setVisible(false)
            mBookEndPage!!.please_wait_update.setVisible(false)
            mBookEndPage!!.finished.setVisible(true)
        } else {
            mBookEndPage!!.not_end_tv.setVisible(true)
            mBookEndPage!!.please_wait_update.setVisible(true)
            mBookEndPage!!.finished.setVisible(false)
        }

        mLastRecBooksView = LastRecBooksView()
        mLastRecBooksView!!.onCreate(mBookEndPage!!.rec_layout)
        mLastRecBooksView!!.createView(activity, null)
        mLastRecBooksView!!.initView()
        Api.recommend().similarBooks(book.bookId).build()
                .subscribeOn(MtSchedulers.io())
                .observeOn(MtSchedulers.mainUi())
                .subscribe({
                    if (it.list.size == 0) {
                        mBookEndPage!!.rec_root.setVisible(false)
                        return@subscribe
                    }
                    mBookEndPage!!.rec_root.setVisible(true)
                    mLastRecBooksView!!.setItemData(0, it)
                }, {
                    mBookEndPage!!.rec_root.setVisible(false)
                })
        mBookEndPage!!.go_city_btn.setOnClickListener {
            ActivityHelper.gotoHome(activity, BaseData(StatisConst.PAGE_READ))
        }
    }

    fun refreshExtraPageAfterChapter(iAdHelper: IAdHelper?, activity: Activity) {
        if (!AdMgr.isShowAd(AdMgr.AD_READ_INTER_CUT)) {
            return
        }
        if (iAdHelper == null) {
            return
        }
        if (mAdParam == null) {
            return
        }
        iAdHelper.loadAdWhitContainer(mAdParam!!, mChapterEndPage!!, activity, object : OnAdLoadedListener {
            override fun onAdLoad(imageMode: Int) {
                val isNightMode = ReadSettingManager.getInstance().isNightMode();
                setNightMode(isNightMode)
            }
        })
    }

    fun destroy() {
        mChapterEndPage?.destroyAd()
    }
}