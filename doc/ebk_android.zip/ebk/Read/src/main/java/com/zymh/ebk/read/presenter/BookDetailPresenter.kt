package com.zymh.ebk.read.presenter

import android.annotation.SuppressLint
import android.text.TextUtils
import com.zydm.base.common.Constants
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.rx.MtSchedulers
import com.zymh.ebk.read.data.api.Api
import com.zymh.ebk.read.data.bean.BookDetailBean
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.dao.BookShelfBean
import com.zymh.ebk.read.dao.ChapterBean
import com.zymh.ebk.read.dao.BookShelfHelper
import com.zymh.ebk.read.data.bean.ChapterUrlBean
import com.zymh.ebk.read.presenter.view.IBookDetailPage
import com.zymh.ebk.read.utils.*
import io.reactivex.Single
import io.reactivex.functions.BiFunction
import io.reactivex.functions.Consumer


class BookDetailPresenter(private val mPage: IBookDetailPage, private var mBookDetailBean: BookDetailBean) : AbsPagePresenter<BookDetailBean>(mPage) {

    @SuppressLint("CheckResult")
    override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<BookDetailBean> {

        val detail = Api.book().getDetail(mBookDetailBean.bookId).setForceUpdate(isForceUpdate).build()

        val curChapter = Single.fromCallable {
            val bookRecordBean: BookRecordBean? = BookRecordHelper.getsInstance().findBookRecordById(mBookDetailBean.bookId)
            bookRecordBean?.seqNum ?: 1
        }.subscribeOn(MtSchedulers.io()).flatMap { seqNum: Int ->
            Api.chapter().getDetailBySeqNum(seqNum, mBookDetailBean.bookId).build().onErrorReturnItem(ChapterUrlBean())
                    .map { chapterUrlBean ->
                        val secret = chapterUrlBean.secret
                        val content = chapterUrlBean.content
                        chapterUrlBean.url = DecryptUtils.decryptUrl(secret, content)
                        chapterUrlBean
                    }.onErrorReturnItem(ChapterUrlBean()).map { chapterUrlBean ->
                        var content = if (TextUtils.isEmpty(chapterUrlBean.url)) Constants.EMPTY else ChapterContentLoadUtils.loadContent(chapterUrlBean.url)
                        content = if (content.startsWith(Constants.CHINESE_PARAGRAPH_SPACE, false)) content else Constants.CHINESE_PARAGRAPH_SPACE.plus(content)
                        try {
                            content = content.replace(Regex("\n{3,}|\n"), "\n".plus("\n").plus(Constants.CHINESE_PARAGRAPH_SPACE))
                        } catch (e: Exception) {
                            //字符串处理可能出现一些无法预料的情况，如果处理报错，那么使用原章节数据
                        }
                        val chapterBean = ChapterBean()
                        chapterBean.chapterId = chapterUrlBean.chapterId
                        chapterBean.content = content
                        chapterBean.seqNum = chapterUrlBean.seqNum
                        chapterBean.bookId = chapterUrlBean.bookId
                        chapterBean.chapterTitle = chapterUrlBean.chapterTitle
                        chapterBean.chapterTitle = StringUtils.convertChapterTitle(chapterBean.chapterTitle, chapterBean.seqNum)
                        chapterBean
                    }
        }

        return if (TextUtils.isEmpty(mBookDetailBean.bookName) || TextUtils.isEmpty(mBookDetailBean.bookCover)) {
            Single.zip(detail, curChapter, BiFunction<BookDetailBean, ChapterBean, BookDetailBean> { bookDetailBean: BookDetailBean, chapterBean: ChapterBean ->
                bookDetailBean.mReadChapter = chapterBean.content
                bookDetailBean.mReadChapterTitle = chapterBean.chapterTitle
                bookDetailBean.mReadChapterSeqNum = chapterBean.seqNum
                bookDetailBean.resume = Constants.CHINESE_PARAGRAPH_SPACE.plus(bookDetailBean.resume)
                bookDetailBean
            })
        } else {
            curChapter.map { chapterBean: ChapterBean ->
                mBookDetailBean.mReadChapter = chapterBean.content
                mBookDetailBean.mReadChapterTitle = chapterBean.chapterTitle
                mBookDetailBean.resume = Constants.CHINESE_PARAGRAPH_SPACE.plus(mBookDetailBean.resume)
                mBookDetailBean
            }
        }.map { bookDetailBean: BookDetailBean ->
            val shelfBean: BookShelfBean? = BookShelfHelper.getsInstance().findBookById(bookDetailBean.bookId)
            if (shelfBean != null) {
                updateShelfBook(bookDetailBean, shelfBean)
            }
            bookDetailBean.mIsInShelf = shelfBean != null

            updateBookRecord(bookDetailBean)
            bookDetailBean
        }
    }

    private fun updateShelfBook(bookDetailBean: BookDetailBean, bookShelfBean: BookShelfBean) {
        bookShelfBean.bookName = bookDetailBean.bookName
        bookShelfBean.author = bookDetailBean.author
        bookShelfBean.resume = bookDetailBean.resume
        bookShelfBean.bookCover = bookDetailBean.bookCover
        bookShelfBean.chapterCount = bookDetailBean.chapterCount
        bookShelfBean.wordCount = bookDetailBean.wordCount
        bookShelfBean.isFinish = bookDetailBean.isFinish
        bookShelfBean.updateTime = bookDetailBean.updateTime
        BookShelfHelper.getsInstance().updateBook(bookShelfBean)
    }

    private fun updateBookRecord(bookDetailBean: BookDetailBean) {
        val bookRecordBean: BookRecordBean? = BookRecordHelper.getsInstance().findBookRecordById(mBookDetailBean.bookId)
        if (bookRecordBean != null) {
            bookRecordBean.bookName = bookDetailBean.bookName
            bookRecordBean.author = bookDetailBean.author
            bookRecordBean.resume = bookDetailBean.resume
            bookRecordBean.bookCover = bookDetailBean.bookCover
            bookRecordBean.chapterCount = bookDetailBean.chapterCount
            bookRecordBean.wordCount = bookDetailBean.wordCount
            bookRecordBean.isFinish = bookDetailBean.isFinish
            bookRecordBean.updateTime = bookDetailBean.updateTime
            BookRecordHelper.getsInstance().updateRecordBook(bookRecordBean, false)
        }
    }

    override fun onPageDataUpdated(pageData: BookDetailBean, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        mPage.showPage(pageData)
    }

    private var mIsUpdate: Boolean = false

    private var mIsSaved: Boolean = false

    @SuppressLint("CheckResult")
    fun saveBookReadRecord(bookDetailBean: BookDetailBean) {
        if (mIsUpdate || mIsSaved) {
            return
        }

        mIsUpdate = true
        Single.fromCallable {
            val bookRecordBean = BookRecordBean()
            bookRecordBean.bookId = bookDetailBean.bookId
            bookRecordBean.bookName = bookDetailBean.bookName
            bookRecordBean.author = bookDetailBean.author
            bookRecordBean.resume = bookDetailBean.resume
            bookRecordBean.bookCover = bookDetailBean.bookCover
            bookRecordBean.chapterCount = bookDetailBean.chapterCount
            bookRecordBean.wordCount = bookDetailBean.wordCount
            bookRecordBean.isFinish = bookDetailBean.isFinish
            bookRecordBean.updateTime = bookDetailBean.updateTime
            bookRecordBean.lastRead = StringUtils.dateConvert(System.currentTimeMillis(), ReadConstant.FORMAT_BOOK_DATE)
            bookRecordBean.seqNum = bookDetailBean.mReadChapterSeqNum + 1
            bookRecordBean.pagePos = 0
            BookRecordHelper.getsInstance().saveRecordBook(bookRecordBean, false)

            true
        }.subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(Consumer<Boolean> {
            mPage.setReadBtnNext()
        })
    }

    @SuppressLint("CheckResult")
    fun updateReadChapter(bookDetailBean: BookDetailBean) {
        Api.chapter().getDetailBySeqNum(bookDetailBean.mReadChapterSeqNum, bookDetailBean.bookId).build().onErrorReturnItem(ChapterUrlBean())
                .map { chapterUrlBean ->
                    val secret = chapterUrlBean.secret
                    val content = chapterUrlBean.content
                    chapterUrlBean.url = DecryptUtils.decryptUrl(secret, content)
                    chapterUrlBean
                }.onErrorReturnItem(ChapterUrlBean()).map { chapterUrlBean ->
                    var content = if (TextUtils.isEmpty(chapterUrlBean.url)) Constants.EMPTY else ChapterContentLoadUtils.loadContent(chapterUrlBean.url)
                    content = if (content.startsWith(Constants.CHINESE_PARAGRAPH_SPACE, false)) content else Constants.CHINESE_PARAGRAPH_SPACE.plus(content)
                    try {
                        content = content.replace(Regex("\n{3,}|\n"), "\n".plus("\n").plus(Constants.CHINESE_PARAGRAPH_SPACE))
                    } catch (e: Exception) {
                    }
                    val chapterBean = ChapterBean()
                    chapterBean.chapterId = chapterUrlBean.chapterId
                    chapterBean.content = content
                    chapterBean.seqNum = chapterUrlBean.seqNum
                    chapterBean.bookId = chapterUrlBean.bookId
                    chapterBean.chapterTitle = chapterUrlBean.chapterTitle
                    chapterBean
                }.flatMap {
                    bookDetailBean.mReadChapter = it.content
                    bookDetailBean.mReadChapterTitle = it.chapterTitle
                    bookDetailBean.mReadChapterSeqNum = it.seqNum
                    Single.just(bookDetailBean)
                }.subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(Consumer<BookDetailBean> {
                    mPage.refreshChapter(it)
                })
    }

    private var mIsAdding: Boolean = false
    @SuppressLint("CheckResult")
    fun addBookToShelf(mBookDetailBean: BookDetailBean) {
        if (mIsAdding || mBookDetailBean.mIsInShelf) {
            return
        }
        mIsAdding = true
        val shelfBean = BookShelfBean(mBookDetailBean.bookId, mBookDetailBean.bookName,
                mBookDetailBean.bookCover, mBookDetailBean.resume, mBookDetailBean.chapterCount,
                mBookDetailBean.wordCount, mBookDetailBean.isFinish, mBookDetailBean.updateTime,
                mBookDetailBean.currTime, System.currentTimeMillis(), mBookDetailBean.author)

        Single.fromCallable {
            BookShelfHelper.getsInstance().saveBook(shelfBean)
            true
        }.subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(Consumer<Boolean> {
            mPage.addShelfSuccess()
        })
    }

    fun setBookDetailBean(bookDetailBean: BookDetailBean) {
        mBookDetailBean = bookDetailBean;
    }
}