package com.zymh.ebk.read.setting;


import com.zydm.base.utils.SPUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.ebk.read.R;
import com.zymh.ebk.read.utils.ScreenUtils;


public class ReadSettingManager {
    public static final int READ_BG_0 = 0;
    public static final int READ_BG_1 = 1;
    public static final int READ_BG_2 = 2;
    public static final int READ_BG_3 = 3;
    public static final int NIGHT_MODE = 5;
    public int[] colorBg = {R.color.read_page_bg_01, R.color.read_page_bg_02,
            R.color.read_page_bg_03, R.color.read_page_bg_04};

    public int[] colorTip = {R.color.read_page_tip_01, R.color.read_page_tip_02,
            R.color.read_page_tip_03, R.color.read_page_tip_04};

    public static final String SHARED_READ_BG = "shared_read_bg";
    public static final String SHARED_READ_BRIGHTNESS = "shared_read_brightness";
    public static final String SHARED_READ_IS_BRIGHTNESS_AUTO = "shared_read_is_brightness_auto";
    public static final String SHARED_READ_TEXT_SIZE = "shared_read_text_size";
    public static final String SHARED_READ_IS_TEXT_DEFAULT = "shared_read_text_default";
    public static final String SHARED_READ_NIGHT_MODE = "shared_night_mode";
    public static final String SHARED_READ_VOLUME_TURN_PAGE = "shared_read_volume_turn_page";
    public static final String SHARED_READ_FULL_SCREEN = "shared_read_full_screen";

    private static volatile ReadSettingManager sInstance;

    public static ReadSettingManager getInstance() {
        if (sInstance == null) {
            synchronized (ReadSettingManager.class) {
                if (sInstance == null) {
                    sInstance = new ReadSettingManager();
                }
            }
        }
        return sInstance;
    }

    private ReadSettingManager() {
    }

    public void setReadBackground(int theme) {
        SPUtils.INSTANCE.putInt(SHARED_READ_BG, theme);
    }

    public void setBrightness(int progress) {
        SPUtils.INSTANCE.putInt(SHARED_READ_BRIGHTNESS, progress);
    }

    public void setAutoBrightness(boolean isAuto) {
        SPUtils.INSTANCE.putBoolean(SHARED_READ_IS_BRIGHTNESS_AUTO, isAuto);
    }

    public void setDefaultTextSize(boolean isDefault) {
        SPUtils.INSTANCE.putBoolean(SHARED_READ_IS_TEXT_DEFAULT, isDefault);
    }

    public void setTextSize(int textSize) {
        SPUtils.INSTANCE.putInt(SHARED_READ_TEXT_SIZE, textSize);
    }

    public void setNightMode(boolean isNight) {
        SPUtils.INSTANCE.putBoolean(SHARED_READ_NIGHT_MODE, isNight);
    }

    public int getBrightness() {
        return SPUtils.INSTANCE.getInt(SHARED_READ_BRIGHTNESS, -1);
    }

    public boolean isBrightnessAuto() {
        return SPUtils.INSTANCE.getBoolean(SHARED_READ_IS_BRIGHTNESS_AUTO, true);
    }

    public int getTextSize() {
        return SPUtils.INSTANCE.getInt(SHARED_READ_TEXT_SIZE, ViewUtils.dp2px(16.5f));
    }

    public boolean isDefaultTextSize() {
        return SPUtils.INSTANCE.getBoolean(SHARED_READ_IS_TEXT_DEFAULT, false);
    }

    public int getReadBgTheme() {
        return SPUtils.INSTANCE.getInt(SHARED_READ_BG, READ_BG_0);
    }

    public boolean isNightMode() {
        return SPUtils.INSTANCE.getBoolean(SHARED_READ_NIGHT_MODE, false);
    }

    public void setVolumeTurnPage(boolean isTurn) {
        SPUtils.INSTANCE.putBoolean(SHARED_READ_VOLUME_TURN_PAGE, isTurn);
    }

    public boolean isVolumeTurnPage() {
        return SPUtils.INSTANCE.getBoolean(SHARED_READ_VOLUME_TURN_PAGE, false);
    }

    public void setFullScreen(boolean isFullScreen) {
        SPUtils.INSTANCE.putBoolean(SHARED_READ_FULL_SCREEN, isFullScreen);
    }

    public boolean isFullScreen() {
        return SPUtils.INSTANCE.getBoolean(SHARED_READ_FULL_SCREEN, false);
    }
}
