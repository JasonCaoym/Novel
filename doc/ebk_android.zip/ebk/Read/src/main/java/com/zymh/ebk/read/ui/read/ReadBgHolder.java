package com.zymh.ebk.read.ui.read;

import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.zydm.base.ui.item.AbsItemView;
import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.CircleImageView;
import com.zydm.base.widgets.CornerDrawable;
import com.zydm.ebk.read.R;
import com.zymh.ebk.read.dao.ReadBgBean;


public class ReadBgHolder extends AbsItemView<ReadBgBean> {

    private ImageView mBg;
    private ViewGroup mParent;

    @Override
    public void onCreate() {
        setContentView(R.layout.item_read_bg);
        mBg = findView(R.id.read_bg_view);
        mParent = findView(R.id.parent);
        mItemView.setOnClickListener(this);
    }

    @Override
    public void onSetData(boolean isFirstSetData, boolean isPosChanged, boolean isDataChanged) {
        ReadBgBean readBgBean = getMItemData();
        CornerDrawable drawable = new CornerDrawable();
        int corner = ViewUtils.dp2px(12);
        drawable.setRadius(corner, corner, corner, corner, corner, corner, corner, corner);
        drawable.setColor(ViewUtils.getColor(readBgBean.getBgColor()));
        drawable.mutate();
        mBg.setImageDrawable(drawable);
        if (readBgBean.isSelect()) {
            CornerDrawable bg = new CornerDrawable();
            int cornerBg = ViewUtils.dp2px(12.5f);
            bg.setRadius(cornerBg, cornerBg, cornerBg, cornerBg, cornerBg, cornerBg, cornerBg, cornerBg);
            bg.setColor(ViewUtils.getColor(R.color.standard_red_main_color_c1));
            mParent.setBackground(bg);
        } else {
            mParent.setBackground(null);
        }
    }
}
