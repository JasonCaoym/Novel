package com.zymh.ebk.read.ui.bookshelf

import android.view.View
import android.widget.RelativeLayout
import com.zydm.base.ext.setVisible
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.ebk.provider.data.AdData
import com.zydm.ebk.read.R
import kotlinx.android.synthetic.main.book_shelf_image_ad_layout.view.*

class ImageAd : AbsItemView<AdData>() {

    override fun onCreate() {
        setContentView(R.layout.book_shelf_image_ad_layout)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        val hasAd = AdMgr.isShowAd(AdMgr.AD_BOOK_SHELF)
        if (!hasAd) {
            mItemView.ad_layout.removeAllViews()
            mItemView.ad_layout.setVisible(false)
            mItemView.setVisible(false)
            return
        }
        mItemView.ad_layout.setVisible(true)
        if (isFirstSetData) {
            mItemView.ad_layout.init(mItemData.mIAdHelper, AdMgr.getAdParam(mItemData.mAdPos, mItemData.mStType), false)
        }
    }

    override fun setContentView(view: View) {
        super.setContentView(view)
        mItemView.ad_layout.supportNightMode(false)
        mItemView.ad_layout.setOnHeightConfirmListener {

        }
    }
}