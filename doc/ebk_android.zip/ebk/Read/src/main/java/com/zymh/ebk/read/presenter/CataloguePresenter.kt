package com.zymh.ebk.read.presenter

import com.zydm.base.presenter.view.ISimplePageView
import com.zydm.base.presenter.AbsPagePresenter
import com.zymh.ebk.read.data.bean.BookDetailBean
import com.zymh.ebk.read.data.api.Api
import com.zymh.ebk.read.dao.ChapterListBean
import com.zymh.ebk.read.utils.BookChapterHelper
import com.zymh.ebk.read.utils.StringUtils
import io.reactivex.Single

class CataloguePresenter(private val mBookBean: BookDetailBean, private val pageView: ISimplePageView<ChapterListBean>) : AbsPagePresenter<ChapterListBean>(pageView) {
    private var mGroup: Int = 0

    init {
        mGroup = if (mBookBean.mReadChapterSeqNum % 50 == 0) mBookBean.mReadChapterSeqNum / 50 - 1 else mBookBean.mReadChapterSeqNum / 50
    }

    override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<out ChapterListBean> {
        val startSeqNum = mGroup * 50 + 1
        return Api.chapter().getList(mBookBean.bookId, 50, 1, startSeqNum).build()
                .map { chapterListBean ->
                    val chapterBeans = BookChapterHelper.getsInstance().findBookChapters(mBookBean.bookId)
                    for (chapterBean in chapterListBean.list) {
                        for (readBean in chapterBeans) {
                            if (chapterBean.chapterId == readBean.chapterId) {
                                chapterBean.isRead = true
                            }
                        }
                        chapterBean.chapterTitle = StringUtils.convertChapterTitle(chapterBean.chapterTitle, chapterBean.seqNum)
                    }
                    val firstSeqNum = chapterListBean.list[0].seqNum
                    chapterListBean.mGroupIndex = if (firstSeqNum % 50 == 0) firstSeqNum / 50 - 1 else firstSeqNum / 50
                    chapterListBean
                }
    }

    override fun onPageDataUpdated(pageData: ChapterListBean, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        pageView.showPage(pageData)
    }

    fun setGroup(group: Int) {
        mGroup = group
        loadPageData(true)
    }
}