package com.zymh.ebk.read.presenter

import android.annotation.SuppressLint
import android.util.Log
import com.zydm.base.data.base.IIdGetter
import com.zydm.base.data.tools.JsonUtils
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.utils.SPUtils
import com.zydm.base.utils.TimeUtils
import com.zymh.ebk.read.data.api.Api
import com.zymh.ebk.read.dao.*
import com.zymh.ebk.read.data.api.definition.RecommendApi
import com.zymh.ebk.read.data.bean.BookUpdatesListBean
import com.zymh.ebk.read.data.bean.TextAdListBean
import com.zymh.ebk.read.presenter.view.IBookShelfPage
import io.reactivex.Single
import io.reactivex.functions.BiFunction
import io.reactivex.functions.Function

class BookShelfPresenter(private val mPage: IBookShelfPage) : AbsPagePresenter<ArrayList<Any>>(mPage) {

    companion object {
        val LAST_REC_TIME = "last_rec_time"
    }

    @SuppressLint("CheckResult")
    override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<ArrayList<Any>> {
        val textAdListBean = TextAdListBean()
        val textAd: Single<TextAdListBean> = Api.recommend().recTexts(5, RecommendApi.REC_TEXT_TYPE_SHELF).build().onErrorReturnItem(textAdListBean)

        val bookList: Single<ShelfBookListBean> = Single.fromCallable {
            val shelfBookList = BookShelfHelper.getsInstance().findAllBooks()
            val shelfBookListBean = ShelfBookListBean()
            shelfBookListBean.list.addAll(shelfBookList)
            for (item in shelfBookListBean.list) {
                item.mIsInShelf = true;
            }
            shelfBookListBean
        }.flatMap(object : Function<ShelfBookListBean, Single<ShelfBookListBean>> {
            override fun apply(t: ShelfBookListBean): Single<ShelfBookListBean> {
                val lastRecTime = SPUtils.getLong(LAST_REC_TIME, 0)
                val needRec = System.currentTimeMillis() - lastRecTime > TimeUtils.DAY_1 * 3
                val shelfData = if (t.list.size >= 6 || !needRec) Single.just(t) else Api.recommend().recBooks(18, RecommendApi.REC_BOOK_TYPE_SHELF).build().map(object : Function<BookRecordListBean, ShelfBookListBean> {
                    override fun apply(it: BookRecordListBean): ShelfBookListBean {
                        SPUtils.putLong(LAST_REC_TIME, System.currentTimeMillis())
                        it.list.forEach {
                            if (!hasBook(t, it) && t.list.size < 6) {
                                val bookShelfBean = BookShelfBean()
                                bookShelfBean.bookId = it.bookId
                                bookShelfBean.bookName = it.bookName
                                bookShelfBean.author = it.author
                                bookShelfBean.resume = it.resume
                                bookShelfBean.bookCover = it.bookCover
                                bookShelfBean.chapterCount = it.chapterCount
                                bookShelfBean.wordCount = it.wordCount
                                bookShelfBean.isFinish = it.isFinish
                                bookShelfBean.updateTime = it.updateTime
                                bookShelfBean.mIsInShelf = true
                                bookShelfBean.addTime = 0
                                BookShelfHelper.getsInstance().saveBook(bookShelfBean)
                                t.list.add(bookShelfBean)
                            }
                        }
                        return t
                    }

                })
                return shelfData.flatMap(object : Function<ShelfBookListBean, Single<ShelfBookListBean>> {
                    override fun apply(it: ShelfBookListBean): Single<ShelfBookListBean> {
                        val ids: ArrayList<IIdGetter> = ArrayList()
                        for (bookShelfBean in it.list) {
                            if (!bookShelfBean.isFinish) {
                                ids.add(bookShelfBean)
                            }
                        }
                        val bookIds = JsonUtils.extractIdToJsonArray(ids)
                        val bookListWithUpdate: Single<ShelfBookListBean> = Api.book().booksUpdateState(bookIds).build().map { bookUpdatesListBean: BookUpdatesListBean ->
                            for (bookUpdatesBean in bookUpdatesListBean.list) {
                                for (bookShelfBean in it.list) {
                                    if (bookShelfBean.bookId == bookUpdatesBean.bookId) {
                                        Log.i("ggg", "updateCount:" + bookUpdatesBean.chapterCount + "...curCount:" + bookShelfBean.chapterCount + "...updateTime:" + bookUpdatesBean.updateTime + "...curTime:" + bookShelfBean.updateTime)
                                        if (bookUpdatesBean.chapterCount > bookShelfBean.chapterCount || bookUpdatesBean.updateTime > bookShelfBean.updateTime) {
                                            bookShelfBean.mIsUpdate = true
                                            bookShelfBean.chapterCount = bookUpdatesBean.chapterCount
                                            bookShelfBean.updateTime = bookUpdatesBean.updateTime
                                        }
                                    }
                                }
                            }
                            it
                        }
                        return bookListWithUpdate
                    }

                })


            }

        })
        return Single.zip(textAd, bookList, BiFunction
        { t1, t2 ->
            val list: ArrayList<Any> = ArrayList()
            list.add(t1)
            list.add(t2)
            list
        })
    }

    override fun onPageDataUpdated(pageData: ArrayList<Any>, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        mPage.showPage(pageData)
    }

    private fun hasBook(shelfBookListBean: ShelfBookListBean, bookRecordBean: BookRecordBean): Boolean {
        shelfBookListBean.list.forEach {
            if (it.bookId == bookRecordBean.bookId) {
                return true
            }
        }
        return false
    }
}

