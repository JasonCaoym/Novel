package com.zymh.ebk.read.page;

import java.util.List;

public class TxtPage {
    int position;
    String title;
    int titleLines;
    List<String> lines;
    public boolean isExtraAfterBook;
    public boolean isExtraAfterChapter;
}
