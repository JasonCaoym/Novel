package com.zymh.ebk.read.presenter;

import android.annotation.SuppressLint;
import android.text.TextUtils;
import android.util.Log;

import com.zydm.base.rx.MtSchedulers;
import com.zydm.base.utils.ToastUtils;
import com.zydm.ebk.read.R;
import com.zymh.ebk.read.data.api.Api;
import com.zymh.ebk.read.dao.BookRecordBean;
import com.zymh.ebk.read.dao.BookShelfBean;
import com.zymh.ebk.read.dao.BookShelfHelper;
import com.zymh.ebk.read.dao.ChapterListBean;
import com.zymh.ebk.read.dao.ChapterBean;
import com.zymh.ebk.read.data.bean.BookDetailBean;
import com.zymh.ebk.read.data.bean.ChapterUrlBean;
import com.zymh.ebk.read.page.TxtChapter;
import com.zymh.ebk.read.presenter.view.IReadPage;
import com.zymh.ebk.read.utils.BookChapterHelper;
import com.zymh.ebk.read.utils.BookManager;
import com.zymh.ebk.read.utils.BookRecordHelper;
import com.zymh.ebk.read.utils.BookSaveUtils;
import com.zymh.ebk.read.utils.ChapterContentLoadUtils;
import com.zymh.ebk.read.utils.DecryptUtils;
import com.zymh.ebk.read.utils.StringUtils;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.Callable;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.SingleSource;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Action;
import io.reactivex.functions.BiFunction;
import io.reactivex.functions.Consumer;
import io.reactivex.functions.Function;


public class ReadPresenter {

    //滚动目录到顶部触发加载目录
    public static final int LOAD_CATALOGUE_TYPE_TOP_MORE = 0;
    //滚动目录到底部触发加载目录
    public static final int LOAD_CATALOGUE_TYPE_BOTTOM_MORE = 1;
    //点击倒序触发加载目录
    public static final int LOAD_CATALOGUE_TYPE_REVERSE = 2;
    //点击正序触发加载目录
    public static final int LOAD_CATALOGUE_TYPE_POSITIVE = 3;
    //首次进入触发加载用户上一次阅读的目录
    public static final int LOAD_CATALOGUE_TYPE_NORMAL = 4;
    //用户阅读时触发预加载目录
    public static final int LOAD_CATALOGUE_TYPE_PRE = 5;


    private IReadPage mIReadPage;

    private Disposable mDisposable;
    //仅用来标记获取章节内容是否成功
    private int chapter;
    private HashSet<Integer> mPreLoadingGroup = new HashSet<>();

    public ReadPresenter(IReadPage mIReadPage) {
        this.mIReadPage = mIReadPage;
    }

    public void loadRecordedChaptersGroup(final String bookId, final int targetSeqNum) {
        Single.fromCallable(new Callable<BookRecordBean>() {
            @Override
            public BookRecordBean call() throws Exception {
                return BookRecordHelper.getsInstance().findBookRecordById(bookId);
            }
        }).onErrorReturnItem(new BookRecordBean()).flatMap(new Function<BookRecordBean, SingleSource<BookRecordBean>>() {
            @Override
            public SingleSource<BookRecordBean> apply(BookRecordBean bookRecordBean) throws Exception {
                if (!TextUtils.isEmpty(bookRecordBean.getBookId())) {
                    if (targetSeqNum != 0) {
                        bookRecordBean.setSeqNum(targetSeqNum);
                        bookRecordBean.setPagePos(0);
                    }
                    return Single.just(bookRecordBean);
                }
                return Api.INSTANCE.book().getDetail(bookId).build().map(new Function<BookDetailBean, BookRecordBean>() {
                    @Override
                    public BookRecordBean apply(BookDetailBean bookDetailBean) throws Exception {
                        BookRecordBean bookRecordBean = new BookRecordBean();
                        bookRecordBean.bookId = bookDetailBean.getBookId();
                        bookRecordBean.bookName = bookDetailBean.getBookName();
                        bookRecordBean.author = bookDetailBean.getAuthor();
                        bookRecordBean.resume = bookDetailBean.getResume();
                        bookRecordBean.bookCover = bookDetailBean.getBookCover();
                        bookRecordBean.chapterCount = bookDetailBean.getChapterCount();
                        bookRecordBean.wordCount = bookDetailBean.getWordCount();
                        bookRecordBean.isFinish = bookDetailBean.isFinish();
                        bookRecordBean.updateTime = bookDetailBean.getUpdateTime();
                        bookRecordBean.setSeqNum(targetSeqNum == 0 ? 1 : targetSeqNum);
                        bookRecordBean.setPagePos(0);
                        return bookRecordBean;
                    }
                });
            }
        }).map(new Function<BookRecordBean, BookRecordBean>() {
            @Override
            public BookRecordBean apply(BookRecordBean recordBean) throws Exception {
                BookShelfBean shelfBean = BookShelfHelper.getsInstance().findBookById(recordBean.getBookId());
                recordBean.mIsInShelf = shelfBean != null;
                return recordBean;
            }
        }).flatMap(new Function<BookRecordBean, SingleSource<List<ChapterListBean>>>() {
            @Override
            public SingleSource<List<ChapterListBean>> apply(final BookRecordBean recordBean) throws Exception {
                int lastReadSeqNum = recordBean.getSeqNum();
                int remain = lastReadSeqNum % 50;
                int startSeqNum = remain != 0 ? lastReadSeqNum - remain + 1 : lastReadSeqNum - 50 + 1;
                Single<ChapterListBean> curChapterListSingle = createChapterListSingle(recordBean, startSeqNum, bookId);
                if (lastReadSeqNum % 50 > 0 && lastReadSeqNum % 50 < 3 && startSeqNum > 50) {
                    int preSeqNum = startSeqNum - 50;
                    return Single.zip(curChapterListSingle, createChapterListSingle(recordBean, preSeqNum, bookId), new BiFunction<ChapterListBean, ChapterListBean, List<ChapterListBean>>() {
                        @Override
                        public List<ChapterListBean> apply(ChapterListBean chapterListBean, ChapterListBean chapterListBean2) throws Exception {
                            ArrayList<ChapterListBean> list = new ArrayList<>();
                            list.add(chapterListBean);
                            if (chapterListBean2.getList().size() != 0) {
                                list.add(chapterListBean2);
                            }
                            return list;
                        }
                    });
                } else if ((lastReadSeqNum % 50 == 0 || lastReadSeqNum % 50 > 48) && startSeqNum < recordBean.chapterCount - 50) {
                    int nextSeqNum = startSeqNum + 50;
                    return Single.zip(curChapterListSingle, createChapterListSingle(recordBean, nextSeqNum, bookId), new BiFunction<ChapterListBean, ChapterListBean, List<ChapterListBean>>() {
                        @Override
                        public List<ChapterListBean> apply(ChapterListBean chapterListBean, ChapterListBean chapterListBean2) throws Exception {
                            ArrayList<ChapterListBean> list = new ArrayList<>();
                            list.add(chapterListBean);
                            if (chapterListBean2.getList().size() != 0) {
                                list.add(chapterListBean2);
                            }
                            return list;
                        }
                    });
                } else {
                    return curChapterListSingle.flatMap(new Function<ChapterListBean, SingleSource<? extends List<ChapterListBean>>>() {
                        @Override
                        public SingleSource<? extends List<ChapterListBean>> apply(ChapterListBean chapterListBean) throws Exception {
                            ArrayList<ChapterListBean> list = new ArrayList<>();
                            list.add(chapterListBean);
                            return Single.just(list);
                        }
                    });
                }
            }
        }).subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi())
                .subscribe(new SingleObserver<List<ChapterListBean>>() {
                    @Override
                    public void onSubscribe(Disposable d) {

                    }

                    @Override
                    public void onSuccess(List<ChapterListBean> chapterBean) {
                        mIReadPage.loadBookChaptersSuccess(chapterBean);
                    }

                    @Override
                    public void onError(Throwable e) {
                        ToastUtils.showLimited(R.string.no_book);
                        mIReadPage.loadChapterContentsFailed();
                    }
                });
    }

    private Single<ChapterListBean> createChapterListSingle(final BookRecordBean recordBean, int startSeqNum, final String bookId) {
        return Api.INSTANCE.chapter().getList(bookId, 50, 1, startSeqNum).build().map(new Function<ChapterListBean, ChapterListBean>() {
            @Override
            public ChapterListBean apply(ChapterListBean chapterListBean) throws Exception {
                chapterListBean.mOwnBook = recordBean;
                return chapterListBean;
            }
        }).map(new Function<ChapterListBean, ChapterListBean>() {
            @Override
            public ChapterListBean apply(ChapterListBean chapterListBean) throws Exception {
                List<ChapterBean> chapterBeans = BookChapterHelper.getsInstance().findBookChapters(bookId);
                for (ChapterBean chapterBean : chapterListBean.getList()) {
                    for (ChapterBean readBean : chapterBeans) {
                        if (chapterBean.chapterId == readBean.chapterId) {
                            chapterBean.isRead = true;
                        }
                    }
                    chapterBean.bookId = bookId;
                    chapterBean.chapterTitle = StringUtils.convertChapterTitle(chapterBean.chapterTitle, chapterBean.seqNum);
                }
                int firstSeqNum = chapterListBean.getList().get(0).seqNum;
                chapterListBean.mGroupIndex = firstSeqNum % 50 == 0 ? firstSeqNum / 50 - 1 : firstSeqNum / 50;
                return chapterListBean;
            }
        });
    }

    @SuppressLint("CheckResult")
    public void preLoadChaptersGroup(final String bookId, final int groupPos) {
        if (mPreLoadingGroup.contains(groupPos)) {
            return;
        }
        mPreLoadingGroup.add(groupPos);
        int startSeqNum = groupPos * 50 + 1;
        Api.INSTANCE.chapter().getList(bookId, 50, 1, startSeqNum).build().map(new Function<ChapterListBean, ChapterListBean>() {
            @Override
            public ChapterListBean apply(ChapterListBean chapterListBean) throws Exception {
                List<ChapterBean> chapterBeans = BookChapterHelper.getsInstance().findBookChapters(bookId);
                for (ChapterBean chapterBean : chapterListBean.getList()) {
                    for (ChapterBean readBean : chapterBeans) {
                        if (chapterBean.chapterId == readBean.chapterId) {
                            chapterBean.isRead = true;
                        }
                    }
                    chapterBean.bookId = bookId;
                    chapterBean.chapterTitle = StringUtils.convertChapterTitle(chapterBean.chapterTitle, chapterBean.seqNum);
                }
                chapterListBean.mGroupIndex = groupPos;
                return chapterListBean;
            }
        }).subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(new SingleObserver<ChapterListBean>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onSuccess(ChapterListBean chapterBean) {
                mIReadPage.preLoadBookChaptersSuccess(chapterBean, groupPos);
                mPreLoadingGroup.remove(groupPos);
            }

            @Override
            public void onError(Throwable e) {
                mPreLoadingGroup.remove(groupPos);
                Log.i("ggg", e.toString(), new Throwable());
            }
        });
    }

    @SuppressLint("CheckResult")
    public void loadContent(final String bookId, final List<TxtChapter> bookChapterList) {
        int size = bookChapterList.size();
        if (size == 0) {
            return;
        }
        //取消上次的任务，防止多次加载
        if (mDisposable != null) {
            mDisposable.dispose();
        }
        final List<Observable<ChapterBean>> chapterContentBeans = new ArrayList<>(bookChapterList.size());
        final ArrayDeque<Integer> chapters = new ArrayDeque<>(bookChapterList.size());
        //首先判断是否Chapter已经存在
        for (int i = 0; i < size; i++) {
            final TxtChapter bookChapter = bookChapterList.get(i);
            if (!(BookManager.isChapterCached(bookId, bookChapter.getTitle()))) {
                Observable<ChapterBean> content = Api.INSTANCE.chapter().getDetailBySeqNum(bookChapter.seqNum, bookChapter.getBookId()).build()
                        .map(new Function<ChapterUrlBean, ChapterUrlBean>() {
                            @Override
                            public ChapterUrlBean apply(ChapterUrlBean chapterUrlBean) throws Exception {
                                if (!"txt".equalsIgnoreCase(chapterUrlBean.format)) {
                                    throw new IllegalBookFormatException("not txt");
                                }
                                String secret = chapterUrlBean.secret;
                                String content = chapterUrlBean.content;
                                chapterUrlBean.seqNum = bookChapter.seqNum;
                                chapterUrlBean.chapterId = bookChapter.chapterId;
                                chapterUrlBean.url = DecryptUtils.decryptUrl(secret, content);
                                return chapterUrlBean;
                            }
                        }).map(new Function<ChapterUrlBean, ChapterBean>() {
                            @Override
                            public ChapterBean apply(ChapterUrlBean chapterUrlBean) throws Exception {
                                String content = ChapterContentLoadUtils.loadContent(chapterUrlBean.url);
                                ChapterBean chapterBean = new ChapterBean();
                                chapterBean.chapterId = chapterUrlBean.chapterId;
                                chapterBean.content = content;
                                chapterBean.seqNum = chapterUrlBean.seqNum;
                                chapterBean.bookId = chapterUrlBean.bookId;
                                chapterBean.chapterTitle = chapterUrlBean.chapterTitle;
                                return chapterBean;
                            }
                        }).toObservable();
                chapterContentBeans.add(content);
                chapters.add(bookChapter.chapterId);
            } else if (i == 0) {
                //如果已经存在，再判断是不是我们需要的下一个章节，如果是才返回加载成功
                if (mIReadPage != null) {
                    mIReadPage.loadChapterContentsSuccess();
                }
            }
        }
        if (chapters.size() == 0) {
            return;
        }
        chapter = chapters.poll();
        Observable.concat(chapterContentBeans)
                .subscribeOn(MtSchedulers.io())
                .observeOn(MtSchedulers.mainUi())
                .subscribe(new Consumer<ChapterBean>() {
                    @Override
                    public void accept(ChapterBean chapterBean) throws Exception {
                        BookSaveUtils.saveChapterInfo(bookId, chapter + "", chapterBean.content);
                        mIReadPage.loadChapterContentsSuccess();
                        chapter = chapters.size() == 0 ? 0 : chapters.poll();
                    }
                }, new Consumer<Throwable>() {
                    @Override
                    public void accept(Throwable throwable) throws Exception {
                        if (bookChapterList.get(0).chapterId == chapter) {
                            mIReadPage.loadChapterContentsFailed();
                        }

                        if (throwable instanceof IllegalBookFormatException) {
                            ToastUtils.showLimited(R.string.not_support_format);
                        }
                    }
                }, new Action() {
                    @Override
                    public void run() throws Exception {
                        Log.i("ggg", "Action");
                    }
                }, new Consumer<Disposable>() {
                    @Override
                    public void accept(Disposable subscription) throws Exception {
                        mDisposable = subscription;
                    }
                });
    }

    @SuppressLint("CheckResult")
    public void addBookToShelf(BookRecordBean recordBean) {
        BookShelfBean shelfBean = new BookShelfBean(recordBean.bookId, recordBean.bookName,
                recordBean.bookCover, recordBean.resume, recordBean.chapterCount,
                recordBean.wordCount, recordBean.isFinish, recordBean.updateTime,
                0, System.currentTimeMillis(), recordBean.author);
        BookShelfHelper.getsInstance().saveBookWithAsync(shelfBean);
    }

    @SuppressLint("CheckResult")
    public void loadCatalogue(final String bookId, final int chapterCount, final int groupPos, final int type) {
        if (mPreLoadingGroup.contains(groupPos)) {
            return;
        }
        mPreLoadingGroup.add(groupPos);
        final int startSeqNum = groupPos * 50 + 1;
        Observable<ChapterListBean> cur = Api.INSTANCE.chapter().getList(bookId, 50, 1, startSeqNum).build().map(new Function<ChapterListBean, ChapterListBean>() {
            @Override
            public ChapterListBean apply(ChapterListBean chapterListBean) throws Exception {
                List<ChapterBean> chapterBeans = BookChapterHelper.getsInstance().findBookChapters(bookId);
                for (ChapterBean chapterBean : chapterListBean.getList()) {
                    for (ChapterBean readBean : chapterBeans) {
                        if (chapterBean.chapterId == readBean.chapterId) {
                            chapterBean.isRead = true;
                        }
                    }
                    chapterBean.bookId = bookId;
                    chapterBean.chapterTitle = StringUtils.convertChapterTitle(chapterBean.chapterTitle, chapterBean.seqNum);
                }
                chapterListBean.mGroupIndex = groupPos;
                return chapterListBean;
            }
        }).toObservable();
        if (type == LOAD_CATALOGUE_TYPE_REVERSE && chapterCount - startSeqNum < 25) {
            int preGroupPos = groupPos - 1;
            int preStartSeqNum = preGroupPos * 50 + 1;
            Observable<ChapterListBean> pre = Api.INSTANCE.chapter().getList(bookId, 50, 1, preStartSeqNum).build().map(new Function<ChapterListBean, ChapterListBean>() {
                @Override
                public ChapterListBean apply(ChapterListBean chapterListBean) throws Exception {
                    List<ChapterBean> chapterBeans = BookChapterHelper.getsInstance().findBookChapters(bookId);
                    for (ChapterBean chapterBean : chapterListBean.getList()) {
                        for (ChapterBean readBean : chapterBeans) {
                            if (chapterBean.chapterId == readBean.chapterId) {
                                chapterBean.isRead = true;
                            }
                        }
                        chapterBean.bookId = bookId;
                        chapterBean.chapterTitle = StringUtils.convertChapterTitle(chapterBean.chapterTitle, chapterBean.seqNum);
                    }
                    chapterListBean.mGroupIndex = groupPos;
                    return chapterListBean;
                }
            }).toObservable();
            cur = Observable.concat(pre, cur);
        }
        cur.subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(new Observer<ChapterListBean>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(ChapterListBean chapterListBean) {
                int firstSeqNum = chapterListBean.getList().get(0).seqNum;
                int group = firstSeqNum % 50 == 0 ? firstSeqNum / 50 - 1 : firstSeqNum / 50;
                mIReadPage.loadCatalogueSuccess(chapterListBean, group, type);
                mPreLoadingGroup.remove(groupPos);
            }

            @Override
            public void onError(Throwable e) {
                mIReadPage.loadCatalogueFailed(groupPos, type);
                mPreLoadingGroup.remove(groupPos);
                Log.i("ggg", "1" + e.toString(), new Throwable());
            }

            @Override
            public void onComplete() {

            }
        });
    }

    private class IllegalBookFormatException extends Exception {
        public IllegalBookFormatException(String message) {
            super(message);
        }
    }
}
