package com.zymh.ebk.read.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.InflaterInputStream;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class ChapterContentLoadUtils {
    private static OkHttpClient okHttpClient = new OkHttpClient.Builder().build();

    public static String loadContent(String url) throws Exception {
        final Request request = new Request.Builder().url(url).build();
        Response response = okHttpClient.newCall(request).execute();
        return decompress(response.body().bytes());
    }

    private static String decompress(byte[] compress) throws Exception {
        ByteArrayInputStream bais = new ByteArrayInputStream(compress);
        InflaterInputStream iis = new InflaterInputStream(bais);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int c;
        byte[] buf = new byte[1024];
        while (true) {
            c = iis.read(buf);
            if (c == -1) break;
            baos.write(buf, 0, c);
        }
        baos.flush();
        return baos.toString("utf-8");
    }
}
