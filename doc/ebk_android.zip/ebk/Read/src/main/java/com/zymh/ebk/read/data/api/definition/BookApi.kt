package com.zymh.ebk.read.data.api.definition

import com.zydm.base.data.net.*
import com.zydm.base.common.ParamKey
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.data.bean.BookDetailBean
import com.zymh.ebk.read.data.bean.BookUpdatesListBean

@BasePath("/Api/Book/")
interface BookApi {

/*    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getDetail(@Param(ParamKey.BOOK_ID) bookId: String): DataSrcBuilder<BookRecordBean>*/

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getDetail(@Param(ParamKey.BOOK_ID) bookId: String): DataSrcBuilder<BookDetailBean>

    fun booksUpdateState(@Param(ParamKey.BOOK_IDS) bookIds: String): DataSrcBuilder<BookUpdatesListBean>
}
