package com.zymh.ebk.read.ui.detail

class BookDetailsFromH5Activity : BookDetailsActivity() {

}