package com.zymh.ebk.read.presenter.view

import com.zydm.base.presenter.view.IPageView

interface IBookShelfPage : IPageView {
    fun showPage(pageData: ArrayList<Any>)
}