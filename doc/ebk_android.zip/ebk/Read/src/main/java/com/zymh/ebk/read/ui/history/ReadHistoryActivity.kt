package com.zymh.ebk.read.ui.history

import android.os.Bundle
import com.zydm.base.data.bean.ListBean
import com.zydm.base.presenter.view.ISimplePageView
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.ui.activity.AbsPageActivity
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.read.R
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.presenter.HistoryPresenter
import com.zymh.ebk.read.utils.BookRecordHelper
import kotlinx.android.synthetic.main.activity_read_history.*

class ReadHistoryActivity : AbsPageActivity(), ISimplePageView<ListBean<BookRecordBean>>,
    BookRecordHelper.RecordDaoObserver {

    private val mAdapter by lazy {
        AdapterBuilder()
            .putItemClass(HistoryItemView::class.java)
            .builderListAdapter(this)
    }

    private var mDataList: ArrayList<BookRecordBean> = ArrayList()

    override fun showPage(data: ListBean<BookRecordBean>?) {
        if (data != null) {
            mDataList.addAll(data.list)
            mAdapter.setData(mDataList)
        }
    }

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<ListBean<BookRecordBean>> {
        setContentView(R.layout.activity_read_history)
        setToolBarLayout(ViewUtils.getString(R.string.read_history))
        list_view.adapter = mAdapter
        pull_layout.setCanPullDown(false)
        BookRecordHelper.getsInstance().addObserver(this)
        return HistoryPresenter(this)
    }

    override fun onRecordChange(recordBean: BookRecordBean) {
        for(i in 0 until mDataList.size) {
            if(mDataList[i].bookId == recordBean.bookId) {
                mDataList[i] = recordBean
            }
        }
        mAdapter.notifyDataSetChanged()
    }
}