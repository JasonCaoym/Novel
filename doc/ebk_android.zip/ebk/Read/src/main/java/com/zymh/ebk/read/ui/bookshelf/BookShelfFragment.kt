package com.zymh.ebk.read.ui.bookshelf

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import com.zydm.base.ext.onClick
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.rx.MtSchedulers
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.fragment.AbsPageFragment
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.ui.item.ItemListener
import com.zydm.base.ui.item.ItemListenerAdapter
import com.zydm.base.utils.CollectionUtils
import com.zydm.base.utils.SnackbarUtil
import com.zydm.base.utils.ToastUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.ebk.provider.data.AdData
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.read.R
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.dao.BookShelfBean
import com.zymh.ebk.read.dao.BookShelfHelper
import com.zymh.ebk.read.dao.ShelfBookListBean
import com.zymh.ebk.read.dao.ShelfEvent
import com.zymh.ebk.read.data.bean.TextAdListBean
import com.zymh.ebk.read.presenter.BookShelfPresenter
import com.zymh.ebk.read.presenter.view.IBookShelfPage
import kotlinx.android.synthetic.main.fragment_book_shelf.*
import kotlinx.android.synthetic.main.title_with_search_icon.*
import java.lang.StringBuilder

class BookShelfFragment : AbsPageFragment(), IBookShelfPage, BookShelfHelper.ShelfDaoObserver, ShelfThreeBooksView.OnLongPressListener {

    private var mShelfBookList: ArrayList<BookShelfBean> = ArrayList()
    private var mSelectedBooks: ArrayList<BookShelfBean> = ArrayList()
    private var mPageData: ArrayList<Any>? = null
    private val mAdapter by lazy {
        AdapterBuilder().putItemClass(TextAd::class.java, mBookItemsListener)
                .putItemClass(ImageAd::class.java)
                .putItemClass(ShelfThreeBooksView::class.java, getItemListener())
                .builderListAdapter(activity!!)
    }

    private val mBookItemsListener by lazy {
        object : ItemListener<TextAd> {
            override fun onCreate(itemView: TextAd) {
                super.onCreate(itemView)
                itemView.mPageName = pageName
            }
        }
    }

    public var isEditMode: Boolean = false

    private var mTopEditHeight = 0

    private val mAdHelper by lazy {
        AdMgr.createAdHelper(activity!!)
    }

    private val mPresenter by lazy {
        BookShelfPresenter(this)
    }

    private var mTopOutAnim: ObjectAnimator? = null
    private var mTopInAnim: ObjectAnimator? = null

    private fun getItemListener(): ItemListenerAdapter<ShelfThreeBooksView> {
        return object : ItemListenerAdapter<ShelfThreeBooksView>() {
            override fun onClick(v: ShelfThreeBooksView, view: View) {
                val data = v.mItemData.list[view.tag as Int]
                data.mIsSelect = !data.mIsSelect
                if (data.mIsSelect) {
                    mSelectedBooks.add(data)
                } else {
                    mSelectedBooks.remove(data)
                }
                setSelectedCount()
                mAdapter.notifyDataSetChanged()
                if (mSelectedBooks.size == 0) {
                    SnackbarUtil.setSnackbarColor(mSnackbar, ViewUtils.getColor(R.color.standard_black_second_level_color_c4), ViewUtils.getColor(R.color.standard_black_fourth_level_color_c6))
                } else {
                    SnackbarUtil.setSnackbarColor(mSnackbar, ViewUtils.getColor(R.color.white), ViewUtils.getColor(R.color.standard_red_main_color_c1))
                }
            }

            override fun onCreate(itemView: ShelfThreeBooksView) {
                super.onCreate(itemView)
                itemView.setOnLongPressListener(this@BookShelfFragment)
            }
        }
    }

    private fun setSelectedCount() {
        select_count.text = ViewUtils.getString(R.string.select_count, mSelectedBooks.size)
    }

    override fun onLongPress() {
        toEditMode()
    }

    private fun toEditMode() {
        mSelectedBooks.clear()
        setSelectedCount()
        mShelfBookList.forEach {
            it.mIsEditMode = true
        }
        mAdapter.notifyDataSetChanged()
        mTopInAnim?.start()
        mSnackbar?.show()
        isEditMode = true
/*        val height = list_view.height
        ViewUtils.setViewHeight(list_view, height + ViewUtils.dp2px(60.0f))
        val layoutParams = list_view.layoutParams as LinearLayout.LayoutParams
        layoutParams.topMargin = - ViewUtils.dp2px(60.0f)
        list_view.layoutParams = layoutParams*/
    }

    override fun getPageName(): String {
        return ViewUtils.getString(R.string.book_shelf)
    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        BookShelfHelper.getsInstance().addObserver(this)
    }

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<*> {
        setContentView(R.layout.fragment_book_shelf)
        return mPresenter
    }

    fun initView() {
        findView<ImageView>(R.id.search_icon)!!.setOnClickListener(this)
        select_all.onClick(this)
        finish.onClick(this)
        title_layout.post {
            mTopEditHeight = if (title_layout == null) 0 else title_layout.height
            ViewUtils.setViewHeight(top_edit, mTopEditHeight)
            initAnim()
        }
    }

    private var mSnackbar: Snackbar? = null

    private fun initAnim() {
        mTopInAnim = ObjectAnimator.ofFloat(top_edit, "translationY", -mTopEditHeight.toFloat(), 0.0f)
        mTopInAnim!!.setDuration(200)
        mTopOutAnim = ObjectAnimator.ofFloat(top_edit, "translationY", 0.0f, -mTopEditHeight.toFloat())
        mTopOutAnim!!.setDuration(200)
        mSnackbar = SnackbarUtil.IndefiniteSnackbar(shelf_root, ViewUtils.getString(R.string.delete),
                Int.MAX_VALUE, ViewUtils.getColor(R.color.standard_black_second_level_color_c4), Gravity.CENTER,
                ViewUtils.getColor(R.color.standard_black_fourth_level_color_c6)) { removeBooksFromShelf() }
    }

    private fun updateBooks(it: ShelfEvent) {
        quitEditMode()
        if (it.mType == ShelfEvent.TYPE_ADD) {
            it.mChangeList.addAll(mShelfBookList)
            mShelfBookList.clear()
            mShelfBookList.addAll(it.mChangeList)
        }
        update()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initView()
        title_text.text = pageName
        list_view.adapter = mAdapter
    }

    override fun showPage(pageData: ArrayList<Any>) {
        mPageData = pageData
        mShelfBookList.clear()
        val listBean = pageData[1]
        if (listBean is ShelfBookListBean) {
            mShelfBookList.addAll(listBean.list)
        }
        update()
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.search_icon -> ActivityHelper.gotoSearch(BaseData(pageName))
            R.id.select_all -> selectAll()
            R.id.delete_btn -> removeBooksFromShelf()
            R.id.finish -> quitEditMode()
        }
    }

    fun quitEditMode() {
        mSelectedBooks.clear()
        mShelfBookList.forEach {
            it.mIsEditMode = false
            it.mIsSelect = false
        }
        mAdapter.notifyDataSetChanged()
        if (mTopOutAnim != null) {
            mTopOutAnim?.start()
        }
        if (mSnackbar != null) {
            mSnackbar?.dismiss()
        }
        isEditMode = false
    }

    @SuppressLint("CheckResult")
    private fun removeBooksFromShelf() {
        if (mSelectedBooks.size == 0) {
            ToastUtils.showLimited(R.string.none_book_selected)
            return
        }
        finish.isClickable = false
        BookShelfHelper.getsInstance().removeBooksInRx(mSelectedBooks, false).subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe {
            ToastUtils.showLimited(it)
            finish.isClickable = true
            removeFromList(mSelectedBooks)
            sendStatis(mSelectedBooks)
            mSelectedBooks.clear()
            update()
            if (mShelfBookList.size == 0) {
                quitEditMode()
            }
        }
    }

    private fun sendStatis(mSelectedBooks: ArrayList<BookShelfBean>) {
        val builder = StringBuilder()
        mSelectedBooks.forEachIndexed { index, bookShelfBean ->
            builder.append(bookShelfBean.bookName)
            if (index != mSelectedBooks.size - 1) {
                builder.append("_")
            }
        }
        StatisHelper.onEvent().bookshelfDelete(builder.toString())
    }

    private fun removeFromList(changeList: ArrayList<BookShelfBean>) {
        for (bookShelfBean in changeList) {
            var y = 0
            for (i in mShelfBookList.indices) {
                val bookItemBean = mShelfBookList[i - y]
                if (bookItemBean.bookId == bookShelfBean.bookId) {
                    mShelfBookList.removeAt(i - y)
                    y++
                }
            }
        }
    }

    private fun selectAll() {
        for (bookShelfBean in mShelfBookList) {
            bookShelfBean.mIsSelect = true
        }
        mSelectedBooks.clear()
        mSelectedBooks.addAll(mShelfBookList)
        setSelectedCount()
        mAdapter.notifyDataSetChanged()
    }

    private var needShowAd: Boolean = false
        get() {
            var showAd = AdMgr.isShowAd(AdMgr.AD_BOOK_SHELF)
            return showAd
        }

    private fun update() {
        val arrayData: ArrayList<Any> = ArrayList()

        if (mPageData != null && mPageData!!.size != 0) {
            val textAd = mPageData!![0]
            if (textAd is TextAdListBean) {
                if (textAd.list.size != 0) {
                    arrayData.add(textAd)
                }
            }
        }
        needShowAd = AdMgr.isShowAd(AdMgr.AD_BOOK_SHELF)
        if (needShowAd) {
            arrayData.add(AdData(mAdHelper, AdMgr.AD_BOOK_SHELF, pageName))
        }

        val shelfBookLists = CollectionUtils.split(mShelfBookList, 3)
        if (shelfBookLists != null && shelfBookLists.size != 0) {
            for (list in shelfBookLists) {
                val shelfBookListBean = ShelfBookListBean()
                shelfBookListBean.list = list
                arrayData.add(shelfBookListBean)
            }
        }
        mAdapter.setData(arrayData)
    }

    override fun onShelfChange(event: ShelfEvent) {
        updateBooks(event)
    }

    override fun onDetach() {
        super.onDetach()
        quitEditMode()
        BookShelfHelper.getsInstance().removeObserver(this)
    }
}
