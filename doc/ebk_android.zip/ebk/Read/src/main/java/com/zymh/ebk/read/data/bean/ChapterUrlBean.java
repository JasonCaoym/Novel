package com.zymh.ebk.read.data.bean;

public class ChapterUrlBean {
    public String secret;
    public String content;
    public int seqNum;
    public int chapterId;
    public String chapterTitle;
    public String format;
    public int chapterCount;
    public String bookName;
    public String bookId;
    public String url;
}
