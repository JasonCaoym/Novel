package com.zymh.ebk.read.utils;

import com.zymh.ebk.read.dao.ChapterBean;
import com.zymh.ebk.read.dao.ChapterBeanDao;
import com.zymh.ebk.read.dao.DaoDbHelper;
import com.zymh.ebk.read.dao.DaoSession;

import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;

public class BookChapterHelper {
    private static volatile BookChapterHelper sInstance;
    private static DaoSession daoSession;
    private static ChapterBeanDao bookChapterBeanDao;

    public static BookChapterHelper getsInstance() {
        if (sInstance == null) {
            synchronized (BookChapterHelper.class) {
                if (sInstance == null) {
                    sInstance = new BookChapterHelper();
                    daoSession = DaoDbHelper.getInstance().getSession();
                    bookChapterBeanDao = daoSession.getChapterBeanDao();
                }
            }
        }
        return sInstance;
    }

    public void saveBookChaptersAsync(final List<ChapterBean> chapterBeans) {
        daoSession.startAsyncSession()
                .runInTx(new Runnable() {
                    @Override
                    public void run() {
                        daoSession.getChapterBeanDao().insertOrReplaceInTx(chapterBeans);
                    }
                });
    }

    public void updateBookChaptersAsync(final ChapterBean chapterBean) {
        daoSession.startAsyncSession()
                .runInTx(new Runnable() {
                    @Override
                    public void run() {
                        daoSession.getChapterBeanDao().insertOrReplaceInTx(chapterBean);
                    }
                });
    }

    public void removeBookChapters(String bookId) {
        bookChapterBeanDao.queryBuilder().where(ChapterBeanDao.Properties.BookId.eq(bookId))
                .buildDelete()
                .executeDeleteWithoutDetachingEntities();
    }

    public Observable<List<ChapterBean>> findBookChaptersInRx(final String bookId) {
        return Observable.create(new ObservableOnSubscribe<List<ChapterBean>>() {
            @Override
            public void subscribe(ObservableEmitter<List<ChapterBean>> emitter) throws Exception {
                List<ChapterBean> chapterBeans = daoSession.getChapterBeanDao()
                        .queryBuilder()
                        .where(ChapterBeanDao.Properties.BookId.eq(bookId))
                        .list();
                emitter.onNext(chapterBeans);
            }
        });
    }

    public List<ChapterBean> findBookChapters(final String bookId) {
        return daoSession.getChapterBeanDao()
                .queryBuilder()
                .where(ChapterBeanDao.Properties.BookId.eq(bookId))
                .list();
    }
}
