package com.zymh.ebk.read.data.api.definition

import com.zydm.base.data.net.*
import com.zydm.base.common.ParamKey
import com.zymh.ebk.read.dao.ChapterListBean
import com.zymh.ebk.read.data.bean.ChapterUrlBean


@BasePath("/Api/Chapter/")
interface ChapterApi {

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getList(@Param(ParamKey.BOOK_ID) bookId: String,
                @Param(ParamKey.COUNT) count: Int,
                @Param(ParamKey.SORT) sort: Int,
                @Param(ParamKey.START_CHAPTER) startChapter: Int): DataSrcBuilder<ChapterListBean>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getDetailBySeqNum(@Param(ParamKey.SEQ_NUM) seqNum: Int,
                          @Param(ParamKey.BOOK_ID) bookId: String): DataSrcBuilder<ChapterUrlBean>
}
