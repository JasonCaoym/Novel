package com.zymh.ebk.read.ui.read

import android.view.View
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.read.R
import com.zymh.ebk.read.page.TxtChapter
import kotlinx.android.synthetic.main.catalogue_item.view.*

open class ReadChapterListHolder : AbsItemView<TxtChapter>() {

    override fun onCreate() {
        setContentView(R.layout.catalogue_item)
        mItemView.setOnClickListener(this)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.chapter_title.text = mItemData.title
    }

    fun setChapterTitleColor(color: Int) {
        mItemView.chapter_title.setTextColor(color)
    }

    fun setDividerColor(color: Int) {
        mItemView.findViewById<View>(R.id.divider_1px).setBackgroundColor(color)
    }
}