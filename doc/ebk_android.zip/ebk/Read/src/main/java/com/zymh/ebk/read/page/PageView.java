package com.zymh.ebk.read.page;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.zymh.ebk.read.page.animation.CoverPageAnim;
import com.zymh.ebk.read.page.animation.HorizonPageAnim;
import com.zymh.ebk.read.page.animation.Layer;
import com.zymh.ebk.read.page.animation.PageSwitcher;

public class PageView extends FrameLayout {

    private int mViewWidth = 0;
    private int mViewHeight = 0;

    private int mStartX = 0;
    private int mStartY = 0;
    private boolean isMove = false;
    private int mBgColor = Color.WHITE;
    private boolean canTouch = true;
    private boolean isPrepare = false;
    private RectF mCenterRectForMenu = null;

    private PageSwitcher mPageAnim;
    private PageSwitcher.OnPageChangeListener mPageAnimListener = new PageSwitcher.OnPageChangeListener() {
        @Override
        public boolean hasPrev() {
            return PageView.this.hasPrev();
        }

        @Override
        public boolean hasNext() {
            return PageView.this.hasNext();
        }

        @Override
        public void pageCancel() {
            mTouchListener.cancel();
            mPageLoader.pageCancel();
        }

        @Override
        public void drawExtra(Canvas canvas) {
            PageView.super.dispatchDraw(canvas);
        }
    };

    private TouchListener mTouchListener;

    private PageLoader mPageLoader;
    private FrameLayout mExtraRoot;

    public PageView(Context context) {
        this(context, null);
    }

    public PageView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PageView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mExtraRoot = new FrameLayout(context);
        mExtraRoot.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        addView(mExtraRoot);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        Log.i("ggg", w + "..." + h + "..." + oldw + "..." + oldh);
        mViewWidth = w;
        mViewHeight = h;
        initSwitchAnim();
        mPageLoader.setDisplaySize(w, h);
        isPrepare = true;
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        canvas.drawColor(mBgColor);
        mPageAnim.draw(canvas);
    }

    public void initSwitchAnim() {
        if (mViewWidth == 0 || mViewHeight == 0) {
            return;
        }
        mPageAnim = new CoverPageAnim(mViewWidth, mViewHeight, this, mPageAnimListener);
    }

    public Layer getNextPage() {
        if (mPageAnim == null) return null;
        return mPageAnim.getNextBitmap();
    }

    public Layer getBgBitmap() {
        if (mPageAnim == null) return null;
        return mPageAnim.getBgBitmap();
    }

    public void setBgColor(int color) {
        mBgColor = color;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        super.onTouchEvent(event);
        if (!canTouch && event.getAction() != MotionEvent.ACTION_DOWN) {
            return true;
        }

        int x = (int) event.getX();
        int y = (int) event.getY();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mStartX = x;
                mStartY = y;
                isMove = false;
                canTouch = mTouchListener.onTouch();
                mPageAnim.onTouchEvent(event);
                break;
            case MotionEvent.ACTION_MOVE:
                int slop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
                if (!isMove) {
                    isMove = Math.abs(mStartX - event.getX()) > slop || Math.abs(mStartY - event.getY()) > slop;
                }
                if (isMove) {
                    mPageAnim.onTouchEvent(event);
                }
                break;
            case MotionEvent.ACTION_UP:
                if (!isMove) {
                    if (mCenterRectForMenu == null) {
                        mCenterRectForMenu = new RectF(mViewWidth * 3/10, 0,
                                mViewWidth * 7 / 10, mViewHeight);
                    }

                    if (mCenterRectForMenu.contains(x, y)) {
                        if (mTouchListener != null) {
                            mTouchListener.center();
                        }
                        return true;
                    }
                }
                mPageAnim.onTouchEvent(event);
                break;
        }
        return true;
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        Layer layer = mPageAnim.getTopBitmap();
        if (!layer.isExtraAfterBook && !layer.isExtraAfterChapter) {
            return true;
        }
        return super.onInterceptTouchEvent(ev);
    }

    private boolean hasNext() {
        Boolean hasNext = false;
        if (mTouchListener != null) {
            hasNext = mTouchListener.nextPage();
            if (hasNext) {
                hasNext = mPageLoader.next();
            }
        }
        return hasNext;
    }

    private boolean hasPrev() {
        Boolean hasPrev = false;
        if (mTouchListener != null) {
            hasPrev = mTouchListener.prePage();
            if (hasPrev) {
                hasPrev = mPageLoader.pre();
            }
        }
        return hasPrev;
    }

    @Override
    public void computeScroll() {
        mPageAnim.scrollAnim();
        super.computeScroll();
    }

    public boolean isPrepare() {
        return isPrepare;
    }

    public boolean isRunning() {
        return !mPageAnim.isRunning();
    }

    public void setTouchListener(TouchListener mTouchListener) {
        this.mTouchListener = mTouchListener;
    }

    public void drawNextPage() {
        if (mPageAnim instanceof HorizonPageAnim) {
            ((HorizonPageAnim) mPageAnim).changePage();
        }
        mPageLoader.onDraw(getNextPage(), false);
    }

    public void refreshPage() {
        drawCurPage(false);
    }

    public void drawCurPage(boolean isUpdate) {
        mPageLoader.onDraw(getNextPage(), isUpdate);
    }

    public PageLoader getPageLoader() {
        if (mPageLoader == null) {
            mPageLoader = new PageLoader(this);
        }
        return mPageLoader;
    }

    public interface TouchListener {
        void center();

        boolean onTouch();

        boolean prePage();

        boolean nextPage();

        void cancel();
    }
}
