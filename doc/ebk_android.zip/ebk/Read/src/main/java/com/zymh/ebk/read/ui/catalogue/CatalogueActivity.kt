package com.zymh.ebk.read.ui.catalogue

import android.app.Dialog
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.*
import com.zydm.base.presenter.view.ISimplePageView
import com.zydm.base.ext.onClick
import com.zydm.base.ext.setVisible
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.activity.AbsPageActivity
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.ui.item.ItemListenerAdapter
import com.zydm.base.ui.item.RecyclerAdapter
import com.zydm.base.utils.ViewUtils
import com.zydm.base.widgets.CornerDrawable
import com.zydm.base.widgets.wheel.WheelView
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.read.R
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.dao.ChapterBean
import com.zymh.ebk.read.dao.ChapterListBean
import com.zymh.ebk.read.data.bean.BookDetailBean
import com.zymh.ebk.read.presenter.CataloguePresenter
import com.zymh.ebk.read.utils.BookRecordHelper
import kotlinx.android.synthetic.main.activity_catalogue.*
import kotlinx.android.synthetic.main.group_dialog_layout.view.*

class CatalogueActivity : AbsPageActivity(), ISimplePageView<ChapterListBean>, BookRecordHelper.RecordDaoObserver {

    private lateinit var mAdapter: RecyclerAdapter

    private lateinit var mBookDetailBean: BookDetailBean

    private var mGroupCount = 0

    private var mReadGroup: Int = 0

    private lateinit var mGroups: ArrayList<GroupItem>

    private var mDialog: Dialog? = null

    private lateinit var mWheelView: WheelView

    private lateinit var mPresenter: CataloguePresenter

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<ChapterListBean> {
        setContentView(R.layout.activity_catalogue)
        mBookDetailBean = intent.getParcelableExtra(BaseActivity.DATA_KEY)
        initView()
        BookRecordHelper.getsInstance().addObserver(this)
        mPresenter = CataloguePresenter(mBookDetailBean, this)
        StatisHelper.onEvent().detailCatalog(mBookDetailBean.bookName)
        return mPresenter
    }

    private fun initView() {
        setToolBarLayout(ViewUtils.getString(R.string.catalogue))
        mAdapter = AdapterBuilder()
                .putItemClass(ChapterListHolder::class.java, getItemListener())
                .builderRecyclerAdapter(this)
        list_view.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        list_view.adapter = mAdapter
        chapter_count.text = ViewUtils.getString(R.string.chapter_count, mBookDetailBean.chapterCount)
        initGroup()
    }

    private fun getItemListener(): ItemListenerAdapter<ChapterListHolder> {
        return object : ItemListenerAdapter<ChapterListHolder>() {
            override fun onClick(readBgHolder: ChapterListHolder, v: View) {
                val position = readBgHolder.mPosition
                ActivityHelper.gotoRead(activity, mBookDetailBean.bookId, (readBgHolder.mItemData as ChapterBean).seqNum, BaseData("目录"))
            }
        }
    }

    private fun initGroup() {
        val chapterCount = mBookDetailBean.chapterCount
        if (chapterCount <= 50) {
            current_group.setVisible(false);
            return
        }
        current_group.setVisible(true);
        mGroupCount = if (chapterCount % 50 == 0) chapterCount / 50 else chapterCount / 50 + 1
        val readSeqNum = mBookDetailBean.mReadChapterSeqNum
        mReadGroup = if (readSeqNum % 50 == 0) readSeqNum / 50 - 1 else readSeqNum / 50
        mGroups = ArrayList(mGroupCount)
        val remain = if (chapterCount % 50 == 0) 50 else chapterCount % 50;
        for (i in 0 until mGroupCount) {
            val groupItem = GroupItem(i)
            groupItem.name = ViewUtils.getString(R.string.chapter_group, i * 50 + 1, if (i == mGroupCount - 1) i * 50 + remain else i * 50 + 50)
            if (i == mReadGroup) {
                groupItem.isReadGroup = true
            }
            mGroups.add(groupItem)
        }
        current_group.text = ViewUtils.getString(R.string.chapter_range, mReadGroup * 50 + 1, mReadGroup * 50 + 50)
        current_group.onClick(this)
    }

    override fun showPage(data: ChapterListBean) {
        val readSeqNum = mBookDetailBean.mReadChapterSeqNum
        var select = 0
        if (readSeqNum >= data.list[0].seqNum && readSeqNum <= data.list[data.list.size - 1].seqNum) {
            for (index in 0 until data.list.size - 1) {
                if (readSeqNum == data.list[index].seqNum) {
                    data.list[index].isSelect = true
                    select = index
                }
            }
        }
        mAdapter.setData(data.list)
        mAdapter.notifyDataSetChanged()
        list_view.scrollToPosition(select)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.current_group -> showGroupDialog()
            R.id.confirm_btn -> updateCatalogue()
        }
    }

    private fun updateCatalogue() {
        mDialog!!.dismiss()
        val group = mWheelView.currentItem
        current_group.text = ViewUtils.getString(R.string.chapter_range, group * 50 + 1, group * 50 + 50)
        mPresenter.setGroup(group)
    }

    private fun showGroupDialog() {
        if (mDialog == null) {
            mDialog = Dialog(this, R.style.ActionSheetDialogStyle)
        }
        val content = LayoutInflater.from(this).inflate(R.layout.group_dialog_layout, null)
        val corner = ViewUtils.dp2px(5.0f).toFloat()
        val drawable = CornerDrawable()
        drawable.setRadius(corner, corner, corner, corner, 0.0f, 0.0f, 0.0f, 0.0f)
        drawable.setColor(ViewUtils.getColor(R.color.white))
        content.background = drawable
        content.confirm_btn.onClick(this)
        mWheelView = content.findViewById<WheelView>(R.id.wheel_view)
        mWheelView.viewAdapter = GroupWheelAdapter(mGroups, this)
        mWheelView.currentItem = mReadGroup
        mDialog!!.setContentView(content)
        val dialogWindow = mDialog!!.window
        dialogWindow.setGravity(Gravity.BOTTOM)
        val lp = dialogWindow.attributes
        lp.height = (ViewUtils.getPhonePixels()[1] / 2.5f).toInt()
        lp.width = ViewUtils.getPhonePixels()[0]
        dialogWindow.attributes = lp
        mDialog!!.show()
    }

/*    private fun getGroupItemListener(): ItemListener<GroupItemView>? {
        return object : ItemListener<GroupItemView> {
            override fun onClick(itemView: GroupItemView, view: View) {

            }
        }
    }*/

    override fun onRecordChange(recordBean: BookRecordBean) {
        if (mBookDetailBean.bookId != recordBean.bookId) {
            return
        }
        mBookDetailBean.mReadChapterSeqNum = recordBean.seqNum
        mPresenter.loadPageData(true)
    }

    override fun onDestroy() {
        super.onDestroy()
        BookRecordHelper.getsInstance().removeObserver(this)
    }

    data class GroupItem(var groupId: Int) {
        public var name: String = ""
        public var isReadGroup: Boolean = false
    }
}
