package com.zymh.ebk.read.ui.bookshelf

import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.read.R
import kotlinx.android.synthetic.main.shelf_empty_layout.view.*

open class ShelfEmptyView : AbsItemView<String>() {

    override fun onCreate() {
        setContentView(R.layout.shelf_empty_layout)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.empty_msg.text = mItemData
    }
}
