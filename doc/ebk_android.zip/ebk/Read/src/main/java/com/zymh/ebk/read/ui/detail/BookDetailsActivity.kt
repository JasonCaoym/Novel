package com.zymh.ebk.read.ui.detail

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.support.v4.widget.NestedScrollView
import android.text.TextUtils
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.alibaba.android.arouter.facade.annotation.Route
import com.zydm.base.common.ParamKey
import com.zydm.base.ext.*
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.activity.AbsPageActivity
import com.zydm.base.utils.TimeUtils
import com.zydm.base.utils.ToastUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.ad.*
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.provider.router.RouterPath
import com.zydm.ebk.read.R
import com.zydm.statistics.motong.MtStConst
import com.zydm.statistics.motong.MtStHelper
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.dao.BookRecordBean
import com.zymh.ebk.read.dao.BookShelfHelper
import com.zymh.ebk.read.dao.ShelfEvent
import com.zymh.ebk.read.data.bean.BookDetailBean
import com.zymh.ebk.read.presenter.BookDetailPresenter
import com.zymh.ebk.read.presenter.view.IBookDetailPage
import com.zymh.ebk.read.utils.BookRecordHelper
import kotlinx.android.synthetic.main.activity_book_detail.*
import kotlinx.android.synthetic.main.book_detail_catalogue_layout.*
import kotlinx.android.synthetic.main.book_detail_head_layout.*
import kotlinx.android.synthetic.main.book_detail_resume_layout.*


@Route(path = RouterPath.Read.PATH_DETAIL)
public open class BookDetailsActivity : AbsPageActivity(), IBookDetailPage, BookRecordHelper.RecordDaoObserver, BookShelfHelper.ShelfDaoObserver {

    companion object {
        const val MAX_LINES = 2
    }

    private lateinit var mBookDetailBean: BookDetailBean
    private lateinit var mToolbarLayout: View
    private lateinit var mToolbarTitle: TextView
    private lateinit var mBottomLine: View
    private lateinit var mToolbarBack: View

    private lateinit var mBookDetailPresenter: BookDetailPresenter

    private val mAdHelper by lazy {
        AdMgr.createAdHelper(this)
    }

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<BookDetailBean> {
        setContentView(R.layout.activity_book_detail)
        initData(intent)
        initView()
        BookRecordHelper.getsInstance().addObserver(this)
        BookShelfHelper.getsInstance().addObserver(this)
        mBookDetailPresenter = BookDetailPresenter(this, mBookDetailBean)
        return mBookDetailPresenter
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent == null) {
            return;
        }
        initData(intent)
        mBookDetailPresenter.setBookDetailBean(mBookDetailBean)
        mBookDetailPresenter.loadPageData(true)
    }

    private fun initView() {
        mToolbarLayout = findViewById(R.id.toolbar_layout)
        mToolbarTitle = findViewById(R.id.toolbar_title)
        mToolbarBack = findViewById(R.id.toolbar_back)
        mBottomLine = findViewById(R.id.toolbar_bottom_line)
        scroll_view.setOnScrollChangeListener { _: NestedScrollView, _: Int, _: Int, _: Int, _: Int ->
            var progress = scroll_view.scrollY.toFloat() / head_layout.height.toFloat()
            if (progress < 0.0f) {
                progress = 0.0f
            }
            if (progress > 1.0f) {
                progress = 1.0f
            }
            transStyleToolBar(progress)

            if (content_root.height <= scroll_view.scrollY + scroll_view.height) {
                if (mBookDetailBean.mReadChapterSeqNum == mBookDetailBean.chapterCount) {
                    ToastUtils.showLimited(R.string.last_chapter)
                    return@setOnScrollChangeListener
                }
                mBookDetailPresenter.saveBookReadRecord(mBookDetailBean)
            }
        }
        findView<ImageView>(R.id.toolbar_back)!!.setImageResource(R.mipmap.icon_back_w)
    }

    override fun onTitleUpdateHeight(statusBarHeight: Int) {
        head_info_layout.setPaddingTop(statusBarHeight + ViewUtils.getDimenPx(R.dimen.title_h))
    }

    private fun initData(intent: Intent) {
        val bookId = getBookId(intent)
        mBookDetailBean = BookDetailBean()
        mBookDetailBean.bookId = bookId
    }

    private fun getBookId(intent: Intent): String {
        val uri = intent.data
        if (null == uri) {
            return intent.getStringExtra(ParamKey.BOOK_ID)
        } else {
            return uri.getQueryParameter(ParamKey.BOOK_ID)
        }
    }

    @SuppressLint("CheckResult")
    override fun showPage(pageData: BookDetailBean) {
        mBookDetailBean = pageData
        sendStatis()
        setHead(pageData)
        setResume(pageData)
        setCatalogue(pageData)
        setFirstChapter(pageData)
        btn_read.onClick(this)
        setReadBtn(pageData)
        btn_add_shelf.onClick(this)
        setAddShelfBtn(pageData)
        initAd()
    }

    private var mIsSend: Boolean = false

    fun sendStatis() {
        if (mIsSend) {
            return
        }
        mIsSend = true
        val data = intent.getParcelableExtra<BaseData>(DATA_KEY)
        var from = "h5"
        if (data != null) {
            from = data.from
        }
        StatisHelper.onEvent().bookDetail(mBookDetailBean.bookName, from)

        if (from == MtStConst.VALUE_SEARCH_BY_KEYWORD) {
            MtStHelper.bookDetails(mBookDetailBean.bookId, "1")
        } else if (from == MtStConst.VALUE_SEARCH_BY_THINK) {
            MtStHelper.bookDetails(mBookDetailBean.bookId, "2")
        } else {
            MtStHelper.bookDetails(mBookDetailBean.bookId, "0")
        }
    }

    private fun initAd() {
        if (AdMgr.isShowAd(AdMgr.AD_DETAIL)) {
            ad_layout.setVisible(true)
            val adParam = AdMgr.getAdParam(AdMgr.AD_DETAIL)
            val mConfig = adParam.mConfig
            if (!mConfig.isOriginal_()) {
                val width = ViewUtils.getPhonePixels()[0]
                val height = width * mConfig.height / mConfig.width.toFloat()
                ViewUtils.setViewSize(ad_layout, width, height.toInt())
            }
            mAdHelper.loadAdWhitContainer(adParam, ad_layout, this, object : OnAdLoadedListener {
                override fun onAdLoad(imageMode: Int) {
                    ad_layout.getChildAt(0)?.setBackgroundColor(ViewUtils.getColor(R.color.white))
                }

            })
        } else {
            ad_layout.setVisible(false)
        }
    }

    private fun setAddShelfBtn(pageData: BookDetailBean) {
        btn_add_shelf.text = ViewUtils.getString(if (pageData.mIsInShelf) R.string.already_in_shelf else R.string.btn_add_shelf)
    }

    override fun addShelfSuccess() {
        mBookDetailBean.mIsInShelf = true
        setAddShelfBtn(mBookDetailBean)
        ToastUtils.showLimited(R.string.add_shelf_success)
    }

    private fun setReadBtn(pageData: BookDetailBean) {
        btn_read.text = ViewUtils.getString(
                if (pageData.mReadChapterSeqNum != mBookDetailBean.chapterCount && pageData.mReadChapterSeqNum != 1) R.string.continue_read else R.string.free_read)
    }

    override fun setReadBtnNext() {
        btn_read.text = ViewUtils.getString(R.string.next_chapter)
    }

    private fun setFirstChapter(pageData: BookDetailBean) {
        refreshChapter(pageData)
    }

    override fun refreshChapter(pageData: BookDetailBean) {
        chapter_title.text = pageData.mReadChapterTitle
        chapter_content.text = pageData.mReadChapter
    }

    private fun setCatalogue(pageData: BookDetailBean) {
        latest_chapter.text = if (pageData.isFinish) ViewUtils.getString(R.string.chapter_count, pageData.chapterCount) else ViewUtils.getString(R.string.latest_chapter, pageData.chapterCount)
        val period = (pageData.currTime - pageData.updateTime)
        val days = (period / 60 / 60 / 24).toInt()
        val dayString: String =
                when {
                    pageData.isFinish -> ViewUtils.getString(R.string.finished)
                    days == 0 -> ViewUtils.getString(R.string.today)
                    days <= 30 -> ViewUtils.getString(R.string.update_time, days)
                    else -> TimeUtils.formatDateStyleCharacter(pageData.updateTime.toString())
                }
        update_time.text = dayString
        book_detail_catalogue_layout.onClick(this)
    }

    private fun setResume(pageData: BookDetailBean) {
        if (TextUtils.isEmpty(pageData.resume)) {
            book_detail_resume_layout.setVisible(false)
            return
        }
        book_detail_resume_layout.setVisible(true)
        book_resume_text.text = pageData.resume
        book_resume_text.maxLines = MAX_LINES
        book_resume_arrow.isActivated = false
        book_resume_text.post {
            if (book_resume_text.lineCount > MAX_LINES) {
                book_resume_arrow.setVisible(true)
                book_resume_arrow.setImageResource(R.mipmap.icon_arrow_down_red)
            } else {
                book_resume_arrow.setVisible(false)
            }
        }
        book_resume_text.onClick(this)
        book_resume_arrow.onClick(this)
    }

    private fun changeResumeExpandState() {
        if (book_resume_text.lineCount < MAX_LINES || book_resume_arrow.visibility == View.GONE) {
            return
        }
        if (book_resume_text.maxLines == MAX_LINES) {
            book_resume_text.maxLines = 1000
            book_resume_arrow.isActivated = true
            book_resume_arrow.setImageResource(R.mipmap.icon_arrow_up_red)
        } else {
            book_resume_text.maxLines = MAX_LINES
            book_resume_arrow.isActivated = false
            book_resume_arrow.setImageResource(R.mipmap.icon_arrow_down_red)
        }
    }

    private fun setHead(pageData: BookDetailBean) {
        transStyleToolBar(0.0f)
        book_cover.loadUrl(mBookDetailBean.bookCover)
        head_layout.loadBackground(mBookDetailBean.bookCover, true)
        mToolbarTitle.text = pageData.bookName
        book_name.text = pageData.bookName
        book_author.text = pageData.author
        book_state.text = ViewUtils.getString(if (pageData.isFinish) R.string.finished else R.string.updating)
        val count: String = if (pageData.wordCount > 10000) (pageData.wordCount.toInt() / 10000).toString() + ViewUtils.getString(R.string.wan) else pageData.wordCount.toString()
        font_count.text = ViewUtils.getString(R.string.font_count, count)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.book_resume_text, R.id.book_resume_arrow -> changeResumeExpandState()
            R.id.btn_add_shelf -> {
                StatisHelper.onEvent().subscription(mBookDetailBean.bookName, "详情页加入书架")
                mBookDetailPresenter.addBookToShelf(mBookDetailBean)
            }
            R.id.btn_read -> ActivityHelper.gotoRead(this, mBookDetailBean.bookId, BaseData("详情"))
            R.id.book_detail_catalogue_layout -> ActivityHelper.gotoCatalogue(this, mBookDetailBean)
        }
    }

    private fun transStyleToolBar(progress: Float) {
        mToolbarLayout.setBackgroundColor(Color.argb((progress * 255).toInt(), 255, 255, 255))
        mToolbarTitle.alpha = progress
        if (progress >= 1.0f) {
            findView<ImageView>(R.id.toolbar_back)!!.setImageResource(R.mipmap.icon_back)
            ViewUtils.setAndroidMWindowsBarTextDark(this)
            mBottomLine.setVisible(true)

        } else {
            findView<ImageView>(R.id.toolbar_back)!!.setImageResource(R.mipmap.icon_back_w)
            ViewUtils.setAndroidMWindowsBarTextWhite(this)
            mBottomLine.setVisible(false)
        }
    }

    override fun showEmpty() {
        super.showEmpty()
        transStyleToolBar(1.0f)
    }

    override fun showLoading() {
        super.showLoading()
        transStyleToolBar(1.0f)
    }

    override fun onRecordChange(recordBean: BookRecordBean) {
        if (mBookDetailBean.bookId != recordBean.bookId) {
            return
        }
        mBookDetailBean.mReadChapterSeqNum = recordBean.seqNum
        mBookDetailPresenter.updateReadChapter(mBookDetailBean)
    }

    override fun onShelfChange(event: ShelfEvent) {
        mBookDetailBean.mIsInShelf = event.mType == ShelfEvent.TYPE_ADD
        setAddShelfBtn(mBookDetailBean)
    }

    override fun onDestroy() {
        super.onDestroy()
        BookRecordHelper.getsInstance().removeObserver(this)
        BookShelfHelper.getsInstance().removeObserver(this)

        ad_layout.destroyAd()
    }

    override fun onPause() {
        super.onPause()
        scroll_view.postDelayed({ scroll_view.scrollY = 0 }, 40)
    }
}