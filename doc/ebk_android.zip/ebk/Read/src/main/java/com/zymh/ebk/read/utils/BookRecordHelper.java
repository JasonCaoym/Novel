package com.zymh.ebk.read.utils;

import android.os.Looper;
import android.support.annotation.NonNull;

import com.zydm.base.common.BaseApplication;
import com.zymh.ebk.read.dao.BookRecordBean;
import com.zymh.ebk.read.dao.BookRecordBeanDao;
import com.zymh.ebk.read.dao.DaoDbHelper;
import com.zymh.ebk.read.dao.DaoSession;

import java.util.ArrayList;
import java.util.List;

public class BookRecordHelper {
    private static volatile BookRecordHelper sInstance;
    private static DaoSession daoSession;
    private static BookRecordBeanDao bookRecordBeanDao;
    private ArrayList<RecordDaoObserver> mObservers = new ArrayList<>();

    public static BookRecordHelper getsInstance() {
        if (sInstance == null) {
            synchronized (BookRecordHelper.class) {
                if (sInstance == null) {
                    sInstance = new BookRecordHelper();
                    daoSession = DaoDbHelper.getInstance().getSession();
                    bookRecordBeanDao = daoSession.getBookRecordBeanDao();
                }
            }
        }
        return sInstance;
    }

    public void saveRecordBook(BookRecordBean recordBean, boolean notify) {
        bookRecordBeanDao.insertOrReplace(recordBean);
        if (notify) {
            notifyObserver(recordBean);
        }
    }

    public void updateRecordBook(BookRecordBean recordBean, boolean notify) {
        bookRecordBeanDao.update(recordBean);
        if (notify) {
            notifyObserver(recordBean);
        }
    }

    public void removeBook(String bookId) {
        bookRecordBeanDao
                .queryBuilder()
                .where(BookRecordBeanDao.Properties.BookId.eq(bookId))
                .buildDelete()
                .executeDeleteWithoutDetachingEntities();
    }

    public BookRecordBean findBookRecordById(String bookId) {
        BookRecordBean recordBean = bookRecordBeanDao.queryBuilder()
                .where(BookRecordBeanDao.Properties.BookId.eq(bookId)).unique();
        return recordBean;
    }

    public List<BookRecordBean> findAllBooks(int offset, int pageCount) {
        return bookRecordBeanDao
                .queryBuilder()
                .orderDesc(BookRecordBeanDao.Properties.LastRead)
                .offset(offset * pageCount).limit(pageCount)
                .list();
    }

    public void addObserver(RecordDaoObserver observer) {
        if (!mObservers.contains(observer)) {
            mObservers.add(observer);
        }
    }

    public void removeObserver(RecordDaoObserver observer) {
        mObservers.remove(observer);
    }

    private void notifyObserver(final BookRecordBean recordBean) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            excute(recordBean);
        } else {
            BaseApplication.handler.post(new Runnable() {
                @Override
                public void run() {
                    excute(recordBean);
                }
            });
        }
    }

    private void excute(BookRecordBean recordBean) {
        for (RecordDaoObserver observer : mObservers) {
            observer.onRecordChange(recordBean);
        }
    }

    public interface RecordDaoObserver {
        void onRecordChange(@NonNull BookRecordBean recordBean);
    }
}
