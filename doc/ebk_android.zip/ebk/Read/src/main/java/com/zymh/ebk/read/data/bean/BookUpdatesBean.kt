package com.zymh.ebk.read.data.bean

import com.zydm.base.data.bean.ListBean

class BookUpdatesBean {
    var bookId = ""
    var chapterCount = 0
    var updateTime: Long = 0
}

class BookUpdatesListBean : ListBean<BookUpdatesBean>()
