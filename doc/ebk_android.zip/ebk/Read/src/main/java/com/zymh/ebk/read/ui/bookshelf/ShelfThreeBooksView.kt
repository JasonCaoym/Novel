package com.zymh.ebk.read.ui.bookshelf

import android.view.View
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.loadUrl
import com.zydm.base.ext.setVisible
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.read.R
import com.zymh.ebk.read.common.ActivityHelper
import com.zymh.ebk.read.dao.BookShelfBean
import com.zymh.ebk.read.dao.BookShelfHelper
import com.zymh.ebk.read.dao.ShelfBookListBean
import kotlinx.android.synthetic.main.shelf_book_item.view.*

open class ShelfThreeBooksView : AbsItemView<ShelfBookListBean>(), View.OnLongClickListener {

    private val ids = arrayOf(
            R.id.book_1,
            R.id.book_2,
            R.id.book_3)

    private lateinit var mOnLongPressListener: OnLongPressListener

    override fun onCreate() {
        setContentView(R.layout.three_books_horizontal_layout)
        ids.forEachIndexed { index, id ->
            val view = mItemView.findViewById<View>(id)
            val width = (ViewUtils.getPhonePixels()[0] - ViewUtils.dp2px(17.0f) * 6) / 3
            val height = width * 4 / 3
            ViewUtils.setViewSize(view.book_cover, width, height)
            view.book_name.maxWidth = width
            view.setOnClickListener(this)
            view.setOnLongClickListener(this)
            view.tag = index
        }
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        ids.forEachIndexed { index, id ->
            val view = mItemView.findViewById<View>(id)
            val data = DataUtils.getItem(mItemData.list, index)
            if (data != null) {
                view.visibility = View.VISIBLE
                view.book_cover.loadUrl(data.bookCover)
                view.book_name.text = data.bookName
                if (data.mIsEditMode) {
                    view.select_icon.setVisible(true)
                    view.select_icon.setImageResource(if (data.mIsSelect) R.mipmap.select else R.mipmap.normal)
                } else {
                    view.select_icon.setVisible(false)
                }
                view.update_icon.setVisible(data.mIsUpdate)
                view.isEnabled = true
            } else {
                view.visibility = View.INVISIBLE
                view.isEnabled = false
            }
        }
    }

    override fun onClick(view: View) {
        val bookShelfBean = mItemData.list[view.tag as Int]
        if (bookShelfBean.mIsEditMode) {
            super.onClick(view)
        } else {
            BookShelfHelper.getsInstance().updateBook(bookShelfBean)
            ActivityHelper.gotoRead(mActivity, bookShelfBean.bookId, BaseData("书架"))
        }
    }

    override fun onLongClick(view: View): Boolean {
        val bookShelfBean = mItemData.list[view.tag as Int]
        if (!bookShelfBean.mIsEditMode) {
            mOnLongPressListener.onLongPress()
        }
        return true
    }

    fun setOnLongPressListener(listener: OnLongPressListener) {
        mOnLongPressListener = listener
    }

    interface OnLongPressListener {
        fun onLongPress()
    }
}
