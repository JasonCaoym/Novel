package com.zymh.ebk.read.data.api

import com.zydm.base.data.net.ApiFactory
import com.zymh.ebk.read.data.api.definition.BookApi
import com.zymh.ebk.read.data.api.definition.ChapterApi
import com.zymh.ebk.read.data.api.definition.RecommendApi

object Api {

    fun chapter() = ApiFactory.getApiInstance(ChapterApi::class.java)
    fun book() = ApiFactory.getApiInstance(BookApi::class.java)
    fun recommend() = ApiFactory.getApiInstance(RecommendApi::class.java)
}