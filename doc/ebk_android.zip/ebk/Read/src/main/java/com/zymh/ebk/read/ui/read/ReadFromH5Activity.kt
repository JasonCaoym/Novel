package com.zymh.ebk.read.ui.read

class ReadFromH5Activity: ReadActivity() {
}