package com.zymh.ebk.read.page.animation;

import android.graphics.Bitmap;
import android.widget.FrameLayout;

public class Layer {
    public Bitmap bitmap;
    public boolean isExtraAfterChapter;
    public boolean isExtraAfterBook;
    public FrameLayout rootLayoutForExtra;
}
