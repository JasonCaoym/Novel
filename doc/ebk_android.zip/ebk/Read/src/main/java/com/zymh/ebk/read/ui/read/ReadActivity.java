package com.zymh.ebk.read.ui.read;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.android.arouter.facade.annotation.Route;
import com.zydm.base.common.BaseApplication;
import com.zydm.base.statistics.umeng.StatisHelper;
import com.zydm.base.ui.activity.BaseActivity;
import com.zydm.base.ui.item.AdapterBuilder;
import com.zydm.base.ui.item.ItemListenerAdapter;
import com.zydm.base.ui.item.ListAdapter;
import com.zydm.base.utils.FringeUtils;
import com.zydm.base.utils.SPUtils;
import com.zydm.base.utils.ToastUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.MTDialog;
import com.zydm.ebk.provider.ad.AdMgr;
import com.zydm.ebk.provider.ad.AdParam;
import com.zydm.ebk.provider.ad.IAdHelper;
import com.zydm.ebk.provider.ad.ui.AutoScrollAdView;
import com.zydm.ebk.provider.router.BaseData;
import com.zydm.ebk.provider.router.RouterPath;
import com.zydm.ebk.read.R;
import com.zydm.statistics.motong.MtStHelper;
import com.zymh.ebk.read.page.TxtPage;
import com.zymh.ebk.read.presenter.view.IReadPage;
import com.zymh.ebk.read.presenter.ReadPresenter;
import com.zymh.ebk.read.dao.BookRecordBean;
import com.zymh.ebk.read.dao.ChapterBean;
import com.zymh.ebk.read.dao.ChapterListBean;
import com.zymh.ebk.read.page.AbsPageLoader;
import com.zymh.ebk.read.page.PageLoader;
import com.zymh.ebk.read.page.PageView;
import com.zymh.ebk.read.page.TxtChapter;
import com.zymh.ebk.read.setting.BrightMgr;
import com.zymh.ebk.read.setting.ReadSettingManager;
import com.zymh.ebk.read.utils.BookChapterHelper;
import com.zymh.ebk.read.utils.StatusBarUtils;
import com.zymh.ebk.read.utils.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

@Route(path = RouterPath.Read.PATH_READ)
public class ReadActivity extends BaseActivity implements IReadPage, View.OnClickListener {

    public static final String KEY_LEVEL = "level";

    View mReadTopMenu;
    PageView mPvReadPage;
    TextView mReadTvPageTip;
    TextView mReadTvCategory;
    TextView mReadTvNightMode;
    TextView mReadTvSetting;
    LinearLayout mReadBottomMenuRoot;
    TwoDirectionPullListView mRvReadCategory;
    DrawerLayout mDrawerLayout;
    private TextView mReadTitleTv;
    private ImageView mCatalogueBtn;
    private TextView mOrderTv;

    private ReadSettingDialog mSettingDialog;
    private PageLoader mPageLoader;
    private Animation mTopInAnim;
    private Animation mTopOutAnim;
    private ObjectAnimator mBottomInAnim;
    private ObjectAnimator mBottomOutAnim;
    private BookRecordBean mBook;
    private boolean isNightMode = false;
    private boolean isFullScreen = false;
    private String mBookId;
    ListAdapter mReadCategoryAdapter;
    List<List<TxtChapter>> mTxtChapters;
    private ReadPresenter mReadPresenter;
    List<List<ChapterBean>> bookChapterList;

    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_BATTERY_CHANGED.equals(intent.getAction())) {
                int level = intent.getIntExtra(KEY_LEVEL, 0);
                mPageLoader.updateBattery(level);
            } else if (Intent.ACTION_TIME_TICK.equals(intent.getAction())) {
                mPageLoader.updateTime();
            }
        }
    };
    private BrightMgr mBrightMgr;
    private int mTargetSeqNum;
    private int lastReadedChapterGroup = -1;
    private int lastReadedChapterPos = -1;
    private IAdHelper mAdHelper;
    private AutoScrollAdView mAdLayout;
    private boolean mHasChapterAd;
    private View mReadBottomMenu;
    private ArrayList<TxtChapter> mChaptersForCatalogue;
    private boolean mIsNormalOrderType = true;
    private View mTiTleLayout;
    private TextView mCatalogue;
    private String mFrom;
    private int mType = ReadPresenter.LOAD_CATALOGUE_TYPE_NORMAL;
    private View mGuideView;
    private View mGuideBtn;
    private ExtraPageMgr mExtraPageMgr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mReadPresenter = new ReadPresenter(this);
        setContentView(R.layout.activity_read);
        findView();
        isNightMode = ReadSettingManager.getInstance().isNightMode();
        mAdHelper = AdMgr.INSTANCE.createAdHelper(this);
        mHasChapterAd = AdMgr.INSTANCE.isShowAd(AdMgr.AD_READ_INTER_CUT);
        mAdLayout.setOnHeightConfirmListener(new AutoScrollAdView.OnHeightConfirmedListener() {
            @Override
            public void onHeightConfirm(int height) {
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mPvReadPage.getLayoutParams();
                params.bottomMargin = height;
                mPvReadPage.setLayoutParams(params);
            }
        });
        mAdLayout.init(mAdHelper, AdMgr.INSTANCE.isShowAd(AdMgr.AD_READ_BOTTOM) ? AdMgr.INSTANCE.getAdParam(AdMgr.AD_READ_BOTTOM, getPageName()) : null, isNightMode);
        initView();
    }

    @SuppressLint("InvalidWakeLockTag")
    private void initView() {
        Uri uri = getIntent().getData();
        if (uri != null) {
            mBookId = uri.getQueryParameter(RouterPath.KEY_BOOK_ID);
            mFrom = "h5";
            mTargetSeqNum = Integer.valueOf(uri.getQueryParameter(RouterPath.TARGET_SEQ_NUM));
        } else {
            mBookId = getIntent().getStringExtra(RouterPath.KEY_BOOK_ID);
            mFrom = ((BaseData) getIntent().getParcelableExtra(BaseActivity.DATA_KEY)).getFrom();
            mTargetSeqNum = getIntent().getIntExtra(RouterPath.TARGET_SEQ_NUM, 0);
        }

        isFullScreen = ReadSettingManager.getInstance().isFullScreen();
        mPageLoader = mPvReadPage.getPageLoader();
        mExtraPageMgr = new ExtraPageMgr();
        mPageLoader.supportPageAfterLastChapter(true);
        mPageLoader.supportPageBetweenChapters(mHasChapterAd);
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
        findViewById(R.id.toolbar_bottom_line).setVisibility(View.GONE);

        initData();


        mSettingDialog = new ReadSettingDialog(this, mPageLoader);
        mBrightMgr = new BrightMgr(this);
        setCategory();

        toggleNightMode();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_BATTERY_CHANGED);
        intentFilter.addAction(Intent.ACTION_TIME_TICK);
        registerReceiver(mReceiver, intentFilter);

        changeScreenBrightness(ReadSettingManager.getInstance().getBrightness());


        //隐藏StatusBar
        mPvReadPage.post(new Runnable() {
            @Override
            public void run() {
                hideSystemBar();
            }
        });

        mPageLoader.setOnPageChangeListener(new AbsPageLoader.OnPageChangeListener() {
            @Override
            public void onChapterChange(int curGroupPos, int pos) {
                setCategorySelect(curGroupPos, pos);
                ChapterBean chapterBean = mBook.bookChapterList.get(curGroupPos).get(pos);
                MtStHelper.INSTANCE.readBookChaper(mBook.bookId, chapterBean.chapterId + "", chapterBean.seqNum);
            }

            @Override
            public void loadChapterContents(List<TxtChapter> chapters, int curGroupPos, int pos) {
                mReadPresenter.loadContent(mBookId, chapters);
                mReadTvPageTip.setVisibility(GONE);
            }

            @Override
            public void preLoadChaptersGroup(int groupPos) {
                mReadPresenter.preLoadChaptersGroup(mBookId, groupPos);
            }

            @Override
            public void onChaptersConverted(List<List<TxtChapter>> chapters, int curGroupPos, int groupPos) {
                mRvReadCategory.setIsLoad(false);
                mTxtChapters = chapters;
                if (mType == ReadPresenter.LOAD_CATALOGUE_TYPE_PRE) {
                    int normalLastSeqNum = mChaptersForCatalogue.get(mChaptersForCatalogue.size() - 1).seqNum;
                    int lastGroup = normalLastSeqNum % 50 == 0 ? normalLastSeqNum / 50 - 1 : normalLastSeqNum / 50;
                    int firstSeqNum = mChaptersForCatalogue.get(0).seqNum;
                    int firstGroup = firstSeqNum % 50 == 0 ? firstSeqNum / 50 - 1 : firstSeqNum / 50;
                    if (lastGroup > firstGroup) {
                        if (groupPos == lastGroup + 1) {
                            mType = ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE;
                        } else if (groupPos == firstGroup - 1) {
                            mType = ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE;
                        }
                    } else {
                        if (groupPos == lastGroup - 1) {
                            mType = ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE;
                        } else if (groupPos == firstGroup + 1) {
                            mType = ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE;
                        }
                    }
                }
                refreshCatalogue();
            }

            @Override
            public void onPageCountChange(int count) {

            }

            @Override
            public int getExtraPageFrequency() {
                if (!AdMgr.INSTANCE.isShowAd(AdMgr.AD_READ_INTER_CUT)) {
                    return 0;
                }
                int frequency = AdMgr.INSTANCE.getAdParam(AdMgr.AD_READ_INTER_CUT, "").getMAdSpace();
                if (frequency < 3) {
                    frequency = 3;
                }
                return frequency;
            }

            @Override
            public void onPageChange(final int pos, TxtPage txtPage, boolean isCur) {
                if (isCur) {
                    mExtraPageMgr.refreshExtraPageAfterChapter(mHasChapterAd ? mAdHelper : null, ReadActivity.this);
                }
            }

            @Override
            public void onDrawPageAfterLastChapter(Canvas canvas, int textColor, boolean isNightMode, FrameLayout rootLayoutForExtra) {
                mExtraPageMgr.onDrawPageAfterLastChapter(canvas, textColor, isNightMode, rootLayoutForExtra);
            }

            @Override
            public void onDrawPageAfterChapter(Canvas canvas, int textColor, boolean isNightMode, FrameLayout rootLayoutForExtra) {
                mExtraPageMgr.onDrawPageAfterChapter(canvas, textColor, isNightMode, rootLayoutForExtra);
            }
        });

        mPvReadPage.setTouchListener(new PageView.TouchListener() {
            @Override
            public void center() {
                toggleMenu(true);
            }

            @Override
            public boolean onTouch() {
                mDrawerLayout.closeDrawer(Gravity.START);
                if (mTxtChapters != null && mTxtChapters.size() != 0) {
                    setCategorySelect(mPageLoader.getCurrGroupPos(), mPageLoader.getCurrChapterPos());
                }
                return !hideReadMenu();
            }

            @Override
            public boolean prePage() {
                return true;
            }

            @Override
            public boolean nextPage() {
                return true;
            }

            @Override
            public void cancel() {
            }
        });

        setOrderTv();
    }

    private void setOrderTv() {
        mOrderTv.setText(ViewUtils.getString(mIsNormalOrderType ? R.string.order_normal : R.string.order_reverse));
        Drawable drawable = ViewUtils.getDrawable(mIsNormalOrderType ? R.mipmap.icon_read_botton_list_along : R.mipmap.icon_read_botton_list_inverted);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        mOrderTv.setCompoundDrawables(drawable, null, null, null);
    }

    private void findView() {
        mAdLayout = findViewById(R.id.ad_layout);
        mReadTopMenu = findViewById(R.id.toolbar_layout);
        mReadTitleTv = findViewById(R.id.toolbar_title);
        mPvReadPage = findViewById(R.id.pv_read_page);
        mReadTvPageTip = findViewById(R.id.read_tv_page_tip);
        mReadTvCategory = findViewById(R.id.read_tv_category);
        mReadTvCategory.setOnClickListener(this);
        mReadTvNightMode = findViewById(R.id.read_tv_night_mode);
        mReadTvNightMode.setOnClickListener(this);
        mReadTvSetting = findViewById(R.id.read_tv_setting);
        mReadTvSetting.setOnClickListener(this);
        mReadBottomMenuRoot = findViewById(R.id.read_ll_bottom_menu_root);
        mReadBottomMenu = findViewById(R.id.read_ll_bottom_menu);
        mRvReadCategory = findViewById(R.id.rv_read_category);
        mDrawerLayout = findViewById(R.id.read_dl_slide);
        mCatalogueBtn = findViewById(R.id.catalogue_btn);
        mCatalogueBtn.setOnClickListener(this);
        mOrderTv = findViewById(R.id.order_type);
        mOrderTv.setOnClickListener(this);
        mTiTleLayout = findViewById(R.id.title_layout);
        mCatalogue = findViewById(R.id.catalogue);
        mGuideView = findViewById(R.id.guide_view);
        mGuideBtn = findViewById(R.id.guide_btn);
        mGuideBtn.setOnClickListener(this);
    }

    @SuppressLint("CheckResult")
    private void initData() {
        mReadPresenter.loadRecordedChaptersGroup(mBookId, mTargetSeqNum);
    }

    private void setCategory() {
        if (mReadCategoryAdapter == null) {
            mReadCategoryAdapter = new AdapterBuilder().putItemClass(ReadChapterListHolder.class, getItemListener()).builderListAdapter(this);
            mRvReadCategory.setAdapter(mReadCategoryAdapter);
        }
        mRvReadCategory.setOnRefreshingListener(new TwoDirectionPullListView.OnRefreshingListener() {
            @Override
            public void onLoadMoreBottom() {
                int normalLastSeqNum = mChaptersForCatalogue.get(mChaptersForCatalogue.size() - 1).seqNum;
                int group = normalLastSeqNum % 50 == 0 ? normalLastSeqNum / 50 - 1 : normalLastSeqNum / 50;
                int nextGroup = mIsNormalOrderType ? group + 1 : group - 1;
                if (mTxtChapters.get(nextGroup).size() != 0) {
                    mType = ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE;
                    mRvReadCategory.onLoadMoreBottomComplete();
                    refreshCatalogue();
                } else {
                    mReadPresenter.loadCatalogue(mBook.bookId, mBook.chapterCount, nextGroup, ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE);
                }
            }

            @Override
            public void onLoadMoreTop() {
                int firstSeqNum = mChaptersForCatalogue.get(0).seqNum;
                int group = firstSeqNum % 50 == 0 ? firstSeqNum / 50 - 1 : firstSeqNum / 50;
                int preGroup = mIsNormalOrderType ? group - 1 : group + 1;
                if (mTxtChapters.get(preGroup).size() != 0) {
                    mType = ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE;
                    mRvReadCategory.onLoadMoreTopComplete();
                    refreshCatalogue();
                } else {
                    mReadPresenter.loadCatalogue(mBook.bookId, mBook.chapterCount, preGroup, ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE);
                }
            }

            @Override
            public boolean hasTopMore() {
                if (mChaptersForCatalogue.size() == 0) {
                    return false;
                }
                return mIsNormalOrderType ? mChaptersForCatalogue.get(0).seqNum != 1 : mChaptersForCatalogue.get(0).seqNum != mBook.chapterCount;
            }

            @Override
            public boolean hasBottomMore() {
                if (mChaptersForCatalogue.size() == 0) {
                    return false;
                }
                return mIsNormalOrderType ? mChaptersForCatalogue.get(mChaptersForCatalogue.size() - 1).seqNum != mBook.chapterCount : mChaptersForCatalogue.get(mChaptersForCatalogue.size() - 1).seqNum != 1;
            }

            @Override
            public void noBottomMore() {
                ToastUtils.showLimited(mIsNormalOrderType ? R.string.already_last_chapter : R.string.already_first_chapter);
            }

            @Override
            public void noTopMore() {
                if (!mIsNormalOrderType) {
                    ToastUtils.showLimited(R.string.already_last_chapter);
                }
            }
        });
    }

    @NonNull
    private ItemListenerAdapter<ReadChapterListHolder> getItemListener() {
        return new ItemListenerAdapter<ReadChapterListHolder>() {
            @Override
            public void onClick(ReadChapterListHolder readBgHolder, View v) {
                mDrawerLayout.closeDrawer(Gravity.START);
                int seqNum = readBgHolder.getMItemData().seqNum;
                int groupIndex = seqNum % 50 == 0 ? seqNum / 50 - 1 : seqNum / 50;
                int selectPos = seqNum % 50 == 0 ? 50 - 1 : seqNum % 50 - 1;
                mPageLoader.skipToChapter(groupIndex, selectPos);
                StatisHelper.onEvent().bookReading(mBook.bookName, "左侧目录");
            }

            @Override
            public void onSetDate(ReadChapterListHolder itemView) {
                super.onSetDate(itemView);
                TxtChapter chapter = itemView.getMItemData();
                if (isNightMode) {
                    if (chapter.isSelect()) {
                        itemView.setChapterTitleColor(ViewUtils.getColor(R.color.standard_red_main_color_c1));
                    } else if (chapter.isRead()) {
                        itemView.setChapterTitleColor(ViewUtils.getColor(R.color.standard_black_second_level_color_c4));
                    } else {
                        itemView.setChapterTitleColor(ViewUtils.getColor(R.color.standard_black_third_level_color_c5));
                    }
                    itemView.setDividerColor(Color.parseColor("#885B5E6A"));
                } else {
                    if (chapter.isSelect()) {
                        itemView.setChapterTitleColor(ViewUtils.getColor(R.color.standard_red_main_color_c1));
                    } else if (chapter.isRead()) {
                        itemView.setChapterTitleColor(ViewUtils.getColor(R.color.standard_black_third_level_color_c5));
                    } else {
                        itemView.setChapterTitleColor(ViewUtils.getColor(R.color.standard_black_second_level_color_c4));
                    }
                    itemView.setDividerColor(ViewUtils.getColor(R.color.standard_black_third_level_color_c5));
                }
            }
        };
    }

    private void setCategorySelect(int currentGroup, int selectPos) {
        if (mTxtChapters == null || mTxtChapters.size() == 0) {
            return;
        }
        if (lastReadedChapterGroup != -1 && lastReadedChapterPos != -1) {
            mTxtChapters.get(lastReadedChapterGroup).get(lastReadedChapterPos).isRead = true;
            ChapterBean chapterBean = mBook.bookChapterList.get(lastReadedChapterGroup).get(lastReadedChapterPos);
            chapterBean.isRead = true;
            BookChapterHelper.getsInstance().updateBookChaptersAsync(chapterBean);
        }
        if (mChaptersForCatalogue == null) {
            mChaptersForCatalogue = new ArrayList<>();
        }
        refreshCatalogueSelect(currentGroup, selectPos);
        lastReadedChapterGroup = currentGroup;
        lastReadedChapterPos = selectPos;
    }

    private void refreshCatalogueSelect(int currentGroup, int selectPos) {
        if (mTxtChapters == null || mTxtChapters.size() == 0) {
            return;
        }
        mChaptersForCatalogue.clear();
        for (int i = 0; i < mTxtChapters.size(); i++) {
            List<TxtChapter> list = mTxtChapters.get(i);
            for (int j = 0; j < list.size(); j++) {
                TxtChapter chapter = list.get(j);
                chapter.setSelect(i == currentGroup && j == selectPos);
            }
        }
        ArrayList<TxtChapter> temp = new ArrayList<>();
        for (int i = currentGroup - 1; i > -1; i--) {
            List<TxtChapter> list = mTxtChapters.get(i);
            if (list.size() == 0) {
                break;
            }
            temp.addAll(list);
            temp.addAll(mChaptersForCatalogue);
            mChaptersForCatalogue.clear();
            mChaptersForCatalogue.addAll(temp);
            temp.clear();
        }

        int select = 0;
        List<TxtChapter> curTxtChapter = mTxtChapters.get(currentGroup);
        for (int j = 0; j < curTxtChapter.size(); j++) {
            TxtChapter chapter = curTxtChapter.get(j);
            mChaptersForCatalogue.add(chapter);
            if (chapter.isSelect()) {
                select = mChaptersForCatalogue.size() - 1;
            }
        }

        for (int i = currentGroup + 1; i < mTxtChapters.size(); i++) {
            List<TxtChapter> list = mTxtChapters.get(i);
            if (list.size() == 0) {
                break;
            }
            mChaptersForCatalogue.addAll(list);
        }

        if (!mIsNormalOrderType) {
            Collections.reverse(mChaptersForCatalogue);
            select = mChaptersForCatalogue.size() - 1 - select;
        }
        mReadCategoryAdapter.setData(mChaptersForCatalogue);
        if (select >= 6) {
            select = select - 6;
        }
        mRvReadCategory.setSelection(select);
    }

    private void refreshCatalogue() {
        if (mChaptersForCatalogue == null) {
            mChaptersForCatalogue = new ArrayList<>();
        }
        if (mType == ReadPresenter.LOAD_CATALOGUE_TYPE_POSITIVE) {
            mChaptersForCatalogue.clear();
            for (int i = 0; i < mTxtChapters.size(); i++) {
                List<TxtChapter> list = mTxtChapters.get(i);
                if (list.size() != 0) {
                    mChaptersForCatalogue.addAll(list);
                } else {
                    break;
                }
            }
        } else if (mType == ReadPresenter.LOAD_CATALOGUE_TYPE_REVERSE) {
            mChaptersForCatalogue.clear();
            ArrayList<TxtChapter> temp = new ArrayList<>();
            for (int i = mTxtChapters.size() - 1; i > -1; i--) {
                List<TxtChapter> list = mTxtChapters.get(i);
                if (list.size() != 0) {
                    temp.addAll(list);
                    temp.addAll(mChaptersForCatalogue);
                    mChaptersForCatalogue.clear();
                    mChaptersForCatalogue.addAll(temp);
                    temp.clear();
                } else {
                    break;
                }
            }
            Collections.reverse(mChaptersForCatalogue);
        } else if (mType == ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE) {
            int firstSeqNum = mChaptersForCatalogue.get(0).seqNum;
            int curGroup = firstSeqNum % 50 == 0 ? firstSeqNum / 50 - 1 : firstSeqNum / 50;
            int preGroup = mIsNormalOrderType ? curGroup - 1 : curGroup + 1;
            List<TxtChapter> chapters = mTxtChapters.get(preGroup);
            ArrayList<TxtChapter> temps = new ArrayList<>(chapters);
            if (!mIsNormalOrderType) {
                Collections.reverse(temps);
            }
            temps.addAll(mChaptersForCatalogue);
            mChaptersForCatalogue.clear();
            mChaptersForCatalogue.addAll(temps);
        } else if (mType == ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE) {
            int lastSeqNum = mChaptersForCatalogue.get(mChaptersForCatalogue.size() - 1).seqNum;
            int curGroup = lastSeqNum % 50 == 0 ? lastSeqNum / 50 - 1 : lastSeqNum / 50;
            int nextGroup = mIsNormalOrderType ? curGroup + 1 : curGroup - 1;
            List<TxtChapter> chapters = mTxtChapters.get(nextGroup);
            ArrayList<TxtChapter> temps = new ArrayList<>(chapters);
            if (!mIsNormalOrderType) {
                Collections.reverse(temps);
            }
            mChaptersForCatalogue.addAll(temps);
        }
        mReadCategoryAdapter.setData(mChaptersForCatalogue);
        if (mType == ReadPresenter.LOAD_CATALOGUE_TYPE_POSITIVE || mType == ReadPresenter.LOAD_CATALOGUE_TYPE_REVERSE) {
            mRvReadCategory.setSelection(0);
        }
    }

    private void toggleNightMode() {
        if (isNightMode) {
            nightMode();
        } else {
            dayMode();
        }
    }

    private void dayMode() {
        mCatalogueBtn.setImageResource(R.mipmap.pic_read_list_back_day);
        mCatalogue.setTextColor(Color.BLACK);
        mRvReadCategory.setBackgroundColor(ViewUtils.getColor(R.color.standard_black_fourth_level_color_c6));
        mReadCategoryAdapter.notifyDataSetChanged();
        mTiTleLayout.setBackgroundColor(ViewUtils.getColor(R.color.read_menu_bg_day));
        mReadTopMenu.setBackgroundColor(ViewUtils.getColor(R.color.read_menu_bg_day));
        mReadTitleTv.setTextColor(ViewUtils.getColor(R.color.standard_black_second_level_color_c4));
        mReadBottomMenu.setBackgroundColor(ViewUtils.getColor(R.color.read_menu_bg_day));
        mReadTvNightMode.setText(StringUtils.getString(R.string.ebk_read_mode_night));
        Drawable drawable = ContextCompat.getDrawable(this, R.mipmap.icon_read_botton_night_g);
        mReadTvNightMode.setCompoundDrawablesWithIntrinsicBounds(null, drawable, null, null);
        ViewUtils.setAndroidMWindowsBarTextDark(this);
        mAdLayout.setNightMode(false);
        mExtraPageMgr.setNightMode(false);
    }

    private void nightMode() {
        mCatalogueBtn.setImageResource(R.mipmap.pic_read_list_back_night);
        mCatalogue.setTextColor(Color.WHITE);
        mRvReadCategory.setBackgroundColor(ViewUtils.getColor(R.color.black));
        mReadCategoryAdapter.notifyDataSetChanged();
        mTiTleLayout.setBackgroundColor(ViewUtils.getColor(R.color.read_menu_bg_night));
        mReadTopMenu.setBackgroundColor(ViewUtils.getColor(R.color.read_menu_bg_night));
        mReadTitleTv.setTextColor(ViewUtils.getColor(R.color.standard_black_second_level_color_c4));
        mReadBottomMenu.setBackgroundColor(ViewUtils.getColor(R.color.read_menu_bg_night));
        mReadTvNightMode.setText(StringUtils.getString(R.string.ebk_read_mode_morning));
        Drawable drawable = ContextCompat.getDrawable(this, R.mipmap.icon_read_botton_day_g);
        mReadTvNightMode.setCompoundDrawablesWithIntrinsicBounds(null, drawable, null, null);
        ViewUtils.setAndroidMWindowsBarTextWhite(this);
        mAdLayout.setNightMode(true);
        mExtraPageMgr.setNightMode(true);
    }

    private void showSystemBar() {
        BaseApplication.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!FringeUtils.hasNotchScreen(ReadActivity.this)) {
                    StatusBarUtils.showUnStableStatusBar(ReadActivity.this);
                }
                if (isFullScreen) {
                    StatusBarUtils.showUnStableNavBar(ReadActivity.this);
                }
            }
        }, 50);
    }

    private void hideSystemBar() {
        BaseApplication.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                StatusBarUtils.hideStableStatusBar(ReadActivity.this);
                if (isFullScreen) {
                    StatusBarUtils.hideStableNavBar(ReadActivity.this);
                }
            }
        }, 50);

    }

    private boolean hideReadMenu() {
        hideSystemBar();
        if (mReadTopMenu.getVisibility() == VISIBLE) {
            toggleMenu(true);
            return true;
        } else if (mSettingDialog.isShowing()) {
            mSettingDialog.dismiss();
            return true;
        }
        return false;
    }

    private void toggleMenu(boolean hideStatusBar) {
        initMenuAnim();

        if (mReadTopMenu.getVisibility() == View.VISIBLE) {
            mReadTopMenu.startAnimation(mTopOutAnim);
            mBottomOutAnim.start();
            mReadTopMenu.setVisibility(GONE);
            mReadTvPageTip.setVisibility(GONE);

            if (hideStatusBar) {
                hideSystemBar();
            }
        } else {
            mReadTopMenu.setVisibility(View.VISIBLE);
            mReadTopMenu.startAnimation(mTopInAnim);
            mBottomInAnim.start();

            showSystemBar();
        }
    }

    private void initMenuAnim() {
        if (mTopInAnim != null) {
            mTopInAnim.cancel();
            mTopOutAnim.cancel();
            mBottomInAnim.cancel();
            mBottomOutAnim.cancel();
            return;
        }

        mTopInAnim = AnimationUtils.loadAnimation(this, R.anim.slide_top_in);
        mTopOutAnim = AnimationUtils.loadAnimation(this, R.anim.slide_top_out);
        ObjectAnimator animator1 = ObjectAnimator.ofFloat(mReadBottomMenuRoot, "translationY", ViewUtils.dp2px(56), 0);
        animator1.setDuration(400);
        mBottomInAnim = animator1;
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(mReadBottomMenuRoot, "translationY", 0, ViewUtils.dp2px(56));
        animator2.setDuration(400);
        mBottomOutAnim = animator2;
        mTopOutAnim.setDuration(200);
        mBottomOutAnim.setDuration(200);
    }

    public void toDayMode() {
        isNightMode = false;
        mPageLoader.setNightMode(false);
        toggleNightMode();
    }


    @Override
    public void onClick(@NonNull View v) {
        int id = v.getId();
        if (id == R.id.read_tv_category) {
            toggleMenu(true);
            mDrawerLayout.openDrawer(Gravity.START);
            StatisHelper.onEvent().catalogClick(mBook == null ? "" : mBook.bookName);
        } else if (id == R.id.read_tv_night_mode) {
            isNightMode = !isNightMode;
            mPageLoader.setNightMode(isNightMode);
            toggleNightMode();
        } else if (id == R.id.read_tv_setting) {
            toggleMenu(false);
            mSettingDialog.show();
            StatisHelper.onEvent().readSetClick(mBook == null ? "" : mBook.bookName);
        } else if (id == R.id.order_type) {
            changeOrder();
        } else if (id == R.id.catalogue_btn) {
            mDrawerLayout.closeDrawer(Gravity.START);
            setCategorySelect(mPageLoader.getCurrGroupPos(), mPageLoader.getCurrChapterPos());
        } else if (id == R.id.toolbar_back) {
            finish();
        } else if (id == R.id.guide_btn) {
            mGuideView.setVisibility(GONE);
        } else {
            super.onClick(v);
        }
    }

    private void changeOrder() {
        if (mBook == null) {
            return;
        }
        if (mRvReadCategory.isLoading()) {
            ToastUtils.showLimited(R.string.is_loading);
            return;
        }

        mRvReadCategory.setIsLoad(true);
        mIsNormalOrderType = !mIsNormalOrderType;
        setOrderTv();
        int group = mIsNormalOrderType ? 0 : mTxtChapters.size() - 1;
        int type = mIsNormalOrderType ? ReadPresenter.LOAD_CATALOGUE_TYPE_POSITIVE : ReadPresenter.LOAD_CATALOGUE_TYPE_REVERSE;
        if (mTxtChapters.get(group).size() != 0) {
            mType = type;
            refreshCatalogue();
            mRvReadCategory.setIsLoad(false);
            return;
        }
        mReadPresenter.loadCatalogue(mBook.bookId, mBook.chapterCount, group, type);
    }

    @Override
    public void loadBookChaptersSuccess(List<ChapterListBean> chapterListBeans) {
        ChapterListBean listBean = chapterListBeans.get(0);
        mBook = listBean.mOwnBook;
        mType = ReadPresenter.LOAD_CATALOGUE_TYPE_NORMAL;
        StatisHelper.onEvent().bookReading(mBook.bookName, mFrom);
        mExtraPageMgr.init(mHasChapterAd ? mAdHelper : null, this, mBook);
        int chapterCount = mBook.getChapterCount();
        int groupCount = chapterCount % 50 == 0 ? chapterCount / 50 : chapterCount / 50 + 1;
        if (bookChapterList == null) {
            bookChapterList = new ArrayList<>(groupCount);
            for (int i = 0; i < groupCount; i++) {
                bookChapterList.add(new ArrayList<ChapterBean>());
            }
        }
        for (ChapterListBean chapterListBean : chapterListBeans) {
            bookChapterList.set(chapterListBean.mGroupIndex, chapterListBean.getList());
        }
        mBook.bookChapterList = bookChapterList;
        setToolBarLayout(mBook.getBookName());
        mPageLoader.openBook(mBook);
        showGuide();
    }

    private void showGuide() {
        boolean hasShowed = SPUtils.INSTANCE.getBoolean("read_guide", false);
        if (!hasShowed) {
            mGuideView.setVisibility(VISIBLE);
            SPUtils.INSTANCE.putBoolean("read_guide", true);
        }
    }

    @Override
    public void preLoadBookChaptersSuccess(ChapterListBean chapterListBean, int groupPos) {
        bookChapterList.set(groupPos, chapterListBean.getList());
        mType = ReadPresenter.LOAD_CATALOGUE_TYPE_PRE;
        mPageLoader.onChaptersGroupUpdate(groupPos);
    }

    @Override
    public void loadCatalogueSuccess(ChapterListBean chapterListBean, int groupPos, int type) {
        mType = type;
        bookChapterList.set(groupPos, chapterListBean.getList());
        if (type == ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE) {
            mRvReadCategory.onLoadMoreTopComplete();
        } else if (type == ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE) {
            mRvReadCategory.onLoadMoreBottomComplete();
        }
        mPageLoader.onChaptersGroupUpdate(groupPos);
        if (type == ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE) {
            mRvReadCategory.setSelection(50);
        }
    }

    @Override
    public void loadCatalogueFailed(int groupPos, int type) {
        if (type == ReadPresenter.LOAD_CATALOGUE_TYPE_TOP_MORE) {
            mRvReadCategory.onLoadMoreTopComplete();
        } else if (type == ReadPresenter.LOAD_CATALOGUE_TYPE_BOTTOM_MORE) {
            mRvReadCategory.onLoadMoreBottomComplete();
        }
        mRvReadCategory.setIsLoad(false);
        ToastUtils.showLimited(R.string.load_failed);
    }

    @Override
    public void loadChapterContentsSuccess() {
        if (mPageLoader.getPageStatus() == AbsPageLoader.STATUS_LOADING) {
            mPvReadPage.post(new Runnable() {
                @Override
                public void run() {
                    mPageLoader.showChapterContent();
                }
            });
        }
    }

    @Override
    public void loadChapterContentsFailed() {
        if (mPageLoader.getPageStatus() == AbsPageLoader.STATUS_LOADING) {
            mPageLoader.showError();
        }
    }


    @Override
    public void onBackPressed() {
        if (mReadTopMenu.getVisibility() == View.VISIBLE) {
            if (!ReadSettingManager.getInstance().isFullScreen()) {
                toggleMenu(true);
                return;
            }
        } else if (mSettingDialog.isShowing()) {
            mSettingDialog.dismiss();
            return;
        } else if (mDrawerLayout.isDrawerOpen(Gravity.START)) {
            mDrawerLayout.closeDrawer(Gravity.START);
            return;
        }

        super.onBackPressed();
    }

    @Override
    public void finish() {
        if (mBook == null) {
            super.finish();
            return;
        }
        if (mBook.mIsInShelf) {
            BaseApplication.handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    showInsertAd();
                }
            }, 100);

            super.finish();
        } else {
            showShelfDialog();
        }
    }

    private void showShelfDialog() {
        MTDialog dialog = new MTDialog(this);
        dialog.setTitle(R.string.add_shelf);
        dialog.setMessage(R.string.add_shelf_msg);
        dialog.setPositiveButton(R.string.add, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                StatisHelper.onEvent().subscription(mBook.bookName, "退出阅读页提示加入书架");
                mReadPresenter.addBookToShelf(mBook);
                ReadActivity.super.finish();
            }
        });
        dialog.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                ReadActivity.super.finish();
            }
        });
        dialog.show();
    }

    private void showInsertAd() {
        if (!AdMgr.INSTANCE.isShowAd(AdMgr.AD_READ_SCREEN)) {
            return;
        }

        BaseActivity topActivity = BaseApplication.context.getTopActivity();
        IAdHelper adHelper = AdMgr.INSTANCE.createAdHelper(topActivity);
        AdParam adParam = AdMgr.INSTANCE.getAdParam(AdMgr.AD_READ_SCREEN, getPageName());
        AdMgr.INSTANCE.loadInteractionAd(adHelper, adParam, topActivity);

    }

    @Override
    protected void onResume() {
        super.onResume();
        mBrightMgr.acquireWakeLock(60 * 60 * 1000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mBrightMgr.releaseWakeLock();
        mPageLoader.saveRecord();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mReceiver);
        mPageLoader.closeBook();
        mAdLayout.destroy();
        mExtraPageMgr.destroy();
    }
}
