package com.zydm.base.tools

interface Supplier<T> {

    fun get(): T
}