package com.zydm.base.presenter.view;

public interface ISimplePageView<D> extends IPageView {

    void showPage(D data);
}
