package com.zydm.base.widgets;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zydm.base.R;
import com.zydm.base.common.Constants;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.utils.TimeUtils;
import com.zydm.base.utils.ViewUtils;

public class MsgExpandTextView extends LinearLayout
        implements
        OnClickListener {

    private static final String TAG = "ExpandableTextView";
    /**
     * TextView
     */
    private TextView mTextViewContent;

    /**
     * 收起/全部TextView
     * <br>shrink/expand TextView
     */
    private TextView mTvState;

    /**
     * 点击进行折叠/展开的图片
     * <br>shrink/expand icon
     */
    private ImageView mImgState;

    /**
     * 底部是否折叠/收起的父类布局
     * <br>shrink/expand layout parent
     */
    private LinearLayout mToggleLayout;

    /**
     * 提示折叠的图片资源
     * <br>shrink drawable
     */
    private Drawable drawableShrink;
    /**
     * 提示显示全部的图片资源
     * <br>expand drawable
     */
    private Drawable drawableExpand;

    /**
     * 全部/收起文本的字体颜色
     * <br>color of shrink/expand text
     */
    private int textViewStateColor;
    /**
     * 展开提示文本
     * <br>expand text
     */
    private String textExpand;
    /**
     * 收缩提示文本
     * <br>shrink text
     */
    private String textShrink;


    /**
     * 是否初始化TextView
     * <br>flag of TextView Initialization
     */
    private boolean isInitTextView = true;

    /**
     * 折叠显示的行数
     * <br>number of lines to expand
     */
    private int expandLines;

    /**
     * 文本的行数
     * <br>Original number of lines
     */
    private int textLines;

    /**
     * 显示的文本
     * <br>content text
     */
    private String mTextContent;

    /**
     * 显示的文本颜色
     * <br>content color
     */
    private int textContentColor;

    /**
     * 显示的文本字体大小
     * <br>content text size
     */
    private float textContentSize;

    /**
     * 显示的背景颜色
     * <br>root layout background color
     */
    private int rootBackColor;


    //    private View mOfficalLayout;
    private View mFeedBackLayout;
    private TextView mFeedBackDate;
    private TextView mFeedBackType;
    private TextView mFeedBackContent;

    //是否处于收缩状态
    private boolean isShrink;
    private ExpandStateChangeListener mExpandStateChangeListener;
    private LinearLayout mRootLayout;


    public MsgExpandTextView(Context context) {
        super(context);
        init(context, null);
    }

    public MsgExpandTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public MsgExpandTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        initValue(context, attrs);
        initView(context);
        setClick(this);
    }

    private void initValue(Context context, AttributeSet attrs) {

        if (null == attrs) {
            return;
        }

        TypedArray ta = context.obtainStyledAttributes(attrs,
                R.styleable.MsgExpandTextView);

        expandLines = ta.getInteger(
                R.styleable.MsgExpandTextView_tvea_expandLines, 3);

        drawableShrink = ta
                .getDrawable(R.styleable.MsgExpandTextView_tvea_shrinkBitmap);
        drawableExpand = ta
                .getDrawable(R.styleable.MsgExpandTextView_tvea_expandBitmap);

        textViewStateColor = ta.getColor(R.styleable.MsgExpandTextView_tvea_textStateColor,
                ViewUtils.getColor(R.color.standard_text_color_light_gray));

        rootBackColor = ta.getColor(R.styleable.MsgExpandTextView_tvea_backgroundColor,
                Color.WHITE);

        textShrink = ta.getString(R.styleable.MsgExpandTextView_tvea_textShrink);
        textExpand = ta.getString(R.styleable.MsgExpandTextView_tvea_textExpand);

        if (null == drawableShrink) {
            drawableShrink = ContextCompat.getDrawable(context, R.mipmap.icon_personal_center_news_arrow_upper);
        }

        if (null == drawableExpand) {
            drawableExpand = ContextCompat.getDrawable(context, R.mipmap.icon_personal_center_news_arrow_down);
        }

        if (TextUtils.isEmpty(textShrink)) {
            textShrink = context.getString(R.string.shrink);
        }

        if (TextUtils.isEmpty(textExpand)) {
            textExpand = context.getString(R.string.expand);
        }


        textContentColor = ta.getColor(R.styleable.MsgExpandTextView_tvea_textContentColor,
                ViewUtils.getColor(R.color.standard_text_color_black));
        textContentSize = ta.getDimension(R.styleable.MsgExpandTextView_tvea_textContentSize, 13);

        ta.recycle();
    }

    private void initView(Context context) {

        View.inflate(context, R.layout.expandable_layout, this);
        mRootLayout = (LinearLayout) findViewById(R.id.root_layout);
        mToggleLayout = (LinearLayout) findViewById(R.id.toggle_layout);

        mTextViewContent = (TextView) findViewById(R.id.expand_tv);
        mTextViewContent.setBackgroundColor(rootBackColor);
        mTextViewContent.setTextColor(textContentColor);
        mTextViewContent.setTextSize(TypedValue.COMPLEX_UNIT_DIP, textContentSize);

        mImgState = (ImageView) findViewById(R.id.toggle_img);

        mTvState = (TextView) findViewById(R.id.toggle_text);
        mTvState.setTextColor(textViewStateColor);

        changeTextState(false);

//        mOfficalLayout = findViewById(R.id.offical_name_layout);
        mFeedBackLayout = findViewById(R.id.feedback_layout);
        mFeedBackLayout.setBackgroundColor(rootBackColor);
        mFeedBackDate = (TextView) findViewById(R.id.private_tv_feedback_date);
        mFeedBackType = (TextView) findViewById(R.id.private_tv_feedback_type);
        mFeedBackContent = (TextView) findViewById(R.id.private_tv_feedback_content);

    }

    private void setClick(OnClickListener listener) {
        this.setOnClickListener(listener);
    }

    public void setOnClick(OnClickListener listener) {
        if (null == listener) {
            this.setClick(this);
        } else {
            this.setOnClickListener(listener);
        }
    }

    public void setPriMsgText(String textContent, boolean isShrink) {
        mTextContent = StringUtils.isBlank(textContent) ? Constants.EMPTY : textContent;
        mTextViewContent.setText(textContent);
        setFeedBackVisible(false);
//        mRootLayout.removeView(mOfficalLayout);
//        mRootLayout.addView(mOfficalLayout, 2);
        setTextContent(isShrink);
    }

    public void setFeedBackText(String textContent, String time, String typeName, String content, boolean isShrink) {

        mTextContent = StringUtils.isBlank(textContent) ? Constants.EMPTY : textContent;

        mTextViewContent.setText(textContent);

        setFeedBackDate(time);
        setFeedBackType(typeName);
        setFeedBackContent(content);
        setTextContent(isShrink);
    }

    private void setTextContent(final boolean isShrink) {
        mTextViewContent.post(new Runnable() {
            @Override
            public void run() {
                textLines = mTextViewContent.getLineCount();

                if (StringUtils.isBlank(mTextContent)) {
                    //隐藏折叠
                    toggleTextState(false);
                } else {
                    if (textLines <= expandLines) {
                        //展示折叠并且隐藏反馈数据
                        toggleTextState(true);
                    } else {
                        mTextViewContent.setMaxLines(expandLines);
                        toggleTextState(true);
                    }
                    toggleLayout(isShrink, false);
                }

            }
        });
    }

    /**
     * 隐藏折叠按钮，并且展示反馈数据
     */
    private void toggleTextState(boolean isExpandNeed) {
        isShrink = isExpandNeed;
        ViewUtils.setViewVisible(mToggleLayout, isExpandNeed);
        if (!isExpandNeed) {
            setClick(null);
        } else {
            setClick(this);
        }

        toggleFeedBackLayout(!isExpandNeed);
    }

    private void toggleFeedBackLayout(boolean visible) {
        ViewUtils.setViewVisible(mFeedBackLayout, visible);
//        ViewUtils.setViewVisible(mOfficalLayout, visible);
    }

    private void setFeedBackDate(String feedBackDate) {

        String date = TimeUtils.formatDateStyleCharacter(feedBackDate);
        setTextWhenVisible(mFeedBackDate, "关于您在" + date + "反馈给" + ViewUtils.getString(R.string.offical_name) + "的问题");
    }

    private void setFeedBackType(String feedBackType) {
        setTextWhenVisible(mFeedBackType, feedBackType);
    }

    private void setFeedBackContent(String feedBackContent) {
        setTextWhenVisible(mFeedBackContent, feedBackContent);
    }

    private void setTextWhenVisible(TextView textView, String text) {
        if (StringUtils.isBlank(text)) {
            textView.setVisibility(GONE);
        } else {
            textView.setVisibility(VISIBLE);
            textView.setText(text);
        }
    }

    private void setFeedBackVisible(boolean isVisible) {
        ViewUtils.setViewVisible(mFeedBackDate, isVisible);
        ViewUtils.setViewVisible(mFeedBackType, isVisible);
        ViewUtils.setViewVisibleOrInvisible(mFeedBackContent, isVisible);
    }

    @Override
    public void onClick(View v) {
        clickImageToggle();
    }

    private void clickImageToggle() {
        if (isShrink) {
            // 如果是已经折叠，那么进行非折叠处理
            toggleLayout(true, true);
        } else {
            // 如果是非折叠，那么进行折叠处理
            toggleLayout(false, true);
        }
    }

    private void toggleLayout(boolean open, boolean isClickStatus) {
        if (open) {
            if (textLines > expandLines) {
                mTextViewContent.setMaxLines(textLines);
                mTextViewContent.postInvalidate();
            }
            toggleFeedBackLayout(true);
            changeTextState(true);
        } else {
            if (textLines > expandLines) {
                mTextViewContent.setMaxLines(expandLines);
                mTextViewContent.postInvalidate();
            }
            toggleFeedBackLayout(false);
            changeTextState(false);
        }

        // 切换状态
        isShrink = !open;

        if (isClickStatus) {
            //点击的情况才会触发这个监听
            if (null != mExpandStateChangeListener) {
                mExpandStateChangeListener.expandStateChange(!isShrink);
            }
        }
    }

    private void changeTextState(boolean b) {
        if (!b) {
            mImgState.setBackground(drawableExpand);
            mTvState.setText(textExpand);
        } else {
            mImgState.setBackground(drawableShrink);
            mTvState.setText(textShrink);
        }
    }

    public void addExpandStateChangeListener(ExpandStateChangeListener expandStateChangeListener) {

        mExpandStateChangeListener = expandStateChangeListener;
    }

    public interface ExpandStateChangeListener {

        void expandStateChange(boolean isExpand);
    }

}
