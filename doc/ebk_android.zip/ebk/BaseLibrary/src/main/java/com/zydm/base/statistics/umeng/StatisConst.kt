package com.zydm.base.statistics.umeng

/**
 * Created by wangdy on 2017/4/21.
 */

object StatisConst {

    const val KEY_TYPE = "type"
    const val KEY_POS = "pos"
    const val KEY_NAME = "name"
    const val KEY_LINK = "link"
    const val KEY_TITLE = "title"
    const val KEY_FROM = "from"

    const val PAGE_READ = "阅读"

}
