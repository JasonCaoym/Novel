package com.zydm.base.statistics.umeng;

import android.content.Context;

import com.umeng.analytics.game.UMGameAgent;
import com.zydm.base.common.BaseApplication;
import com.zydm.base.data.base.MtMap;
import com.zydm.base.tools.PhoneStatusManager;
import com.zydm.base.utils.LogUtils;
import com.zydm.base.utils.StringUtils;

public class StatisHelper {
    private static final String TAG = StatisHelper.class.getSimpleName();
    private static final String UM_APP_KEY_PRODUCTION = "5bf50a34f1f5560f60000037";
    private static final String UM_APP_KEY_TEST = "5bf50995f1f5565481000184";

    public static void init(Context context) {
        boolean testEnv = BaseApplication.context.isTestEnv();
        String umAppKey = testEnv ? UM_APP_KEY_TEST : UM_APP_KEY_PRODUCTION;
        String channel = PhoneStatusManager.getInstance().getAppChannel();
        LogUtils.d(TAG, "init:umAppKey:" + umAppKey + " channel:" + channel);
        UMGameAgent.startWithConfigure(new UMGameAgent.UMAnalyticsConfig(context, umAppKey, channel));
        UMGameAgent.openActivityDurationTrack(false);
        UMGameAgent.setDebugMode(testEnv);
        UMGameAgent.init(context);
    }

    public static void onResume(Context context) {
        LogUtils.d(TAG, "onResume:" + context);
        UMGameAgent.onResume(context);
    }

    public static void onPause(Context context) {
        LogUtils.d(TAG, "onPause:" + context);
        UMGameAgent.onPause(context);
    }

    public static void onPageStart(String pageName) {
        if (StringUtils.isBlank(pageName)) {
            return;
        }
        LogUtils.d(TAG, "onPageStart:" + pageName);
        UMGameAgent.onPageStart(pageName);
    }

    public static void onPageEnd(String pageName) {
        if (StringUtils.isBlank(pageName)) {
            return;
        }
        LogUtils.d(TAG, "onPageEnd:" + pageName);
        UMGameAgent.onPageEnd(pageName);
    }

    public static void reportError(Throwable throwable) {
        UMGameAgent.reportError(BaseApplication.context, throwable);
    }

    public static void onProfileSignIn(String userId) {
        LogUtils.d(TAG, "onProfileSignIn:" + userId);
        UMGameAgent.onProfileSignIn(userId);
    }

    public static void onProfileSignIn(String channel, String userId) {
        LogUtils.d(TAG, "onProfileSignIn:" + userId);
        UMGameAgent.onProfileSignIn(channel, userId);
    }

    public static void onProfileSignOff() {
        LogUtils.d(TAG, "onProfileSignOff");
        UMGameAgent.onProfileSignOff();
    }

    public static EventMethods onEvent() {
        return CustomEventMgr.getInstance().onEvent();
    }

    public static void bookUV(final String bookId, final MtMap<String, String> params) {
                StringBuilder builder = new StringBuilder();
                builder.append("bookUV").append(bookId);
                String eventId = builder.toString();
                UMGameAgent.onEvent(BaseApplication.context, eventId, params);
    }

    public static void onKillProcess(Context context) {
        UMGameAgent.onKillProcess(context);
    }

    public static void setPlayerLevel(int level) {
        UMGameAgent.setPlayerLevel(level);
    }
}
