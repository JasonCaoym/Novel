package com.zydm.base.utils

import android.content.Context
import android.graphics.drawable.Drawable
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.bumptech.glide.request.target.ViewTarget
import com.bumptech.glide.request.transition.Transition
import com.zydm.base.utils.transformation.RatioBlurTransformation

/*
    Glide工具类
 */
object GlideUtils {
    fun loadImage(context: Context, url: String, imageView: ImageView) {
        val myOptions = RequestOptions()
                .centerCrop()

        Glide.with(context).load(url).apply(myOptions).into(imageView)
    }

    fun loadBackground(context: Context, url: String, view: View, blur: Boolean) {
        var requestOptions = RequestOptions().dontAnimate()
        if (blur) {
            requestOptions = requestOptions.transform(RatioBlurTransformation(50, 3))
        }
        Glide.with(context).load(url).apply(requestOptions).into(object : ViewTarget<View, Drawable>(view) {
            override fun onResourceReady(resource: Drawable, transition: Transition<in Drawable>?) {
                view.background = resource
            }
        })
    }
}
