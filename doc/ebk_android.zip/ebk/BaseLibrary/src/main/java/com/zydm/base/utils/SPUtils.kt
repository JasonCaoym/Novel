package com.zydm.base.utils

import android.content.Context
import android.content.SharedPreferences
import com.zydm.base.common.BaseApplication
import com.zydm.base.common.Constants

import java.util.HashSet

object SPUtils {

    private val TAG = "SPUtils"

    private val PREF_NAME = "acgn_pref"

    private val sPre: SharedPreferences by lazy {
        BaseApplication.context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    val all: Map<*, *>
        get() = sPre.all

    fun remove(key: String) {
        sPre.edit().remove(key).apply()
    }

    fun removeWithBack(key: String) {
        remove(key)
    }

    fun putInt(key: String, value: Int) {
        sPre.edit().putInt(key, value).apply()
    }

    fun getInt(key: String, defValue: Int): Int {
        return sPre.getInt(key, defValue)
    }

    fun putBoolean(key: String, value: Boolean) {
        sPre.edit().putBoolean(key, value).apply()
    }

    fun getBoolean(key: String, defValue: Boolean): Boolean {
        return sPre.getBoolean(key, defValue)
    }

    fun putString(key: String, value: String) {
        sPre.edit().putString(key, value).apply()
    }

    fun putStringSet(key: String, values: Set<String>) {
        sPre.edit().putStringSet(key, values).apply()
    }

    fun getStringSet(key: String): Set<String> {
        return sPre.getStringSet(key, HashSet())
    }

    @JvmOverloads
    fun getString(key: String, defValue: String = Constants.EMPTY): String {
        return sPre.getString(key, defValue)
    }

    fun putLong(key: String, value: Long) {
        sPre.edit().putLong(key, value).apply()
    }

    fun getLong(key: String, defValue: Long): Long {
        return sPre.getLong(key, defValue)
    }

    fun putFloat(key: String, value: Float) {
        sPre.edit().putFloat(key, value).apply()
    }

    fun getFloat(key: String, defValue: Float): Float {
        return sPre.getFloat(key, defValue)
    }

}
