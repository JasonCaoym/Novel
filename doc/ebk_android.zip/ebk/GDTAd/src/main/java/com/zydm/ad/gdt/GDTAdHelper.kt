package com.zydm.ad.gdt

import android.app.Activity
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import com.qq.e.ads.nativ.ADSize
import com.qq.e.ads.nativ.NativeExpressAD
import com.qq.e.ads.nativ.NativeExpressADView
import com.qq.e.ads.splash.SplashAD
import com.qq.e.ads.splash.SplashADListener
import com.qq.e.comm.util.AdError
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.setVisible
import com.zydm.base.utils.LogUtils
import com.zydm.ebk.provider.ad.*
import com.zydm.ebk.provider.data.bean.AdConstants
import com.qq.e.ads.interstitial.AbstractInterstitialADListener
import com.qq.e.ads.interstitial.InterstitialAD



class GDTAdHelper(private val mActivity: Activity): IAdHelper {

    companion object {
        private const val TAG = "GDTAdHelper"

        private const val APP_ID = "1107985337"
    }

    private val mListenerSet = HashSet<ADListener>()

    override fun addListener(adListener: ADListener) {
        mListenerSet.add(adListener)
    }

    override fun removeListener(adListener: ADListener) {
        mListenerSet.remove(adListener)
    }

    override fun loadBannerAd(adParam: AdParam, containerView: ViewGroup) {
        containerView.setVisible(false)
    }

    override fun loadBannerAd(adParam: AdParam, loadBannerAdListener: LoadBannerAdListener) {
        loadBannerAdListener.onLoadBanner(null)
    }

    override fun loadSplashAd(adParam: AdParam, containerView: ViewGroup) {
        SplashAD(mActivity, containerView, APP_ID, adParam.mConfig.slotId, object : SplashADListener {
            override fun onNoAD(p0: AdError?) {
                onAdError(adParam, p0?.errorCode?:-1, p0?.errorMsg)
            }

            override fun onADExposure() {
                onAdShow(adParam)
            }

            override fun onADDismissed() {
                onAdDismiss(adParam, "")
            }

            override fun onADPresent() {
                LogUtils.d(TAG, "loadSplashAd onADPresent")
            }

            override fun onADClicked() {
                onAdClicked(adParam, "")
            }

            override fun onADTick(p0: Long) {
                LogUtils.d(TAG, "onADTick p0 $p0")
            }
        })
    }

    override fun loadInteractionAd(adParam: AdParam) {
        val iad = InterstitialAD(mActivity, APP_ID, adParam.mConfig.slotId)
        iad.setADListener(object : AbstractInterstitialADListener() {
            override fun onNoAD(error: AdError) {
                LogUtils.d(TAG, "onNoAD")
                onAdError(adParam, -1, "onNoAD")
            }

            override fun onADReceive() {
                iad.show()
            }
        })
        iad.loadAD()
    }

    override fun loadNativeAd(adParam: AdParam, callback: NativeAdCallback) {
        val nativeExpressAD = NativeExpressAD(mActivity, ADSize(ADSize.FULL_WIDTH, ADSize.AUTO_HEIGHT), APP_ID, adParam.mConfig.slotId, object : NativeExpressAD.NativeExpressADListener {
            override fun onADCloseOverlay(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onADCloseOverlay")
            }

            override fun onADOpenOverlay(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onADOpenOverlay")
            }

            override fun onRenderSuccess(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onRenderSuccess")
            }

            override fun onRenderFail(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onRenderFail")
                onAdError(adParam, -1, "onRenderFail")
                callback.callback(null)
            }

            override fun onADExposure(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onADExposure")
                onAdShow(adParam)
            }

            override fun onADClosed(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onADClosed")
            }

            override fun onADLeftApplication(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onADLeftApplication")
            }

            override fun onNoAD(p0: AdError?) {
                LogUtils.d(TAG, "onNoAD")
                onAdError(adParam, -1, "onNoAD")
                callback.callback(null)
            }

            override fun onADClicked(p0: NativeExpressADView?) {
                LogUtils.d(TAG, "onADClicked")
                onAdClicked(adParam, "")
            }

            override fun onADLoaded(p0: MutableList<NativeExpressADView>?) {
                LogUtils.d(TAG, "onADLoaded")
                if (p0 == null) {
                    callback.callback(null)
                    return
                }
                val adSrc = ArrayList(p0)
                if (DataUtils.isEmptyList(adSrc)) {
                    callback.callback(null)
                    return
                }

                val list = ArrayList<NativeAd>()
                adSrc.forEach {
                    list.add(transform(adParam, it))
                }

                callback.callback(list[0])
                callback.callback(ArrayList(list))
            }
        })

        nativeExpressAD.loadAD(adParam.mCount)
    }

    private fun transform(adParam: AdParam, nativeAd: NativeExpressADView?): NativeAd {
        return object : NativeAd{
            override fun getAdParam(): AdParam {
                return adParam
            }

            override fun getAdLogo(): Bitmap? {
                return null
            }

            override fun getTitle(): String {
                return ""
            }

            override fun getDescription(): String {
                return ""
            }

            override fun getSource(): String {
                return ""
            }

            override fun getIcon(): String {
                return ""
            }

            override fun getImageList(): List<String> {
                return ArrayList()
            }

            override fun getInteractionType(): Int {
                return 0
            }

            override fun getImageMode(): Int {
                return AdConstants.IMG_VIEW
            }

            override fun registerViewForInteraction(var1: ViewGroup, clickView: View, creativeView: View) {

            }

            override fun registerViewForInteraction(var1: ViewGroup, var2: List<View>, var3: List<View>) {
            }

            override fun getAdView(): View? {
                nativeAd?.setTag(this)
                return nativeAd
            }

            override fun render() {
                nativeAd?.render()
            }

            override fun destroy() {
                LogUtils.d(TAG, "ad destory")
                nativeAd?.destroy()
            }
        }
    }

    private fun onAdShow(adParam: AdParam) {
        LogUtils.d(TAG, "onAdShow  adParam $adParam")
        mListenerSet.forEach {
            it.onAdShow(adParam)
        }
    }

    private fun onAdClicked(adParam: AdParam, from: String = "") {
        LogUtils.d(TAG, "onAdClicked  adParam $adParam")
        mListenerSet.forEach {
            it.onAdClicked(adParam, from)
        }
    }

    private fun onAdDismiss(adParam: AdParam, reason: String) {
        LogUtils.d(TAG, "onAdDismiss  adParam $adParam")
        mListenerSet.forEach {
            it.onAdDismiss(adParam, reason)
        }
    }

    private fun onAdError(adParam: AdParam, code: Int, msg: String?) {
        LogUtils.d(TAG, "onAdError  adParam $adParam code $code  msg $msg")
        mListenerSet.forEach {
            it.onAdError(adParam, code, msg ?: "")
        }
    }
}