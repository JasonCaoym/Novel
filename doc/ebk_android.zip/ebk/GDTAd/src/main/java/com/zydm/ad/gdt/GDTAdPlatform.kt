package com.zydm.ad.gdt

import android.app.Activity
import android.content.Context
import com.alibaba.android.arouter.facade.annotation.Route
import com.zydm.ebk.provider.ad.IAdHelper
import com.zydm.ebk.provider.ad.IAdPlatform
import com.zydm.ebk.provider.router.RouterPath

@Route(path = RouterPath.GDTAd.PATH_AD_GDT_PLATFORM)
class GDTAdPlatform: IAdPlatform {

    override fun initPlatform(activity: Activity) {

    }

    override fun createHelper(activity: Activity): IAdHelper {
        return GDTAdHelper(activity)
    }

    override fun init(context: Context?) {
    }
}