package com.zydm.ebk.common

import android.content.Intent
import com.zydm.base.common.BaseApplication
import com.zydm.base.utils.LogUtils
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.statistics.motong.MtStEventMgr
import com.zydm.statistics.motong.MtStHelper
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.ebk.ui.SplashActivity

class MainApplication : BaseApplication() {

    override fun onCreate() {
        super.onCreate()
//        UiThreadBlockWatcher.install(3000, UiThreadBlockWatcher.TYPE_LOOPER);
        MtStHelper.visit()
        ConfigMgr.loadConfig()
        StatisHelper.init(this)
    }

    override fun onForegroundChanged(onForeground: Boolean) {
        super.onForegroundChanged(onForeground)
        if (onForeground) {
            startAd()
            LogUtils.initDebugLogSwitch()
            if (!MtStHelper.visit()) {
                MtStEventMgr.getInstance().upload()
            }
        } else {
            //到后台重新刷新一个push列表
            MtStEventMgr.getInstance().upload()
            AdMgr.saveConfig()
            AdMgr.onAppGoBackground()
        }
    }

    private fun startAd() {
        val activity = topActivity ?: return

        if (activity is SplashActivity) {
            return
        }

        if (!AdMgr.isShowAd(AdMgr.AD_SPLASH)) {
            return
        }

        val intent = Intent(activity, SplashActivity::class.java)
        intent.putExtra(BaseActivity.DATA_KEY, true)
        activity.startActivity(intent)
    }

    override fun quitActivity(baseActivity: BaseActivity) {
        AdMgr.clearCache()
    }

}
