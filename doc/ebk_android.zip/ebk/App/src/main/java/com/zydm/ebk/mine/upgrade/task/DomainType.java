package com.zydm.ebk.mine.upgrade.task;

/**
 * Created by yan on 2017/5/3.
 */

public class DomainType {
    public static final int DEFAULT = 0;
    public static final int SEARCH = 1;
    public static final int STATISTICS = 2;
    public static final int H5_PAGE = 3;
}
