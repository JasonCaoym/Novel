package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.common.BaseApplication;
import com.zydm.base.tools.PhoneStatusManager;

import java.util.Map;

public class ApiParamConst {

    public static final String DEVICE_ID = "deviceId";
    public static final String DEVICE_MODEL = "model";
    public static final String SYSTEM_VERSION = "sysVer";
    public static final String DEVICE_RESOLUTION = "resolution";
    public static final String LOCATION = "loc";
    public static final String NETWORK_TYPE = "netType";
    public static final String APP_CHANNEL = "appChannel";
    public static final String APP_VERSION = "appVer";
    public static final String CLIENT = "client";
    public static final String IMEI = "imei";
    public static final String TOKEN = "token";
    public static final String CURSOR = "cursor";
    public static final String COUNT = "count";
    public static final String PACKAGE = "package";
    public static final String VERSION_CODE = "versionCode";
    public static final String KEYWORD = "keyword";
    public static final String PHONE = "phone";
    public static final String AREA_PHONE_CODE = "areaCode"; //区号
    public static final String PASSWORD = "password";
    public static final String CAPTCHA = "captcha";
    public static final String SCENE = "scene";
    public static final String USER_NAME = "userName";
    public static final String SEX = "sex";
    public static final String USER_ICON = "userIcon";
    public static final String BOOK_IDS = "bookIds";
    public static final String THIRD_UNION_OPEN_ID = "unionOpenUid";
    public static final String THIRD_UNION_ID = "unionId";
    public static final String THIRD_UNION_TOKEN = "unionToken";
    public static final String THIRD_OPEN_TYPE = "openType";
    // 2017/5/27-下午3:41 qq需要特殊参数pf
    public static final String THIRD_QQ_PF = "pf";
    public static final String THIRD_QQ_PF_KEY = "pfkey";
    public static final String BOOK_ID = "bookId";
    public static final String QUESTION_CONTACT = "contact";
    public static final String QUESTION_TYPE_ID = "typeId";
    public static final String QUESTION_CONTENT = "content";
    public static final String PASSWORD_NEW = "passwordNew";
    public static final String CHAPTER_ID = "chapterId";
    public static final String USER_INFO = "userInfo";
    private static final String ANDROID_ID = "androidId";
    private static final String DEVICE_ID_SRC = "dis";

    public static void addCommonParam(Map<String, String> params) {
        PhoneStatusManager phone = PhoneStatusManager.getInstance();
        params.put(ApiParamConst.DEVICE_ID, phone.getEncryptedDeviceId());
        params.put(ApiParamConst.DEVICE_ID_SRC, phone.getDeviceIdSrc());
        params.put(ApiParamConst.IMEI, phone.getImei());
        params.put(ApiParamConst.ANDROID_ID, phone.getAndroidId());
        params.put(ApiParamConst.DEVICE_MODEL, phone.getDeviceModel());
        params.put(ApiParamConst.SYSTEM_VERSION, phone.getSystemVersion());
        params.put(ApiParamConst.DEVICE_RESOLUTION, phone.getResolution()[0] + "*"
                + phone.getResolution()[1]);
        params.put(ApiParamConst.LOCATION, phone.getLongitudeAndLatitude()[0] + "*"
                + phone.getLongitudeAndLatitude()[1]);
        params.put(ApiParamConst.NETWORK_TYPE, phone.getNetworkConnectionType());
        params.put(ApiParamConst.APP_CHANNEL, phone.getAppChannel());
        params.put(ApiParamConst.APP_VERSION, phone.getAppVersionName());
        params.put(ApiParamConst.CLIENT, PhoneStatusManager.CLIENT_TYPE);
        params.put(PACKAGE, BaseApplication.context.getPackageName());
    }
}
