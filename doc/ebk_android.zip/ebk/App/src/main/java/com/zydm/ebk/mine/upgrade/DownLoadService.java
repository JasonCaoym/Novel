package com.zydm.ebk.mine.upgrade;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.Vibrator;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.widget.RemoteViews;

import com.zydm.base.common.Constants;
import com.zydm.base.common.NotificationVersionAdapter;
import com.zydm.base.tools.PhoneStatusManager;
import com.zydm.base.utils.StringUtils;
import com.zydm.ebk.R;
import com.zydm.ebk.ui.HomeActivity;

public class DownLoadService extends Service implements UpgradeHelper.DownloadStateListener {

    private static final String TAG = "DownLoadService";
    private static final int NOTIFI_ID = 1;
    private long[] vibrates = new long[]{10, 100, 20, 200};

    private UpdateInfoBean mInfoBean;
    private String mTitle;

    private Intent intent = new Intent(UpgradeManager.PROGRESS_BROAD);
    private Intent closeIntent = new Intent(UpgradeManager.CLOSE_DOWN_SERVICE_BROAD);

    private int mTotal;
    private int mProgress;

    public DownLoadService() {
    }

    @Override
    public IBinder onBind(Intent intent) {

        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (null != intent) {
            mInfoBean = (UpdateInfoBean) intent.getSerializableExtra(UpgradeManager.UPDATE_INFO);
        }

        if (null != mInfoBean) {
            if (null != mInfoBean.info) {
                mTotal = (int) mInfoBean.info.size;
            }
        }

        startUpdate();
        updateNotification(Constants.ZERO_NUM, mTotal);
        return super.onStartCommand(intent, flags, startId);
    }

    private void updateNotification(int progress, int total) {
        NotificationCompat.Builder builder = getNotificationBuilder();
        builder.setVibrate(new long[]{0});
        builder.setSound(null);
        Notification notification = builder.build();
        notification.contentView.setProgressBar(R.id.progress_bar, total, progress, false);
        notification.contentView.setTextViewText(R.id.noti_percentage, StringUtils.getPercentage(progress, total));
        notification.flags = Notification.FLAG_AUTO_CANCEL;
        notification.contentView.setTextViewText(R.id.noti_title, mTitle == null ? "" : mTitle);
        startForeground(NOTIFI_ID, notification);
    }

    private void startUpdate() {
        UpgradeHelper.getInstance(this).addDownloadStateListener(this);

        if (mInfoBean != null) {
            UpgradeHelper.getInstance(this).startDownload(mInfoBean.info, false);
        }
    }

    private RemoteViews getRemoteView() {
        RemoteViews remoteViews = new RemoteViews(getPackageName(), R.layout.download_notification);
        return remoteViews;
    }

    @NonNull
    private NotificationCompat.Builder getNotificationBuilder() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        NotificationVersionAdapter.getInstance().adapter(builder);
        String versionName = mInfoBean == null ? PhoneStatusManager.getInstance().getAppVersionName() : mInfoBean.info.versionName;
        mTitle = getString(R.string.upgrade_title, versionName);
        builder.setContent(getRemoteView()).setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(Notification.PRIORITY_DEFAULT).setContentIntent(getDefaultIntent(Notification.FLAG_AUTO_CANCEL)).setOngoing(true);
        return builder;
    }

    public PendingIntent getDefaultIntent(int flags) {
        Intent intent = new Intent(this, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, NOTIFI_ID, intent, flags);
        return pendingIntent;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // 在服务销毁的时候，使当前服务推出前台，并销毁显示的通知
        stopForeground(true);
    }

    @Override
    public void downloadStart() {
        startVibrator();
    }

    @Override
    public void downloadSuccessful() {
        startVibrator();
        closeForegroundService();
    }

    private void startVibrator() {
        Vibrator vibrator = (Vibrator) getApplication().getSystemService(Service.VIBRATOR_SERVICE);
        vibrator.vibrate(Constants.MILLIS_200);//震半秒钟
        vibrator.vibrate(vibrates, -1);
    }

    @Override
    public void downloadFailed() {
        closeForegroundService();
    }

    @Override
    public void directInstall() {
        closeForegroundService();
    }

    private void closeForegroundService() {
        // 自己关闭自己……
        LocalBroadcastManager.getInstance(this).sendBroadcast(closeIntent);
        Intent intent = new Intent(this, DownLoadService.class);
        stopService(intent);
    }

    @Override
    public void setProgress(int progress, int total) {
        mProgress = progress;
        // 发送Action为com.motong.communication.RECEIVER的广播
        intent.putExtra(LoadingLayer.PROGRESS, progress);
        // intent.putExtra(LoadingActivity.TOTAL, total);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
        //更新通知栏
        updateNotification(progress, total);
    }
}
