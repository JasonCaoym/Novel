package com.zydm.ebk.mine.upgrade;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;

import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.AbsDialogViewHolder;
import com.zydm.ebk.R;

/**
 * Created by wangdy on 2017/7/21.
 */

public class LayerUtil {

    public static Dialog showUpdateDialog(Activity activity, String resume) {
        return showLayer(activity, new UpdateNewVersionViewHolder(resume));
    }

    public static Dialog showUpgradeDialog(Activity activity, boolean isUpgrade, UpdateInfoBean upgradeInfoBean, String award) {
        return showLayer(activity, new UpgradeViewHolder(isUpgrade, upgradeInfoBean, award));
    }

    public static Dialog showLoadingLayer(Activity activity, UpdateInfoBean mUpdateInfoBean) {
        LoadingLayer loadingLayer = new LoadingLayer(mUpdateInfoBean);
        return showLayer(activity, loadingLayer);
    }

    public static Dialog showLayer(Activity activity, AbsDialogViewHolder holder) {
        return showLayer(activity, holder, false);
    }

    public static Dialog showLayer(Activity activity, AbsDialogViewHolder holder, boolean isAnim) {
        if (null == activity) {
            return null;
        }
        if (activity.isFinishing()) {
            return null;
        }
        Dialog dialog = new Dialog(activity, R.style.Dialog);
        holder.setContentViewTo(activity, dialog);
        Window window = dialog.getWindow();
        if (isAnim) {
            window.setGravity(Gravity.BOTTOM);
            window.setWindowAnimations(R.style.BottomDialog_Animation);
        }
        window.setAttributes(resetLayoutParams(window.getAttributes()));
        dialog.show();
        return dialog;
    }

    public static WindowManager.LayoutParams resetLayoutParams(WindowManager.LayoutParams lp) {
        lp.width = ViewUtils.getPhonePixels()[0];
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        return lp;
    }
}
