package com.zydm.ebk.ui

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import com.zydm.ebk.provider.ad.ADListener
import com.zydm.ebk.provider.ad.AdParam
import com.zydm.base.common.BaseApplication
import com.zydm.base.ext.setVisible
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.utils.LogUtils
import com.zydm.ebk.R
import com.zydm.ebk.provider.ad.AdMgr
import kotlinx.android.synthetic.main.splash_activity.*

class SplashActivity: BaseActivity() {

    private var mForceGoMain = false
    private var mIsShowAd = false
    private var mIsContinueTime = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash_activity)

        AdMgr.initAdPlatform(this)

        if (AdMgr.isShowAd(AdMgr.AD_SPLASH)) {
            mIsShowAd = true
            ad_bottom_layout.setVisible(true)
            default_start_img.setVisible(false)
            val adHelper = AdMgr.createAdHelper(this)
            adHelper.addListener(object : ADListener {
                override fun onAdDismiss(param: AdParam, reason: String) {
                    super.onAdDismiss(param, reason)
                    gotoHome()
                }

                override fun onAdError(param: AdParam, code: Int, msg: String) {
                    super.onAdError(param, code, msg)
                    gotoHome()
                }
            })

            adHelper.loadSplashAd(AdMgr.getAdParam(AdMgr.AD_SPLASH), splash_container)
        } else {
            mIsShowAd = false
            default_start_img.setVisible(true)
            ad_bottom_layout.setVisible(false)
            BaseApplication.handler.postDelayed(mDelayGoHome, 2000)
        }
    }

    private val mDelayGoHome = object : Runnable{
        override fun run() {
            gotoHome()
        }
    }

    override fun onResume() {
        super.onResume()
        LogUtils.d(TAG, "onResume")
        if (mForceGoMain) {
            gotoHome()
        } else if (mIsContinueTime) {
            BaseApplication.handler.postDelayed(mDelayGoHome, 1000)
        }
    }

    override fun onPause() {
        super.onPause()
        LogUtils.d(TAG, "onPause")
        if (!mIsShowAd) {
            BaseApplication.handler.removeCallbacks(mDelayGoHome)
            mIsContinueTime = true
        }
    }

    private fun gotoHome() {
        if (!isOnForeground) {
            return
        }

        if (!intent.getBooleanExtra(DATA_KEY, false)) {
            val intent = Intent(this@SplashActivity, HomeActivity::class.java)
            startActivity(intent)
        }
        finish()
    }

    override fun onStop() {
        super.onStop()
        mForceGoMain = true
    }
}