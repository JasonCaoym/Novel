package com.zydm.ebk.mine.upgrade;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.CornerDrawable;
import com.zydm.base.widgets.RoundImageView;
import com.zydm.ebk.R;

public class UpdateDialog extends Dialog {

    public static final int status_check = 0;

    public UpdateDialog(Context context) {
        super(context);
        View content = LayoutInflater.from(context).inflate(R.layout.upgrade_dialog_layout, null);
        RoundImageView imageView = content.findViewById(R.id.top_bg);
        int corner = ViewUtils.dp2px(4.0f);
        CornerDrawable drawable = new CornerDrawable();
        drawable.setRadius(corner, corner, corner, corner, corner, corner, corner, corner);
        drawable.setColor(ViewUtils.getColor(R.color.white));
        imageView.setBackground(drawable);

        Window dialogWindow = getWindow();
        dialogWindow.setGravity(Gravity.CENTER);
        WindowManager.LayoutParams attributes = dialogWindow.getAttributes();
        attributes.height = (int) (ViewUtils.getPhonePixels()[0] * 1.25f);
        attributes.width = ViewUtils.getPhonePixels()[0];
        dialogWindow.setAttributes(attributes);
    }

}
