package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.common.BaseApplication;
import com.zydm.base.utils.SPUtils;
import com.zydm.base.utils.StringUtils;

public final class DomainHelper {

    private static final String SEARCH_URL_CONST_FOLDER = "/Api/Search";

    private static final String BASE_DOMAIN_NAME = "ebk.cm233.com";

    private static final String[] DEFAULT = {
            "http://test." + BASE_DOMAIN_NAME,
            "http://" + BASE_DOMAIN_NAME
    };

    private static final String[] SEARCH = {
            "http://search.test." + BASE_DOMAIN_NAME,
            "http://search." + BASE_DOMAIN_NAME
    };

    private static final String[] STATISTICS = {
            "http://statistics.test." + BASE_DOMAIN_NAME,
            "http://statistics." + BASE_DOMAIN_NAME
    };

    private static final String[] H5_PAGE = {
            "http://m.test." + BASE_DOMAIN_NAME,
            "http://m." + BASE_DOMAIN_NAME
    };

    private static final String[][] ALL_DOMAIN = {
            DEFAULT,
            SEARCH,
            STATISTICS,
            H5_PAGE
    };

    private final static String[] KEY_BY_DOMAIN = {
            "domain_name_default",
            "domain_name_search",
            "domain_name_statistics"
    };

    private static String[] sCurDomain = new String[ALL_DOMAIN.length];

    public static String fullUrl(String urlConst) {
        int type = DomainType.DEFAULT;
        return getDomainName(type) + urlConst;
    }

    /**
     * @return
     */
    public static String getDomainName(int type) {
        if (StringUtils.isBlank(sCurDomain[type])) {
            sCurDomain[type] = SPUtils.INSTANCE.getString(KEY_BY_DOMAIN[type]);
            if (StringUtils.isBlank(sCurDomain[type])) {
                int envIndex = BaseApplication.context.isTestEnv() ? 0 : 1;
                sCurDomain[type] = ALL_DOMAIN[type][envIndex];
            }
        }
        return sCurDomain[type];
    }

    /*-------------------------------------------------开发者模式专用-------------------------------------------------*/
    public static String getStaticDomain(int type, boolean isTestEnv) {
        int envIndex = isTestEnv ? 0 : 1;
        return ALL_DOMAIN[type][envIndex];
    }

    public static void setDomains(String api, String search, String statistics) {
        sCurDomain[DomainType.DEFAULT] = api;
        sCurDomain[DomainType.SEARCH] = search;
        sCurDomain[DomainType.STATISTICS] = statistics;

        for (int i = 0; i < KEY_BY_DOMAIN.length; i++) {
            SPUtils.INSTANCE.putString(KEY_BY_DOMAIN[i], sCurDomain[i]);
        }
    }

}
