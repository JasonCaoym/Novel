package com.zydm.ebk.mine.upgrade;

import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.zydm.base.common.Constants;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.AbsDialogViewHolder;
import com.zydm.ebk.R;

public class UpgradeViewHolder extends AbsDialogViewHolder {

    private Activity mActivity;
    private View mRootView;
    private boolean mIsUpgrade = false;
    private TextView mResumeTv;
    private TextView mMBeanTv;
    private TextView mTitleTv;
    private Button mGetBtn;
    private UpdateInfoBean mUpgradeInfoBean;
    private String mAward;

    public UpgradeViewHolder(boolean isUpgrade, UpdateInfoBean upgradeInfoBean, String award) {
        mIsUpgrade = isUpgrade;
        mUpgradeInfoBean = upgradeInfoBean;
        mAward = award;
    }

    @Override
    protected View createContentView(Activity activity) {
        mActivity = activity;
        mRootView = ViewUtils.inflateView(activity, R.layout.activity_urgrade_dialog, null);
        initView(mRootView);
        initData();
        return mRootView;
    }

    private void initView(View rootView) {
        mTitleTv = findView(rootView, R.id.title_tv);
        mResumeTv = findView(rootView, R.id.resume_tv);
        mMBeanTv = findView(rootView, R.id.mbean_tv);
        mGetBtn = findViewSetOnClick(rootView, R.id.get_btn);
        findViewSetOnClick(rootView, R.id.present_fake_empty_one);
        findViewSetOnClick(rootView, R.id.present_fake_empty_two);
        ViewUtils.setViewVisible(mMBeanTv, !mIsUpgrade);
        ViewUtils.setViewVisible(mTitleTv, mIsUpgrade);
    }

    private void initData() {
        String log = null == mUpgradeInfoBean ? Constants.EMPTY : mUpgradeInfoBean.getLog();
        mResumeTv.setGravity(mIsUpgrade ? Gravity.LEFT : Gravity.CENTER_HORIZONTAL);
        mResumeTv.setText(mIsUpgrade ? log : "小墨快递到~收好你的新版礼包");
        if (mIsUpgrade) {
            String versionName = null == mUpgradeInfoBean ? Constants.EMPTY : mUpgradeInfoBean.getVersionName();
            mTitleTv.setText(ViewUtils.getString(R.string.upgrade_title, versionName));
        }
        if (!mIsUpgrade) {
            mMBeanTv.setText(StringUtils.isBlank(mAward) ? Constants.EMPTY : mAward);
        }
        mGetBtn.setText(mIsUpgrade ? "前往升级" : "领取");
    }

    @Override
    public void onClick(View v) {
        if (null == v) {
            return;
        }

        switch (v.getId()) {
            case R.id.get_btn:
                UpgradeManager.getInstance().resetCheckComplete();
                if (!mIsUpgrade) {
                    dismissDialog();
                    return;
                }
                UpgradeManager.getInstance().startDownLoadingActivity(mActivity);
                dismissDialog();
                break;
            case R.id.present_fake_empty_one:
            case R.id.present_fake_empty_two:
                UpgradeManager.getInstance().resetCheckComplete();
                dismissDialog();
                break;
            default:
                break;
        }
    }

}
