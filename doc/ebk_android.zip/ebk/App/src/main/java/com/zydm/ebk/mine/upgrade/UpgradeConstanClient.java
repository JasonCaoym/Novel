package com.zydm.ebk.mine.upgrade;

import android.annotation.SuppressLint;

import com.zydm.base.rx.MtSchedulers;
import com.zydm.base.tools.PhoneStatusManager;
import com.zydm.base.utils.LogUtils;
import com.zydm.base.utils.SPUtils;
import com.zydm.ebk.data.api.Api;

import io.reactivex.functions.Action;

/**
 * @version:
 * @FileDescription:
 * @Author:jing
 * @Since:2016/12/26
 * @ChangeList:
 */

public class UpgradeConstanClient {

    private static final String TAG = "UpgradeConstanClient";


    private static final String APP_IS_GRAY = "app_is_gray_update";
    public static final String UPGRADE_APP_VERSIONCODE = "upgrade_grady_app_version_code";

    public static void setAppGray(boolean isGray) {
        SPUtils.INSTANCE.putBoolean(APP_IS_GRAY, isGray);
    }

    public static void setAppVersionCode(int versionCode) {
        SPUtils.INSTANCE.putInt(UPGRADE_APP_VERSIONCODE, versionCode);
    }

    /**
     * @return 是否是这个版本的灰度
     */
    private static boolean isThisVersionGray() {
        return PhoneStatusManager.getInstance().getAppVersionCode() == SPUtils.INSTANCE.getInt(UPGRADE_APP_VERSIONCODE, 0);
    }

    public static boolean isGray() {
        return SPUtils.INSTANCE.getBoolean(APP_IS_GRAY, false);
    }

    @SuppressLint("CheckResult")
    public static void reportGray() {
        //是否灰度
        if (!isGray()) {
            return;
        }

        //低版本不上报
        if (!isThisVersionGray()) {
            return;
        }

        LogUtils.d(TAG, "reportGray");

        Api.INSTANCE.version().incrGrayCount().subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(new Action() {
            @Override
            public void run() throws Exception {
                //上报一次
                LogUtils.d(TAG, "gray report request succeed");
                setAppGray(false);
            }
        });
    }
}
