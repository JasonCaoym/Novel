package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.data.base.IBeanEmpty;
import com.zydm.ebk.mine.upgrade.FkErrorCode;

public class Response<D> {

    private int mErrorCode = FkErrorCode.OK;
    private String mErrorMsg = "";
    private D mData;
    private Object mTag;

    public Response(D data) {
        this.mData = data;
    }

    public Response(int errorCode, String errorMsg) {
        super();
        this.mErrorCode = errorCode;
        this.mErrorMsg = errorMsg == null ? "" : errorMsg;
    }

    public Response(int errorCode, String errorMsg, D data, Object tag) {
        this(errorCode, errorMsg);
        this.mData = data;
        this.mTag = tag;
    }

    public int getErrorCode() {
        return mErrorCode;
    }

    public String getErrorMsg() {
        return mErrorMsg;
    }

    public D getData() {
        return mData;
    }

    public Object getTag() {
        return mTag;
    }

    public boolean isDataEmpty() {
        if (null == mData || FkErrorCode.OK != mErrorCode) {
            return true;
        }
        if (mData instanceof IBeanEmpty) {
            return ((IBeanEmpty) mData).isEmpty();
        }
        return false;
    }

    public boolean isOk() {
        return FkErrorCode.OK == mErrorCode;
    }

}
