package com.zydm.ebk.mine.upgrade;

import android.app.Activity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.TextView;

import com.motong.framework.download.utils.Utils;
import com.zydm.base.ui.activity.BaseActivity;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.widgets.MTDialog;
import com.zydm.ebk.R;

import org.jetbrains.annotations.Nullable;

public class UpgradeDialogActivity extends BaseActivity {

    private UpdateInfoBean mUpdateInfoBean;
    private boolean mIsAutoCheck;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initData();
        showNormalDialog(this, true);
    }

    private void initData() {
        mUpdateInfoBean = (UpdateInfoBean) getIntent().getSerializableExtra("update_info");
        mIsAutoCheck = getIntent().getBooleanExtra("is_auto", false);
    }

    private void showNormalDialog(Activity activity, boolean isDismissOnTouch) {
/*        UpdateDialog dialog = new UpdateDialog(activity);
        dialog.show();*/


        MTDialog upgradeDialog = new MTDialog(activity);
        upgradeDialog.setTitle(activity.getString(R.string.upgrade_title, mUpdateInfoBean.getVersionName()));
        upgradeDialog.setMessage(mUpdateInfoBean.getLog());
        showDialogWithStatus(activity, isDismissOnTouch, upgradeDialog);
    }

    private void showDialogWithStatus(final Activity activity, boolean isDismissOnTouch, MTDialog upgradeDialog) {
        if (mIsAutoCheck && !Utils.isWifiNet(activity)) {
            upgradeDialog.setPositiveButton(R.string.update_cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    UpgradeManager.getInstance().resetCheckComplete();
                }
            });
            upgradeDialog.setNegativeButton(R.string.update_now, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    UpgradeManager.getInstance().startDownLoadingActivity(activity);
                    UpgradeManager.getInstance().resetCheckComplete();
                }
            });
        } else {
            upgradeDialog.setNegativeButton(R.string.update_cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    UpgradeManager.getInstance().resetCheckComplete();
                }
            });
            upgradeDialog.setPositiveButton(R.string.update_now, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    UpgradeManager.getInstance().startDownLoadingActivity(activity);
                    UpgradeManager.getInstance().resetCheckComplete();
                }
            });
        }
        upgradeDialog.setCanceledOnTouchOutside(isDismissOnTouch);
        upgradeDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                UpgradeManager.getInstance().resetCheckComplete();
                finish();
            }
        });
        upgradeDialog.show();
        TextView message = (TextView) upgradeDialog.findViewById(R.id.dialog_message);
        StringUtils.setAutoSplit(message);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}
