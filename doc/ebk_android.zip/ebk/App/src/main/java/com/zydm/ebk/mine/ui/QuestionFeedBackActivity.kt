package com.zydm.ebk.mine.ui

import android.os.Bundle
import android.view.View
import android.widget.ListView

import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.ui.activity.AbsPageActivity
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.R
import com.zydm.ebk.data.bean.FeedBackMsgBean
import com.zydm.ebk.presenter.FeedbackPresenter

class QuestionFeedBackActivity : AbsPageActivity(), IFeedbackPage {

    protected lateinit var mListView: ListView

    private val mAdapter by lazy {
        AdapterBuilder()
                .putItemClass(FeedBackViewHolder::class.java)
                .builderListAdapter(activity)
    }
    protected lateinit var mPresenter: FeedbackPresenter

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<*> {
        setContentView(R.layout.activity_question_feed_back)
        initView()
        mPresenter = FeedbackPresenter(this)
        return mPresenter
    }

    private fun initView() {
        setToolBarLayout(ViewUtils.getString(R.string.feedback_history))
        findViewById<View>(R.id.toolbar_right_tv).visibility = View.GONE
        mListView = findViewById(R.id.fragment_list_listview)
        mListView.divider = null
    }

    override fun showPage(listBean: FeedBackMsgBean) {
        mListView.adapter = mAdapter
        mAdapter.setData(listBean.list)
    }
}
