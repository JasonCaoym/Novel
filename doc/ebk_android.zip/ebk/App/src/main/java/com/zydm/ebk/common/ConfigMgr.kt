package com.zydm.ebk.common

import android.annotation.SuppressLint
import android.text.TextUtils
import android.util.Log
import com.zydm.base.rx.MtSchedulers
import com.zydm.base.tools.PhoneStatusManager
import com.zydm.ebk.data.api.Api
import com.zydm.ebk.provider.ad.AdMgr

object ConfigMgr {

    @SuppressLint("CheckResult")
    fun loadConfig() {
        Api.version().appCheck().build().subscribeOn(MtSchedulers.io()).subscribe { version, exception ->
            val myVersion = PhoneStatusManager.getInstance().appVersionName;
            if (!TextUtils.isEmpty(version) && myVersion.startsWith(version)) {
                return@subscribe
            }
            AdMgr.initConfig()
        }
    }
}