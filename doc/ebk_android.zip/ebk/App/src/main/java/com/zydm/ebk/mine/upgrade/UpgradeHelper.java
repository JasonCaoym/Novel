package com.zydm.ebk.mine.upgrade;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.FileProvider;
import android.widget.RemoteViews;

import com.motong.framework.download.core.DownloadInfo;
import com.motong.framework.download.manager.DownloadMgr;
import com.motong.framework.download.manager.DownloadRequest;
import com.motong.framework.download.manager.IDownloadObserver;
import com.zydm.base.common.BaseApplication;
import com.zydm.base.common.Constants;
import com.zydm.base.common.NotificationVersionAdapter;
import com.zydm.base.rx.MtSchedulers;
import com.zydm.base.tools.PhoneStatusManager;
import com.zydm.base.utils.LogUtils;
import com.zydm.base.utils.MD5Utils;
import com.zydm.base.utils.StorageUtils;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.utils.ToastUtils;
import com.zydm.ebk.R;
import com.zydm.ebk.data.api.Api;

import java.io.File;
import java.util.List;

import io.reactivex.functions.BiConsumer;
import io.reactivex.functions.Consumer;

import static android.content.Context.NOTIFICATION_SERVICE;

public class UpgradeHelper {

    public static final String TAG = "UpgradeHelper";
    private String mLink;
    private VersionInfoBean mVersionInfoBean;
    private Context mContext;
    private DownloadStateListener mStateListener;
    public int mTotal;
    public static final int SILENT_DOWN_SUCCEED_NOTIFICATION_ID = 1;

    private static volatile UpgradeHelper singleton = null;
    private IDownloadObserver mDownloadObserver;

    private UpgradeHelper(Context context) {
        mContext = context;
    }

    public static UpgradeHelper getInstance(Context context) {
        if (singleton == null) {
            synchronized (UpgradeHelper.class) {
                if (singleton == null) {
                    singleton = new UpgradeHelper(context);
                }
            }
        }
        return singleton;
    }

    void startDownload(VersionInfoBean versionInfo, boolean isSilent) {
        if (null == versionInfo) {
            return;
        }
        mVersionInfoBean = versionInfo;
        mTotal = (int) versionInfo.size;
        UpgradeConstanClient.setAppGray(versionInfo.isGray());
        UpgradeConstanClient.setAppVersionCode(versionInfo.versionCode);
        downloadAPK(versionInfo, isSilent);
    }

    private void downloadAPK(VersionInfoBean versionInfo, boolean isSilent) {
        mLink = versionInfo.link;
        LogUtils.d(TAG, mLink);

        if (tryHandleApkWithVersion(versionInfo, isSilent)) {
            return;
        }
        if (!isSilent) {
            ToastUtils.showLimited(mContext.getString(R.string.start_download));
        }
        DownloadRequest request = new DownloadRequest(mLink,
                Constants.EMPTY, getDownloadPath(mVersionInfoBean));
        request.setAllowByMobileNet(!isSilent);
        DownloadMgr.getInstance().enqueue(request);
        request.setRequestCallback(new DownloadRequest.ResultCallback() {
            @Override
            public void onResult(boolean isExists, DownloadInfo downloadInfo) {
                if (isExists) {
                    DownloadMgr.getInstance().reDownload(downloadInfo.getDownId());
                }
            }
        });
        handleDownloadState(isSilent);
    }

    private void handleDownloadState(final boolean isSilent) {
        if (null != mStateListener) {
            mStateListener.downloadStart();
        }

        if (null == mDownloadObserver) {
            mDownloadObserver = new IDownloadObserver() {
                @Override
                public void onProgressChange(List<DownloadInfo> list) {
                    DownloadInfo targetInfo = getUpgradeDownloadInfo(list, mLink);
                    if (targetInfo != null) {
                        int mProgress = targetInfo.getProgress();
                        int total = targetInfo.getTotal();
                        LogUtils.d(TAG, "progress : " + mProgress);
                        if (mStateListener != null) {
                            mStateListener.setProgress(mProgress, total);
                        }
                    }
                }

                @Override
                public void onStatusChange(List<DownloadInfo> list) {
                    DownloadInfo targetInfo = getUpgradeDownloadInfo(list, mLink);
                    handleDownloadComplete(targetInfo, mVersionInfoBean, isSilent);
                }

                @Override
                public void onDelete(List<DownloadInfo> list) {
                }
            };
        }
        DownloadMgr.getInstance().registerObserver(mDownloadObserver);
    }

    private void handleDownloadComplete(DownloadInfo targetInfo, VersionInfoBean versionInfoBean, boolean isSilent) {
        if (null == targetInfo) {
            return;
        }

        if (targetInfo.getStatus() == DownloadMgr.STATUS_SUCCESSFUL) {
            DownloadMgr.getInstance().deleteTask(targetInfo.getDownId(), false);
            stateListenerSuccessful();
            lastCheckUpdateAndTryInstall(versionInfoBean, isSilent);
        } else if (targetInfo.getStatus() == DownloadMgr.STATUS_FAILED) {
            stateListenerFailed();
        }
    }

    @SuppressLint("CheckResult")
    private void lastCheckUpdateAndTryInstall(final VersionInfoBean versionInfoBean, final boolean isSilent) {
        if (UpgradeManager.isNeedCheckAPI()) {
            UpgradeManager.updateCheckAPI();
            Api.INSTANCE.version().check(BaseApplication.context.getPackageName(), String.valueOf(PhoneStatusManager.getInstance().getAppVersionCode())).setForceUpdate(true).build()
                    .subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi())
                    .subscribe(new Consumer<UpdateInfoBean>() {
                        @Override
                        public void accept(UpdateInfoBean updateInfoBean) throws Exception {
                            if (null != updateInfoBean && updateInfoBean.hasNewVersion(PhoneStatusManager.getInstance().getAppVersionCode())) {
                                clearApk();
                            } else {
                                handleInstallStatus(versionInfoBean, isSilent);
                            }
                        }
                    }, new Consumer<Throwable>() {
                        @Override
                        public void accept(Throwable throwable) throws Exception {

                        }
                    });
        } else {
            handleInstallStatus(versionInfoBean, isSilent);
        }
    }

    private void handleInstallStatus(VersionInfoBean versionInfoBean, boolean isSilent) {
        if (isSilent) {
            showDownSucceedNotif();
        } else {
            startInstallAPK(versionInfoBean, isSilent);
        }
    }

    private void showDownSucceedNotif() {
        NotificationManager mNotificationManager = (NotificationManager) mContext.getSystemService(NOTIFICATION_SERVICE);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext);
        NotificationVersionAdapter.getInstance().adapter(builder);
        builder.setContent(getRemoteView()).setSmallIcon(R.mipmap.ic_launcher)
                .setPriority(Notification.PRIORITY_DEFAULT).setDefaults(Notification.DEFAULT_ALL)
                .setContentIntent(getPendingIntent()).setOngoing(true);

        Notification notification = builder.build();
        notification.flags = Notification.FLAG_AUTO_CANCEL;
        mNotificationManager.notify(SILENT_DOWN_SUCCEED_NOTIFICATION_ID, notification);
    }

    private PendingIntent getPendingIntent() {
        Intent intent = new Intent(UpgradeManager.ACTION_NOTIFICATION_DOWNLOAD_RECEIVER);
        intent.putExtra(UpgradeManager.APK_INSTALL_INFO, mVersionInfoBean);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getBroadcast(mContext, Constants.ONE_NUM,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private RemoteViews getRemoteView() {
        RemoteViews remoteViews = new RemoteViews(mContext.getPackageName(), R.layout.silent_down_succeed_notification);
        return remoteViews;
    }

    private void stateListenerFailed() {
        if (null != mStateListener) {
            mStateListener.downloadFailed();
        }
    }

    private void stateListenerSuccessful() {
        if (null != mStateListener) {
            mStateListener.downloadSuccessful();
        }
    }

    private void stateListenerDirectInstall() {
        if (null != mStateListener) {
            mStateListener.directInstall();
        }
    }

    /**
     * 处理apk文件
     */
    public boolean tryHandleApkWithVersion(VersionInfoBean versionInfoBean, boolean isSilentShowNotifi) {
        if (isDownloaded(versionInfoBean)) {
            startInstallAPK(versionInfoBean, isSilentShowNotifi);
            return true;
        } else {
            return false;
        }
    }

    public boolean isDownloaded(VersionInfoBean versionInfoBean) {
        if (versionInfoBean == null) {
            return false;
        }
        File downloadFile = getDownloadFile(versionInfoBean);
        return downloadFile != null && downloadFile.exists();
    }

    private void startInstallAPK(VersionInfoBean versionInfoBean, boolean isSilent) {
        if (isSilent) {
            showDownSucceedNotif();
            return;
        }
        LogUtils.d(TAG, "CMApp.isOnForeground" + BaseApplication.context.isOnForeground());
        //在APP内部直接安装
        if (!BaseApplication.context.isOnForeground()) {
            //如果没安装下次进入app就提示
            return;
        }
        File downloadFile = getDownloadFile(versionInfoBean);
        if (!downloadFile.exists()) {
            return;
        }
        String fileMd5 = MD5Utils.getFileMd5(downloadFile);
        LogUtils.d(TAG, "file Md 5 : " + (StringUtils.isBlank(fileMd5) ? "fileMd null" : fileMd5));
        stateListenerDirectInstall();
        if (fileMd5.equalsIgnoreCase(versionInfoBean.md5)) {
            installApp(getDownloadPath(versionInfoBean));
        } else {
            downloadFile.delete();
        }
    }

    private void installApp(String filePath) {
        String cmd = "chmod 755 " + filePath;
        try {
            Runtime.getRuntime().exec(cmd);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Intent intent = new Intent(Intent.ACTION_VIEW);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Uri contentUri = FileProvider.getUriForFile(mContext, "com.zydm.ebk.fileprovider", new File(filePath));
            intent.setDataAndType(contentUri, "application/vnd.android.package-archive");
        } else {
            intent.setDataAndType(Uri.fromFile(new File(filePath)), "application/vnd.android.package-archive");
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        mContext.startActivity(intent);
    }

    private DownloadInfo getUpgradeDownloadInfo(List<DownloadInfo> list, String link) {
        for (DownloadInfo info : list) {
            if (link.equals(info.getUrl())) {
                return info;
            }
        }
        return null;
    }

    private File getDownloadFile(VersionInfoBean info) {

        if (null == info) {
            return null;
        }
        String filePath = getDownloadPath(info);
        return new File(filePath);
    }

    private String getDownloadPath(VersionInfoBean info) {
        return BaseApplication.context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + File.separator
                + getFileName(info);
    }

    private String getFileName(VersionInfoBean info) {
        return info.versionCode + Constants.APK;
    }

    public void addDownloadStateListener(DownloadStateListener stateListener) {
        mStateListener = stateListener;
    }

    interface DownloadStateListener {

        void downloadStart();

        void downloadSuccessful();

        void downloadFailed();

        void directInstall();

        void setProgress(int progress, int total);
    }

    public static float getDirectorySize() {
        return StorageUtils.getFileDirectoryTotalMB(BaseApplication.context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS));
    }

    public static void clearApk() {
        StorageUtils.deleteFileDir(BaseApplication.context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), false);
    }
}
