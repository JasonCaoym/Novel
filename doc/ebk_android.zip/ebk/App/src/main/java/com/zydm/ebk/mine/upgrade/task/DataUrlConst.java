package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.data.base.MtMap;
import com.zydm.base.utils.StringUtils;

public final class DataUrlConst {

    public static final String SPLASH_URL = "/Api/Banners/getLaunchingPage";

    //个人中心
    public static final String GET_PROBLEM_LIST_URL = "/Api/Feedback/getType";
    public static final String COMMIT_PROBLEM_URL = "/Api/Feedback/addIssue";
    public static final String EDIT_USER_INFO = "/Api/User/editInfo";

    //其它
    public static final String CHECK_UPDATE_URL = "/Api/Version/check";

    //设备签到
    public static final String DEVICE_SIGN_URL = "/Api/Device/sign";


    private static MtMap<String, Integer> sCacheExpiredTime = new MtMap<String, Integer>();

    /**
     * === 缓存有效期规则 ===
     * 1 所有缓存有效期不超过1天
     * 2 帖子列表缓存有效期不能超过10分钟;
     * 3 作品,用户列表缓存有效期不能超过1小时;
     * 4 仅当前用户操作所刷新的数据,有效期不超过1天;
     * 5 粉丝数有效期不超过5分钟;
     * 6 消息列表有效期不超过10分钟;
     * 7 用户基本信息有效期不超过1天;
     * 8 热门推荐数据有效期不超过1小时;
     **/
    private static final Integer ONE_DAY_IN_SECONDS = new Integer(86400);
    private static final Integer ONE_HOUR_IN_SECONDS = new Integer(3600);

    public static int getCacheExpiredTime(String urlConstant) {

        if (StringUtils.isBlank(urlConstant)) {
            return -1;
        }

        if (sCacheExpiredTime.containsKey(urlConstant)) {
            Integer value = sCacheExpiredTime.get(urlConstant);
            return value.intValue();
        }

        return -1;
    }

}