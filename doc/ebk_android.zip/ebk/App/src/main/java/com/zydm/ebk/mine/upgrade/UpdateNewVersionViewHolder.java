package com.zydm.ebk.mine.upgrade;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import com.zydm.base.utils.StringUtils;
import com.zydm.base.utils.ToastUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.AbsDialogViewHolder;
import com.zydm.ebk.R;

public class UpdateNewVersionViewHolder extends AbsDialogViewHolder {


    private Activity mActivity;
    private String mResume;
    private TextView mResumeTv;

    public UpdateNewVersionViewHolder(String resume) {
        mResume = resume;
    }

    @Override
    protected View createContentView(Activity activity) {
        mActivity = activity;
        View view = ViewUtils.inflateView(activity, R.layout.update_dialog_layout, null);
        initView(view);
        initData();
        return view;
    }

    private void initView(View rootView) {
        findViewSetOnClick(rootView, R.id.img_cancel);
        findViewSetOnClick(rootView, R.id.tv_update);
        mResumeTv = findView(rootView, R.id.tv_resume);
    }

    private void initData() {
        if (StringUtils.isBlank(mResume)) {
            return;
        }
        mResumeTv.setText(mResume);
    }

    @Override
    public void onClick(View v) {
        if (v == null) {
            return;
        }

        int id = v.getId();
        switch (id) {
            case R.id.img_cancel:
                cancelDialog();
                break;
            case R.id.tv_update:
                dismissDialog();
                update();
                break;
        }
    }

    private void update() {
        ToastUtils.showLimited(ViewUtils.getString(R.string.download_new_version));
        UpgradeManager.getInstance().startDownLoadingActivity(mActivity);
        UpgradeManager.getInstance().resetCheckComplete();
    }
}
