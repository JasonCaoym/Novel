package com.zydm.ebk.mine.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import com.zydm.base.common.BaseApplication
import com.zydm.base.data.net.DomainConfig
import com.zydm.base.ext.onClick
import com.zydm.base.ext.setVisible
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.tools.PhoneStatusManager
import com.zydm.base.ui.BaseActivityHelper
import com.zydm.base.ui.activity.web.WebActivity
import com.zydm.base.ui.fragment.BaseFragment
import com.zydm.base.utils.ToastUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.R
import com.zydm.ebk.common.ActivityHelper
import com.zydm.ebk.mine.MineManager
import com.zydm.ebk.mine.upgrade.UpgradeManager
import kotlinx.android.synthetic.main.fragment_mine.*
import kotlinx.android.synthetic.main.mine_item.view.*

class MineFragment : BaseFragment() {

    override fun onCreateView(savedInstanceState: Bundle?) {
        setContentView(R.layout.fragment_mine)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        read_history.onClick(this)
        read_history.module_name.text = ViewUtils.getString(R.string.read_history)
        help.module_name.text = ViewUtils.getString(R.string.help)
        help.onClick(this)
        check_update.module_name.text = ViewUtils.getString(R.string.check_update)
        check_update.number.setVisible(true)
//        check_update.next.setVisible(false)
        check_update.number.text = ViewUtils.getString(R.string.current_version_name, PhoneStatusManager.getInstance().appVersionName)
        check_update.onClick(this)
        about.module_name.text = ViewUtils.getString(R.string.user_agreement)
        about.onClick(this)
        developer.setVisible(BaseApplication.context.isTestEnv())
        developer.module_name.text = ViewUtils.getString(R.string.developer)
        developer.onClick(this)
    }

    override fun onClick(v: View) {
        super.onClick(v)
        when (v.id) {
            R.id.help -> {
                StatisHelper.onEvent().helpClick()
                ActivityHelper.gotoQuestion(activity!!)
            }
            R.id.check_update -> {
                StatisHelper.onEvent().upgradeClick()
                checkUpdate()
            }
            R.id.developer -> {
                val intent = Intent(activity!!, DeveloperActivity::class.java)
                activity!!.startActivity(intent)
            }
            R.id.read_history -> ActivityHelper.gotoHistory(activity!!)
            R.id.about -> BaseActivityHelper.gotoWebActivity(activity!!, WebActivity.Data(DomainConfig.getAboutH5(), ""))
        }
    }

    fun checkUpdate() {
        if (MineManager.isCheckComplete) {
            MineManager.isCheckComplete = false
            ToastUtils.showLimited(R.string.start_check)
            UpgradeManager.getInstance().startManualCheck(activity)
        }
    }
}
