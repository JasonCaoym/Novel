package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.data.tools.JsonUtils;
import com.zydm.ebk.mine.upgrade.FkErrorCode;

import java.util.ArrayList;

public class SingleRequestTask extends BaseApiTask implements ApiTask.IApiResponseParser {

    private Class mJsonDataBeanClazz;

    public SingleRequestTask(Class jsonDataBeanClazz) {
        this.setRspParser(this);
        this.mJsonDataBeanClazz = jsonDataBeanClazz;
    }

    @Override
    public Response onParse(ArrayList<ApiRequest> reqs) {
        ApiRequest singleRequest = reqs.get(0);
        Object dataBean = null;
        int errorCode = singleRequest.getErrorCode();
        if (FkErrorCode.OK == errorCode) {
            if (null == mJsonDataBeanClazz) {
                dataBean = singleRequest.getResponseData();
            } else {
                dataBean = JsonUtils.parseJson(singleRequest.getResponseData(), mJsonDataBeanClazz);
            }
        }
        return new Response<Object>(errorCode, singleRequest.getErrorMsg(), dataBean, mTag);
    }

}
