package com.zydm.ebk.mine.upgrade;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;
import android.widget.ProgressBar;

import com.zydm.base.utils.LogUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.base.widgets.AbsDialogViewHolder;
import com.zydm.ebk.R;


public class LoadingLayer extends AbsDialogViewHolder {

    private ProgressReceiver msgReceiver;
    private UpdateInfoBean mInfoBean;

    public static final String PROGRESS = "progress";
    public static final String TOTAL = "total";
    private ProgressBar mProgressBar;
    private CloseReceiver mCloseReceiver;

    public LoadingLayer(UpdateInfoBean infoBean) {
        mInfoBean = infoBean;
    }

    @Override
    protected View createContentView(Activity activity) {
        View rootView = ViewUtils.inflateView(activity, R.layout.activity_loading);
        mProgressBar = findView(rootView, R.id.progress_bar);
        if (null != mInfoBean) {
            if (null != mInfoBean.info) {
                int total = (int) mInfoBean.info.size;
                mProgressBar.setMax(total);
            }
        }

        // 动态注册广播接收器
        msgReceiver = new ProgressReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UpgradeManager.PROGRESS_BROAD);
        LocalBroadcastManager.getInstance(activity).registerReceiver(msgReceiver, intentFilter);

        mCloseReceiver = new CloseReceiver();
        IntentFilter intentFilterClose = new IntentFilter();
        intentFilterClose.addAction(UpgradeManager.CLOSE_DOWN_SERVICE_BROAD);
        LocalBroadcastManager.getInstance(activity).registerReceiver(mCloseReceiver, intentFilterClose);

        Intent intent = new Intent(activity, DownLoadService.class);

        if (null != mInfoBean) {
            intent.putExtra(UpgradeManager.UPDATE_INFO, mInfoBean);
        }
        activity.startService(intent);
        return rootView;
    }

    public class ProgressReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            int progress = intent.getIntExtra(PROGRESS, 0);
            LogUtils.d(TAG, "progress : " + progress);
            mProgressBar.setProgress(progress);
        }
    }

    public class CloseReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            LogUtils.d(TAG, "CloseReceiver");
            LocalBroadcastManager.getInstance(context).unregisterReceiver(msgReceiver);
            LocalBroadcastManager.getInstance(context).unregisterReceiver(mCloseReceiver);
            dismissDialog();
        }
    }
}
