package com.zydm.ebk.mine.upgrade.task;

public class JsonConst {
    public static final String SIGNATURE_VALUE = "mtwl";
    
    public static final String SIGNATURE = "sign";
    public static final String ERROR_CODE = "errorCode";
    public static final String ERROR_MSG = "errorMsg";
    public static final String DATA = "data";
    public static final String ORIGINAL_IMG = "originalImg";
    public static final String PRAISE_COUNT = "praiseCount";

    public static final String IS_COLLECT = "isCollect";

    public static final String COUNT = "count";

    public static final String USER_LIST = "userList";
    public static final String STAT_LIST = "statList";
    public static final String POST_LIST = "postList";
    
    public static final String POST_ID = "postId";
    public static final String USER_ID = "userId";
    public static final String CREATE_TIME = "createTime";
    public static final String IS_HOT = "isHot";
    public static final String CONTENT = "content";
    public static final String IMG_URL = "imgUrl";
    public static final String IMG_NUM = "imgNum";
    public static final String WORKS_NAME = "worksName";
    public static final String WORKS_ID = "worksId";
    public static final String COMMENT_TOTAL = "commentTotal";
    public static final String PRAISE_TOTAL = "praiseTotal";
    public static final String IS_PRAISED = "isPraised";
    public static final String USER_ICON = "userIcon";
    public static final String USER_NAME = "userName";
    public static final String VIP_LEVEL = "vipLevel";
    public static final String LIST = "list";
    public static final String NEXT_CURSOR = "nextCursor";
    public static final String TYPE = "type";
    public static final String TIME = "time";

    public static final String FOLLOW = "follow";
    public static final String FOLLOWED = "followed";
    public static final String FANS_COUNT = "fansCount";

    public static final String BASIC_INFO = "basicInfo";
    public static final String ADDITIONAL_INFO = "additionalInfo";

    public static final String SEX = "sex";
}
