package com.zydm.ebk.mine.upgrade.task;

import android.annotation.SuppressLint;

import com.zydm.base.utils.LogUtils;
import com.zydm.ebk.mine.upgrade.FkErrorCode;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;

public class ApiTaskExecutor {
    private static final String TAG = "ApiTaskExecutor";
    private static final String API_FAIL = "api_fail";
    private static final int CORE_POOL_SIZE = 4;
    private static final int MAX_POOL_SIZE = 10;
    private static final int KEEP_ALIVE_TIME = 30; // second
    private static final int QUEUE_CAPACITY = 50;

    private static ApiTaskExecutor sSelf = null;
    private ExecutorService mExecutor = null;

    private PriorityBlockingQueue<Runnable> mTaskQueue = new PriorityBlockingQueue<Runnable>();

    private ApiTaskExecutor() {
        mExecutor = new ThreadPoolExecutor(CORE_POOL_SIZE, MAX_POOL_SIZE, KEEP_ALIVE_TIME, TimeUnit.SECONDS,
                mTaskQueue, new PriorityThreadFactory("Api_Task",
                android.os.Process.THREAD_PRIORITY_LESS_FAVORABLE)
                // android.os.Process.THREAD_PRIORITY_BACKGROUND:
                // we change the thread priority to less favorable to
                // let task begin sooner
        );
    }

    protected static ApiTaskExecutor getInstance() {
        if (null == sSelf) {
            sSelf = new ApiTaskExecutor();
        }

        return sSelf;
    }

    protected boolean submitRequest(ApiRequest req) {
        if (mTaskQueue.size() > QUEUE_CAPACITY) {
            LogUtils.e(TAG, "queue full !!!");
            return false;
        }
        try {
            HttpWorker worker = new HttpWorker(req);
            mExecutor.execute(worker);
        } catch (RejectedExecutionException rejectExp) {
            LogUtils.e(TAG, rejectExp.getLocalizedMessage(), rejectExp);
            return false;
        } catch (NullPointerException nullExp) {
            LogUtils.e(TAG, nullExp.getLocalizedMessage(), nullExp);
            return false;
        }

        return true;
    }

    /* Worker thread to load data, from cache or server */
    public static class HttpWorker implements Runnable, Comparable<HttpWorker> {

        private static final String TAG = "ApiTaskExecutor.HttpWorker";
        //        private static final String HTTP = "http";
        private static final String HTTPS = "https";
        private static final String UTF_8 = "UTF-8";
        private static final String NULL = "null";

        private static final int SECOND_10 = 10000;

        private static final String HTTP_HEAD_FIELD_CACHE_CONTROL = "Cache-Control";
        private static final String HTTP_HEAD_FIELD_DATE = "Date";

        private static final String LAST_MODIFY_TIME = "Last-Modified";

        private ApiRequest mRequest = null;
        private long mPriority = 0;
        private int mErrorCode = FkErrorCode.UNKNOWN;
        private String mResponseContent = null;
        private String mResponseData = null;
        private boolean mUpdateCache = false;
        private long mLastAccessTime = 0;//the time in milliseconds since January 1, 1970 GMT
        private long mCacheControl = 0; //cache max validity period in seconds
        private long mLastModifyTime = 0; //last cache modify time in milliseconds since January 1, 1970 UTC

        public HttpWorker(ApiRequest req) {
            mRequest = req;
            mPriority = System.currentTimeMillis();
        }

        @SuppressLint("NewApi")
        @Override
        public int compareTo(HttpWorker another) {
            return Long.compare(another.mPriority, mPriority);
        }

        @Override
        public void run() {
            LogUtils.d(TAG, "run");

            try {
                loadData();
                handleResult();
            } catch (Exception exp) {
                LogUtils.e(TAG, exp.getLocalizedMessage(), exp);
            } finally {
            }
        }

        private void loadData() {
            int requestMode = mRequest.getRequestMode();
            switch (requestMode) {
                case ApiRequest.REQ_MODE_LOCAL_CACHE_FIRST:
                case ApiRequest.REQ_MODE_CONFIRM_WITH_SERVER:/*temporarily*/
                    if (false == loadFromCache()) {
                        loadFromServer();
                    }
                    break;

                case ApiRequest.REQ_MODE_FORCE_UPDATE:
//                    loadFromServer();
                    if (false == loadFromServer()) {
                        loadCacheData();
                    }
                    break;
            }
        }

        private void handleResult() {
            if (isValidApiResponse()) {
                mRequest.setResponseData(mResponseData);
            } else {
                if (FkErrorCode.UNKNOWN == mErrorCode || FkErrorCode.OK == mErrorCode) {
                    mErrorCode = FkErrorCode.NETWORK_INVALID_RESPONSE;
                }
            }

            mRequest.setErrorCode(mErrorCode);

            ApiTask task = mRequest.getTask();
            if (null == task) {
                return;
            }

            task.onResult(mRequest);

            if (true == mUpdateCache &&
                    true == mRequest.isCacheEnabled() &&
                    FkErrorCode.OK == mErrorCode) {
                updateCache();
            }
        }

        private boolean loadFromCache() {
            if (false == mRequest.isCacheEnabled()) {
                return false;
            }

            LogUtils.d(TAG, "loadFromCache, url: " + mRequest.getFullUrl());

            loadCacheData();
            return isValidCache();
        }

        private boolean isValidCache() {
            if (null == mResponseContent) {
                return false;
            }
            boolean cacheValid = true;

            try {
                JSONObject jsonObj = new JSONObject(mResponseContent);
                mLastAccessTime = jsonObj.getLong(HTTP_HEAD_FIELD_DATE);
                mCacheControl = jsonObj.getLong(HTTP_HEAD_FIELD_CACHE_CONTROL);
                mLastModifyTime = jsonObj.getLong(LAST_MODIFY_TIME);
            } catch (JSONException e) {
                LogUtils.e(TAG, "invalid cache data");
                return false;
            }

            long expireTime = mLastModifyTime + mCacheControl * 1000;
            long currentTime = System.currentTimeMillis();
            if (currentTime >= expireTime) {
                cacheValid = false;
            }
            return cacheValid;
        }

        private void loadCacheData() {
            String url = mRequest.getFullUrl();
            HashMap<String, String> params = mRequest.getParams();
            mResponseContent = ApiCacheHelper.getCacheData(url, params);
        }

        private void updateCache() {
            LogUtils.d(TAG, "updateCache()");
            try {
                JSONObject jsonObj = new JSONObject(mResponseContent);

                jsonObj.put(HTTP_HEAD_FIELD_DATE, mLastAccessTime);

                if (mCacheControl > 0 && mLastModifyTime > 0) {
                    jsonObj.put(HTTP_HEAD_FIELD_CACHE_CONTROL, mCacheControl);
                    jsonObj.put(LAST_MODIFY_TIME, mLastModifyTime);
                } else {
                    jsonObj.put(HTTP_HEAD_FIELD_CACHE_CONTROL, mRequest.getCacheExpire());
                    jsonObj.put(LAST_MODIFY_TIME, System.currentTimeMillis());
                }

                String cacheData = jsonObj.toString();
                String url = mRequest.getFullUrl();
                HashMap<String, String> params = mRequest.getParams();
                ApiCacheHelper.storeCacheData(url, params, cacheData);
            } catch (JSONException e) {
            }
        }

        private HttpURLConnection doGetRequest() {
            URL url = createApiUrl();
            if (null == url) {
                return null;
            }
            LogUtils.d(TAG, "GET: " + url.toString());

            HttpURLConnection conn = createConnection(url);
            if (null == conn) {
                return null;
            }
            try {
                conn.setRequestMethod("GET");
                conn.setDoOutput(false);
            } catch (ProtocolException e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
                conn = null;
            }
            return conn;
        }

        private HttpURLConnection doPostRequest() {
            URL url = createApiUrl();
            if (null == url) {
                return null;
            }

            LogUtils.d(TAG, "POST: " + url.toString());
            HttpURLConnection conn = createConnection(url);
            if (null == conn) {
                return null;
            }

            OutputStream outputSteam = null;
            try {
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setUseCaches(false);

                byte[] reqParams = createRequestParams().getBytes(UTF_8);
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestProperty("Content-Length", String.valueOf(reqParams.length));

                outputSteam = conn.getOutputStream();
                outputSteam.write(reqParams);
                outputSteam.flush();
            } catch (SocketTimeoutException e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
                mErrorCode = FkErrorCode.NETWORK_CONNETED_TIMEOUT;
                conn = null;
            } catch (IOException e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
                conn = null;
            } finally {
                try {
                    if (null != outputSteam) {
                        outputSteam.close();
                    }
                } catch (IOException e) {
                }
            }
            return conn;
        }

        private boolean loadFromServer() {
            /*
            PhoneStatusManager phone = PhoneStatusManager.getInstance();
            if (!phone.hasNetworkConnected()) {
                mErrorCode = ErrorCode.NETWORK_DISCONNECTION;
                return false;
            }
            */

            LogUtils.i(TAG, "loadFromServer");
            HttpURLConnection conn = null;
            if (ApiRequest.REQ_METHOD_POST == mRequest.getRequestMethod()) {
                conn = doPostRequest();
            } else {
                conn = doGetRequest();
            }
            if (null == conn) {
                if (FkErrorCode.UNKNOWN == mErrorCode) {
                    mErrorCode = FkErrorCode.NETWORK_ERROR;
                }
                LogUtils.i(TAG, "mErrorCode: " + mErrorCode);
                return false;
            }

            try {
                int response = conn.getResponseCode();
                LogUtils.i(TAG, "http response code: " + response);
                if (response == HttpURLConnection.HTTP_OK) {
                    String outputData = getResponseContent(conn);
                    if (API_FAIL.equals(outputData)) {
                        mErrorCode = FkErrorCode.NETWORK_ERROR;
                        return false;
                    } else {
                        extractHeadFields(conn);
                        mResponseContent = outputData;
                        mUpdateCache = true;
                        mErrorCode = FkErrorCode.OK;
                        mRequest.setDataSource(false);
                        return true;
                    }
                } else if (response == HttpURLConnection.HTTP_NOT_MODIFIED) {
                    /*Use cache data has been loaded in loadFromCache called by run()*/
                    return true;
                }
            } catch (SocketTimeoutException e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
                mErrorCode = FkErrorCode.NETWORK_CONNETED_TIMEOUT;
            } catch (IOException e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
                mErrorCode = FkErrorCode.NETWORK_ERROR;
            } finally {
                if (conn != null) {
                    conn.disconnect();
                    conn = null;
                }
                LogUtils.i(TAG, "finally mErrorCode: " + mErrorCode);
            }
            return false;
        }

        private void extractHeadFields(URLConnection conn) {
            mCacheControl = 0;
            mLastAccessTime = conn.getDate();
            mLastModifyTime = conn.getLastModified();
            String field = conn.getHeaderField(HTTP_HEAD_FIELD_CACHE_CONTROL);
            if (null != field && field.startsWith("max-age=")) {
                String cacheControl = field.substring(8, field.length());
                try {
                    mCacheControl = Long.parseLong(cacheControl);
                } catch (NumberFormatException e) {
                }
            }
        }

        private String getResponseContent(URLConnection conn) {
            InputStream is = null;
            InputStream finalInputStream = null;
            BufferedReader bufferReader = null;
            try {
                is = conn.getInputStream();
                StringBuilder sb = new StringBuilder();
                if ("gzip".equals(conn.getContentEncoding())) {
                    finalInputStream = new GZIPInputStream(is);
                } else {
                    finalInputStream = is;
                }
                bufferReader = new BufferedReader(new InputStreamReader(finalInputStream));

                String line = "";
                while (null != (line = bufferReader.readLine())) {
                    sb.append(line);
                }

                return sb.toString();
            } catch (IOException e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
            } catch (Exception e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
            } finally {
                try {
                    if (null != bufferReader) {
                        bufferReader.close();
                    } else if (null != finalInputStream) {
                        finalInputStream.close();
                    } else if (null != is) {
                        is.close();
                    }
                } catch (IOException e) {
                }
            }

            return API_FAIL;
        }

        private HttpURLConnection createConnection(URL url) {
            HttpURLConnection conn = null;
            try {
                if (url.getProtocol().equalsIgnoreCase(HTTPS)) {
                    SSLContext sc = SSLContext.getInstance("TLS");
                    sc.init(null, new TrustManager[]{new MyTrustManager()}, new SecureRandom());
                    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
                    HttpsURLConnection.setDefaultHostnameVerifier(new MyHostnameVerifier());
                    conn = (HttpsURLConnection) url.openConnection();
                } else {
                    conn = (HttpURLConnection) url.openConnection();
                }

                conn.setConnectTimeout(SECOND_10);
                conn.setReadTimeout(SECOND_10);
                conn.setDoInput(true);
                conn.setIfModifiedSince(mLastAccessTime);
                conn.setRequestProperty("Accept-Encoding", "gzip");
            } catch (Exception e) {
                LogUtils.e(TAG, e.getLocalizedMessage(), e);
            }
            return conn;
        }

        private URL createApiUrl() {
            String fullUrl = mRequest.getFullUrl();

            if (ApiRequest.REQ_METHOD_GET == mRequest.getRequestMethod()) {
                String params = createRequestParams();
                fullUrl = fullUrl + "?" + params;
            }
            try {
                return new URL(fullUrl);
            } catch (MalformedURLException exp) {
                LogUtils.e(TAG, exp.getLocalizedMessage(), exp);
            }

            return null;
        }

        @SuppressWarnings("unchecked")
        private String createRequestParams() {
            Map<String, String> params = (Map<String, String>) mRequest.getParams().clone();
            LogUtils.d(TAG, "params: " + params);
            ApiParamConst.addCommonParam(params);

            StringBuffer stringBuffer = new StringBuffer();
            try {
                for (Map.Entry<String, String> entry : params.entrySet()) {
                    stringBuffer.append(entry.getKey())
                            .append("=")
                            .append(getUTF8Code(entry.getValue()))
                            .append("&");
                }
                stringBuffer.deleteCharAt(stringBuffer.length() - 1);
            } catch (Exception e) {
            }
            LogUtils.d(TAG, "all params: " + stringBuffer.toString());
            return stringBuffer.toString();
        }

        private String getUTF8Code(String value) {
            try {
                return URLEncoder.encode(value, UTF_8);
            } catch (UnsupportedEncodingException e) {
                return NULL;
            }
        }

        private boolean isValidApiResponse() {
            if (null == mResponseContent) {
                return false;
            }
            boolean isLoadFromCache = mRequest.isLoadFromCache();
            try {
                JSONObject jsonObj = new JSONObject(mResponseContent);
                LogUtils.d(TAG, "url=" + mRequest.getUrlConstant() + "  isLoadFromCache = " + isLoadFromCache + "    response:" + jsonObj.toString(2));
                String sign = jsonObj.getString(JsonConst.SIGNATURE);
                mErrorCode = jsonObj.getInt(JsonConst.ERROR_CODE);
                if (FkErrorCode.OK == mErrorCode && JsonConst.SIGNATURE_VALUE.equals(sign)) {
                    mResponseData = jsonObj.optString(JsonConst.DATA);
                    return true;
                }

                String errorMsg = "";
                if(!jsonObj.isNull(JsonConst.ERROR_MSG)) {
                    errorMsg = jsonObj.optString(JsonConst.ERROR_MSG);
                }
                mRequest.setErrorMsg(errorMsg);
            } catch (JSONException e) {
                LogUtils.w(TAG, "url=" + mRequest.getUrlConstant() + "  invalid response: \n" + mResponseContent + "\n" + e.getMessage());
//                LogUtils.e(TAG, e.getLocalizedMessage(), e);
            }

            return false;
        }

    }
}
