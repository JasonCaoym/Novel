package com.zydm.ebk.mine.upgrade.task;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;

import com.zydm.base.utils.LogUtils;
import com.zydm.ebk.mine.upgrade.FkErrorCode;

import java.util.ArrayList;

public class ApiTask {
    protected final String TAG = this.getClass().getSimpleName();
    private static final int MSG_CALL_LISTENER = 100;

    private final ArrayList<ApiRequest> mApiReqs = new ArrayList<ApiRequest>();
    private Handler mUiHandler = null;
    private IApiResponseParser mRspParser = null;
    @SuppressWarnings("rawtypes")
    private IApiResponseListener mListener = null;
    private int mResponseCount = 0;
    private boolean mCallByUi = false;

    /* Public member begin */

    /* T is class of result object after parse data */
    public interface IApiResponseParser {
        @SuppressWarnings("rawtypes")
        Response onParse(ArrayList<ApiRequest> reqs);
    }

    /* This T must be same as T in IApiResponseParser */
    public interface IApiResponseListener<D> {
        /**
         * @param result
         * @return true表示自己处理，false表示交给框架处理
         */
        boolean onResult(Response<D> result);
    }

    /* You can put multi request in a task */
    public void pushRequest(ApiRequest req) {
        if (null != req) {
            req.setTask(this);
            mApiReqs.add(req);
        }
    }

    public void setRspParser(IApiResponseParser parser) {
        mRspParser = parser;
    }

    @SuppressWarnings("rawtypes")
    public void setRspListener(IApiResponseListener listener) {
        mListener = listener;
    }

    @SuppressWarnings("rawtypes")
    public IApiResponseListener getResponseListener() {
        return mListener;
    }

    public void stop() {
        mListener = null;
        mRspParser = null;
    }

    public void start() {
        LogUtils.d(TAG, "start()");
        if (Looper.myLooper() == Looper.getMainLooper()) {
            mCallByUi = true;
            prepareHandlerForUI();
        } else {
            mCallByUi = false;
        }

        startAllRequests();
    }

    /* Public member end */

    @SuppressWarnings({"rawtypes"})
    protected void onResult(ApiRequest req) {
        synchronized (this) {
            mResponseCount++;
            if (mResponseCount != mApiReqs.size()) {
                return;
            }

            mResponseCount = 0;

            if (null == mRspParser) {
                return;
            }

            Response rsp = mRspParser.onParse(mApiReqs);
            onResponse(rsp);
        }
    }

    private void onResponse(Response rsp) {
        if (mCallByUi) {
            Message msg = mUiHandler.obtainMessage(MSG_CALL_LISTENER, rsp);
            mUiHandler.sendMessage(msg);
            return;
        }
        handlerResponse(rsp);
    }

    private void prepareHandlerForUI() {
        if (null == mUiHandler) {
            HandlerCallback callBack = new HandlerCallback();
            mUiHandler = new Handler(callBack);
        }
    }

    @SuppressWarnings("rawtypes")
    private void startAllRequests() {
        int errorCode = FkErrorCode.OK;
        for (ApiRequest req : mApiReqs) {
            ApiTaskExecutor executor = ApiTaskExecutor.getInstance();
            if (false == executor.submitRequest(req)) {
                errorCode = FkErrorCode.TASK_BUSY;
                break;
            }
        }
        if (errorCode != FkErrorCode.OK) {
            for (ApiRequest request : mApiReqs) {
                request.setErrorCode(errorCode);
            }
            Response rsp = mRspParser.onParse(mApiReqs);
            onResponse(rsp);
        }
    }

    private class HandlerCallback implements Callback {
        @SuppressWarnings("rawtypes")
        public boolean handleMessage(Message msg) {
            if (MSG_CALL_LISTENER != msg.what) {
                return false;
            }

            Response response = (Response) msg.obj;
            handlerResponse(response);
            return true;
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    protected void handlerResponse(Response response) {
        boolean isHandleErrorCode = true;
        if (null != mListener) {
            isHandleErrorCode = mListener.onResult(response);
        }
        if (!isHandleErrorCode && null != response) {
            onErrorCodeDefaultHandle(response.getErrorCode(),
                    response.getErrorMsg());
        }
    }

    protected void onErrorCodeDefaultHandle(int errorCode, String errorMsg) {
    }

    public ArrayList<ApiRequest> getAllRequest() {
        return mApiReqs;
    }

    public void clearRequest() {
        mApiReqs.clear();
        mResponseCount = 0;
    }
}
