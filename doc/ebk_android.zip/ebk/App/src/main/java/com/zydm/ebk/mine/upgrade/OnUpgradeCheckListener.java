package com.zydm.ebk.mine.upgrade;

interface OnUpgradeCheckListener {

    boolean onCheckFinish(int code, UpdateInfoBean data);
}
