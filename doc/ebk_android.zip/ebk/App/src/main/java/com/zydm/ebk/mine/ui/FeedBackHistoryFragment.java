package com.zydm.ebk.mine.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.widget.ListView;

import com.zydm.base.presenter.AbsPagePresenter;
import com.zydm.base.ui.fragment.AbsPageFragment;
import com.zydm.base.ui.item.AdapterBuilder;
import com.zydm.base.ui.item.ListAdapter;
import com.zydm.base.utils.ViewUtils;
import com.zydm.ebk.R;
import com.zydm.ebk.data.bean.FeedBackMsgBean;
import com.zydm.ebk.presenter.FeedbackPresenter;


public class FeedBackHistoryFragment extends AbsPageFragment implements IFeedbackPage {

    protected ListView mListView;
    private ListAdapter mMtAdapter;
    protected FeedbackPresenter mPresenter;

    @NonNull
    @Override
    protected AbsPagePresenter onCreatePage(Bundle savedInstanceState) {
        setContentView(R.layout.fragment_feedback);
        initView();
        mPresenter = new FeedbackPresenter(this);
        return mPresenter;
    }

    @Override
    public void showPage(FeedBackMsgBean data) {
        mMtAdapter.setData(data.getList());
    }

    private void initView() {
        mListView = findView(R.id.fragment_list_listview);
        mListView.setDivider(null);
        mMtAdapter = new AdapterBuilder().putItemClass(FeedBackViewHolder.class).builderListAdapter(getActivity());
        mListView.setAdapter(mMtAdapter);
    }

    @Override
    protected void onVisibleToUserChanged(boolean isVisibleToUser) {
        super.onVisibleToUserChanged(isVisibleToUser);

        if (!isVisibleToUser) {
            mMtAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public String getPageName() {
        return ViewUtils.getString(R.string.feedback_history);
    }
}
