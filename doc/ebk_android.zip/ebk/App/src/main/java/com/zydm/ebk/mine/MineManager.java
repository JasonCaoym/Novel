package com.zydm.ebk.mine;

public class MineManager {

    public static final String MY_MSG_NUM = "my_msg_num";
    private static final String TAG = "MineManager";

    public static int FEEDBACK_NEW_NUM = 0;//问题反馈

    public static boolean isCheckComplete = true;
}
