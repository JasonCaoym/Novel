package com.zydm.ebk.mine.upgrade;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.widget.TextView;

import com.motong.framework.download.utils.Utils;
import com.zydm.base.common.BaseApplication;
import com.zydm.base.common.Constants;
import com.zydm.base.statistics.umeng.StatisHelper;
import com.zydm.base.tools.PhoneStatusManager;
import com.zydm.base.utils.LogUtils;
import com.zydm.base.utils.SPUtils;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.utils.TimeUtils;
import com.zydm.base.utils.ToastUtils;
import com.zydm.base.widgets.MTDialog;
import com.zydm.ebk.R;
import com.zydm.ebk.mine.MineManager;
import com.zydm.ebk.mine.upgrade.task.ApiParamConst;
import com.zydm.ebk.mine.upgrade.task.ApiRequest;
import com.zydm.ebk.mine.upgrade.task.ApiTask;
import com.zydm.ebk.mine.upgrade.task.DataUrlConst;
import com.zydm.ebk.mine.upgrade.task.Response;
import com.zydm.ebk.mine.upgrade.task.SingleRequestTask;

import static com.zydm.ebk.mine.upgrade.UpdateInfoBean.FORCE_UPDATE;

public class UpgradeManager {

    private static final String TAG = "UpgradeManager";

    public static final String TYPE_APPLICATION = "application/vnd.android.package-archive";

    //更新对话框键
    public static final String LAST_CLEAR_UPGRADE_DIALOG_TIME = "last_clear_upgrade_dialog_time";

    //静默下载键
    public static final String LAST_CHECK_SILENT = "last_check_silent";

    public static final String UPDATE_INFO = "update_info";


    public static final String PROGRESS_BROAD = "com.motong.upgrade.PROGRESS_RECEIVER";
    public static final String CLOSE_DOWN_SERVICE_BROAD = "com.motong.upgrade.CLOSE_RECEIVER";

    public static final String ACTION_NOTIFICATION_DOWNLOAD_RECEIVER = "com.motong.com.DOWNLOAD_PENDING";
    public static final String APK_INSTALL_INFO = "upgrade_apk_info";
    private static final String LAST_SHOW_INSTALL_NOTIFI = "last_show_install_notifi";
    private static final String LAST_CHECK_API_TIME = "last_check_api_time";
    private static final String FORCE_UPDATE_VERSION_CODE = "UpgradeManager.force_update_version_code";

    private UpdateInfoBean mUpdateInfoBean;
    private boolean mIsAutoCheck;
    private long sLastVisitTime;

    private static volatile UpgradeManager singleton = null;

    private UpgradeManager() {
    }

    public static UpgradeManager getInstance() {
        if (singleton == null) {
            synchronized (UpgradeManager.class) {
                if (singleton == null) {
                    singleton = new UpgradeManager();
                }
            }
        }
        return singleton;
    }

    public void startBackgroundCheck(final Activity activity) {
        LogUtils.d(TAG, "startBackgroundCheck 1");
        if (!isNeedBackgroundCheck()) {
            return;
        }

        LogUtils.d(TAG, "startBackgroundCheck 2");
        startCheck(new OnUpgradeCheckListener() {
            @Override
            public boolean onCheckFinish(int code, UpdateInfoBean data) {
                if (code == 0 && data != null && data.hasNewVersion(PhoneStatusManager.getInstance().getAppVersionCode())) {
                    mIsAutoCheck = true;
                    checkShowDialog(data, activity);
                }
                return true;
            }
        });
    }

    public void startManualCheck(final Activity activity) {

        startCheck(new OnUpgradeCheckListener() {
            @Override
            public boolean onCheckFinish(int code, UpdateInfoBean data) {

                if (code != 0 || data == null) {
                    UpgradeManager.this.resetCheckComplete();
                    return true;
                }
                mIsAutoCheck = false;
                if (data.hasNewVersion(PhoneStatusManager.getInstance().getAppVersionCode())) {
                    UpgradeManager.this.showUpgradeDialog(activity, true);
                } else {
                    UpgradeManager.this.resetCheckComplete();
                    ToastUtils.showLimited(R.string.mine_was_last_update);
                }
                return true;
            }
        });
    }

    public void startSilentCheck(final Context context) {
        if (!isNeedSilentCheck()) {
            return;
        }

        LogUtils.d(TAG, "startSilentCheck");
        startCheck(new OnUpgradeCheckListener() {
            @Override
            public boolean onCheckFinish(int code, UpdateInfoBean data) {
                if (code == 0 && data != null && data.hasNewVersion(PhoneStatusManager.getInstance().getAppVersionCode())) {
                    LogUtils.d(TAG, "startCheck-wifi");
                    checkIsSilentDownload(data, context);
                }
                return true;
            }
        });
    }

    private void checkIsSilentDownload(UpdateInfoBean data, Context context) {
        updateSilentCheckTime();
        if (data.isForceUpdate()) {
            UpgradeHelper.getInstance(context).startDownload(data.info, true);
            return;
        }
        UpgradeHelper.getInstance(context).startDownload(data.info, true);
    }

    private void startCheck(OnUpgradeCheckListener listener) {

        if (isTimeTooShort()) {
            resetCheckComplete();
            return;
        }

        startCheckVersion(listener);
    }

    private boolean isTimeTooShort() {

        long currentTime = System.currentTimeMillis();
        long interval = Math.abs(currentTime - sLastVisitTime);
        boolean tooShort = interval < Constants.SECOND_2;
        if (!tooShort) {
            sLastVisitTime = currentTime;
        }
        return tooShort;
    }

    private void startCheckVersion(final OnUpgradeCheckListener listener) {
        updateCheckAPI();

        SingleRequestTask task = new SingleRequestTask(UpdateInfoBean.class);
        ApiRequest request = new ApiRequest(DataUrlConst.CHECK_UPDATE_URL);
        request.addParam(ApiParamConst.PACKAGE, BaseApplication.context.getPackageName());
        request.addParam(ApiParamConst.VERSION_CODE, String.valueOf(PhoneStatusManager.getInstance().getAppVersionCode()));
        task.pushRequest(request);
        task.setRspListener(new ApiTask.IApiResponseListener<UpdateInfoBean>() {

            @Override
            public boolean onResult(Response<UpdateInfoBean> result) {

                return onVersionCheckFinish(result, listener);
            }
        });
        task.start();
    }

    private boolean onVersionCheckFinish(Response<UpdateInfoBean> resultData,
                                         OnUpgradeCheckListener listener) {

        UpdateInfoBean updateInfoBean = resultData.getData();
        int errorCode = resultData.getErrorCode();
        if (errorCode == FkErrorCode.OK && updateInfoBean != null) {
            mUpdateInfoBean = updateInfoBean;
            if (mUpdateInfoBean.isForceUpdate() && mUpdateInfoBean.info != null) {
                SPUtils.INSTANCE.putInt(FORCE_UPDATE_VERSION_CODE, mUpdateInfoBean.info.versionCode);
            } else {
                SPUtils.INSTANCE.remove(FORCE_UPDATE_VERSION_CODE);
            }
        }

        if (listener != null) {
            return listener.onCheckFinish(errorCode, updateInfoBean);
        }
        return true;
    }

    private void checkShowDialog(UpdateInfoBean data, Activity activity) {
        updateUpgradeDialogTime();
        if (!data.hasNewVersion(PhoneStatusManager.getInstance().getAppVersionCode())) {
            return;
        }

        if (data.isForceUpdate()) {
            showForceUpgradeDialog(activity);
            return;
        }

        if (isShowInstallNotifi()) {
            if (UpgradeHelper.getInstance(activity).tryHandleApkWithVersion(data.info, true)) {
                updateShowInstallNofiti();
                return;
            }
        }

        showUpgradeDialog(activity, true);
    }

    private boolean isNeedBackgroundCheck() {
        int forceVersionCode = SPUtils.INSTANCE.getInt(FORCE_UPDATE_VERSION_CODE, -1);
        return isShowDialogExpired() || forceVersionCode > PhoneStatusManager.getInstance().getAppVersionCode();
    }

    private boolean isShowInstallNotifi() {

        long lastShowTime = SPUtils.INSTANCE.getLong(LAST_SHOW_INSTALL_NOTIFI, Constants.ZERO_NUM);
        return TimeUtils.isPastDay(lastShowTime);
    }

    private boolean isShowDialogExpired() {

        long lastShowTime = getUpgradeDialogTime();
        return TimeUtils.isPastDay(lastShowTime);
    }


    private boolean isNeedSilentCheck() {
        long lastShowTime = SPUtils.INSTANCE.getLong(LAST_CHECK_SILENT, Constants.ZERO_NUM);
        LogUtils.d(TAG, "lastshowtime" + lastShowTime);
        return TimeUtils.isPastDay(lastShowTime);
    }

    private static long getUpgradeDialogTime() {
        return SPUtils.INSTANCE.getLong(LAST_CLEAR_UPGRADE_DIALOG_TIME, Constants.ZERO_NUM);
    }

    private static void updateUpgradeDialogTime() {

        SPUtils.INSTANCE.putLong(LAST_CLEAR_UPGRADE_DIALOG_TIME, System.currentTimeMillis());
    }

    public static void clearUpgradeDialogTime() {

        SPUtils.INSTANCE.putLong(LAST_CLEAR_UPGRADE_DIALOG_TIME, Constants.ZERO_NUM);
    }

    private static void updateSilentCheckTime() {

        SPUtils.INSTANCE.putLong(LAST_CHECK_SILENT, System.currentTimeMillis());
    }

    private static void updateShowInstallNofiti() {

        SPUtils.INSTANCE.putLong(LAST_SHOW_INSTALL_NOTIFI, System.currentTimeMillis());
    }

    public static void updateCheckAPI() {
        SPUtils.INSTANCE.putLong(LAST_CHECK_API_TIME, System.currentTimeMillis());
    }

    public static boolean isNeedCheckAPI() {
        long l = SPUtils.INSTANCE.getLong(LAST_CHECK_API_TIME, Constants.ZERO_NUM);
        return System.currentTimeMillis() - l > Constants.HOUR_1;
    }

    private void showForceUpgradeDialog(final Activity activity) {
        if (!BaseApplication.context.isOnForeground()) {
            return;
        }
        StatisHelper.onEvent().strongUpgrade();
        final MTDialog forceDialog = new MTDialog(activity);
        forceDialog.setTitle(activity.getString(R.string.upgrade_title, mUpdateInfoBean.getVersionName()));
        String forceLog = activity.getString(R.string.force_upgrade_msg) + "\r\n" +
                mUpdateInfoBean.getLog();
        forceDialog.setMessage(forceLog);
        forceDialog.setPositiveButton(R.string.update_now, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                StatisHelper.onEvent().strongNowUpgrade();
                UpgradeManager.this.startDownLoadingActivity(activity);
            }
        });
        forceDialog.setAutoDismiss(false);
        forceDialog.setCanceledOnTouchOutside(false);
        forceDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                activity.finish();
            }
        });
        forceDialog.show();
        TextView message = (TextView) forceDialog.findViewById(R.id.dialog_message);
        StringUtils.setAutoSplit(message);
    }

    private void showUpgradeDialog(final Activity activity, final boolean isDismissOnTouch) {
        if (!BaseApplication.context.isOnForeground()) {
            return;
        }
        StatisHelper.onEvent().upgradeTips();
        showNormalDialog(activity, isDismissOnTouch);
    }

    private void showNormalDialog(Activity activity, boolean isDismissOnTouch) {
        MTDialog upgradeDialog = new MTDialog(activity);
        upgradeDialog.setTitle(activity.getString(R.string.upgrade_title, mUpdateInfoBean.getVersionName()));
        upgradeDialog.setMessage(mUpdateInfoBean.getLog());
        showDialogWithStatus(activity, isDismissOnTouch, upgradeDialog);
    }

    private void showDialogWithStatus(final Activity activity, boolean isDismissOnTouch, MTDialog upgradeDialog) {
        if (mIsAutoCheck && !Utils.isWifiNet(activity)) {
            upgradeDialog.setPositiveButton(R.string.update_cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    StatisHelper.onEvent().laterUpgrade();
                    UpgradeManager.this.resetCheckComplete();
                }
            });
            upgradeDialog.setNegativeButton(R.string.update_now, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    StatisHelper.onEvent().nowUpgrade();
                    UpgradeManager.this.startDownLoadingActivity(activity);
                    UpgradeManager.this.resetCheckComplete();
                }
            });
        } else {
            upgradeDialog.setNegativeButton(R.string.update_cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    StatisHelper.onEvent().laterUpgrade();
                    UpgradeManager.this.resetCheckComplete();
                }
            });
            upgradeDialog.setPositiveButton(R.string.update_now, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    StatisHelper.onEvent().nowUpgrade();
                    UpgradeManager.this.startDownLoadingActivity(activity);
                    UpgradeManager.this.resetCheckComplete();
                }
            });
        }
        upgradeDialog.setCanceledOnTouchOutside(isDismissOnTouch);
        //当dialog消失的时候，检查更新的整个事务结束,个人中心的检查更新可以再次点击
        upgradeDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                UpgradeManager.this.resetCheckComplete();
            }
        });
        upgradeDialog.show();
        //文字居左
        TextView message = (TextView) upgradeDialog.findViewById(R.id.dialog_message);
        StringUtils.setAutoSplit(message);
    }

    public void startDownLoadingActivity(final Activity activity) {
        if (Utils.isMobileNet(activity) && !UpgradeHelper.getInstance(activity).isDownloaded(mUpdateInfoBean.info)) {
            MTDialog dialog = new MTDialog(activity);
            dialog.setMessage(R.string.offline_network_note);
            dialog.setPositiveButton(R.string.not_user_mobile_network);
            dialog.setNegativeButton(R.string.continue_user, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    startDownLoading(activity);
                    dialog.dismiss();
                }
            });
            dialog.show();
        } else {
            startDownLoading(activity);
        }
    }

    private void startDownLoading(Activity activity) {
        Intent intent = new Intent(activity, LoadingActivity.class);
        intent.putExtra(UPDATE_INFO, mUpdateInfoBean);
        activity.startActivity(intent);
        activity.overridePendingTransition(R.anim.alpha_in, R.anim.alpha_out);
    }

    public void resetCheckComplete() {
        MineManager.isCheckComplete = true;
    }
}
