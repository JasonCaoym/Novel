package com.zydm.ebk.mine.ui;

import com.zydm.base.presenter.view.IPageView;
import com.zydm.ebk.data.bean.FeedBackMsgBean;
import com.zydm.ebk.data.bean.ProblemListBean;

public interface IFeedbackPage extends IPageView {

    void showPage(FeedBackMsgBean listBean);
}
