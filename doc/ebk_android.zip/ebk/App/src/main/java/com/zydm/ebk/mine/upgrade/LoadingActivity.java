package com.zydm.ebk.mine.upgrade;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.zydm.base.ui.activity.BaseActivity;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.widgets.MTDialog;
import com.zydm.ebk.R;

public class LoadingActivity extends BaseActivity {

    private Intent mIntent;
    private ProgressReceiver msgReceiver;
    private UpdateInfoBean mInfoBean;

    public static final String PROGRESS = "progress";
    public static final String TOTAL = "total";
    private CloseReceiver mCloseReceiver;
    private MTDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setFinishOnTouchOutside(false);

        Intent intent = getIntent();
        mInfoBean = (UpdateInfoBean) intent.getSerializableExtra(UpgradeManager.UPDATE_INFO);

        dialog = new MTDialog(this);
        dialog.setCancelable(false);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setTitle(getString(R.string.upgrade_title, mInfoBean.getVersionName()));
        dialog.setMessage(mInfoBean.getLog());
        dialog.show();
        int total = (int) mInfoBean.info.size;
        dialog.setMax(total);
        TextView message = (TextView) dialog.findViewById(R.id.dialog_message);
        StringUtils.setAutoSplit(message);
        msgReceiver = new ProgressReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UpgradeManager.PROGRESS_BROAD);
        LocalBroadcastManager.getInstance(this).registerReceiver(msgReceiver, intentFilter);

        mCloseReceiver = new CloseReceiver();
        IntentFilter intentFilterClose = new IntentFilter();
        intentFilterClose.addAction(UpgradeManager.CLOSE_DOWN_SERVICE_BROAD);
        LocalBroadcastManager.getInstance(this).registerReceiver(mCloseReceiver, intentFilterClose);

        mIntent = new Intent(this, DownLoadService.class);

        if (null != mInfoBean) {
            mIntent.putExtra(UpgradeManager.UPDATE_INFO, mInfoBean);
        }
        startService(mIntent);
    }

    @Override
    public void onBackPressed() {
        if (mInfoBean.isForceUpdate()) {
            return;
        }
        Intent intent = getIntent();
        setResult(RESULT_OK, intent);
        finish();
        overridePendingTransition(R.anim.alpha_in, R.anim.alpha_out);
    }

    @Override
    protected void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(msgReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(mCloseReceiver);
        super.onDestroy();
    }

    public class ProgressReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            int progress = intent.getIntExtra(PROGRESS, 0);
            dialog.setProgress(progress);
        }
    }

    public class CloseReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            dialog.dismiss();
            LoadingActivity.this.finish();
        }
    }
}
