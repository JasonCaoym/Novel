package com.zydm.ebk.mine.ui;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.zydm.base.common.Constants;
import com.zydm.base.tools.TooFastChecker;
import com.zydm.base.widgets.MTDialog;
import com.zydm.base.ui.fragment.BaseFragment;
import com.zydm.base.utils.KeyboardUtils;
import com.zydm.base.utils.StringUtils;
import com.zydm.base.utils.ViewUtils;
import com.zydm.ebk.R;
import com.zydm.ebk.data.bean.ProblemDetailBean;
import com.zydm.ebk.data.bean.ProblemListBean;
import com.zydm.ebk.presenter.QuestionPresenter;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public class QuestionFragment extends BaseFragment implements IQuestionPage {

    private static final String PROBLEM_NAME = "problem_type";

    private static final String PROBLEM_ID = "problem_id";

    private TextView mProblemsText;

    private EditText mContactEdit;

    private EditText mWriteProblemEdit;

    private View mQuestionCommit;

    private ListView mProblemListView;

    private View mProblemListLayout;

    private String mTypeId;

    private String mTypeName;

    private View mRedPoint;

    private TextView mQuestionFeedback;

    private boolean isChoiceType = false;

    private boolean isLeaveQQ = false;

    private List<ProblemDetailBean> mProblemDetailBeanList;

    List<String> problemItemList;

    private boolean oneRequestFeedbackEnd = true;

    private QuestionActivity mQuestionActivity;

    private AdapterView.OnItemClickListener mOnItemClickListener = new AdapterView.OnItemClickListener() {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            handleProblemItem(position);
        }
    };

    private TextWatcher mWriteProblemWacther = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {

            String problem = s.toString();
            if (!StringUtils.isEmpty(problem) && isChoiceType) {
                setCommitTrue();
            } else {
                setCommitFalse();
            }
        }
    };


    private TextWatcher mContaceWacther = new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {

            String problem = s.toString();
            isLeaveQQ = !StringUtils.isEmpty(problem);
        }
    };

    protected TooFastChecker mTooFastChecker = new TooFastChecker();
    private QuestionPresenter mPrecenter;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof QuestionActivity) {
            mQuestionActivity = (QuestionActivity) context;
        }
    }

    @Override
    public void onCreateView(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.fragment_question);
        mPrecenter = new QuestionPresenter(this);
        initView();

        getProblemList();
    }

    private void initView() {
        mProblemsText = findViewSetOnClick(R.id.question_choice_problem);
        mProblemsText.setClickable(false);
        mProblemListLayout = findView(R.id.question_problem_list_layout);
        mProblemListView = findView(R.id.question_problem_list);
        mContactEdit = findView(R.id.question_edit_contact);
        mWriteProblemEdit = findView(R.id.question_edit_write_problem);
        findViewSetOnClick(R.id.rl_question_feedback);
        mQuestionCommit = findViewSetOnClick(R.id.question_btn_commit);
        mQuestionFeedback = findView(R.id.tv_question_feedback);
        mRedPoint = findView(R.id.question_red_point);
        initFeedBackMsg();
        mContactEdit.setCursorVisible(false);
        mContactEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mContactEdit.setCursorVisible(true);
            }
        });
        setCommitFalse();
        mContactEdit.addTextChangedListener(mContaceWacther);
        mWriteProblemEdit.addTextChangedListener(mWriteProblemWacther);
    }

    private void initFeedBackMsg() {
        mQuestionFeedback.setText(ViewUtils.getString(R.string.question_problem_feedback_empty));
        mRedPoint.setVisibility(View.GONE);
    }

    private void setCommitTrue() {

        mQuestionCommit.setClickable(true);
        mQuestionCommit.setBackgroundResource(R.drawable.red_btn_bg);
    }

    private void setCommitFalse() {

        mQuestionCommit.setClickable(false);
        mQuestionCommit.setBackgroundColor(ViewUtils.getColor(R.color.standard_text_color_gray));
    }

    @Override
    protected void onVisibleToUserChanged(boolean isVisibleToUser) {
        super.onVisibleToUserChanged(isVisibleToUser);
        if (!isVisibleToUser) {
            KeyboardUtils.hideKeyboard(getActivity(), mContactEdit);
        }
    }

    @Override
    public void onClick(View v) {
        if (mTooFastChecker.isTooFast(Constants.MILLIS_700)) {
            return;
        }

        super.onClick(v);
        switch (v.getId()) {
            case R.id.question_choice_problem:
                toggleProblemList();
                break;
            case R.id.question_btn_commit:
                commitProblem();
                break;
            case R.id.rl_question_feedback:
                toQuestionFeedBack();
                break;
        }
    }

    private void toQuestionFeedBack() {
        Intent intent = new Intent(getActivity(), QuestionFeedBackActivity.class);
        getActivity().startActivity(intent);
    }

    private void getProblemList() {
        mPrecenter.getProblemList();
    }

    private void toggleProblemList() {

        if (View.VISIBLE == mProblemListLayout.getVisibility()) {
            mProblemListLayout.setVisibility(View.GONE);
        } else {
            mProblemListLayout.setVisibility(View.VISIBLE);
        }
    }

    private void handleResult(ProblemListBean problemListBean) {

        mProblemDetailBeanList = problemListBean.list;

        problemItemList = new ArrayList<>();
        for (ProblemDetailBean problemDetailBean : mProblemDetailBeanList) {
            problemItemList.add(problemDetailBean.typeName);
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.item_problem_list, R.id.item_problem_tv, problemItemList);
        mProblemListView.setAdapter(adapter);

        mProblemListView.setOnItemClickListener(mOnItemClickListener);
    }

    private void handleProblemItem(int position) {

        toggleProblemList();

        showSelectItem(position);
    }

    private void showSelectItem(int position) {
        isChoiceType = true;
        mTypeId = mProblemDetailBeanList.get(position).typeId;
        mTypeName = mProblemDetailBeanList.get(position).typeName;

        mProblemsText.setTextColor(ViewUtils.getColor(R.color.standard_text_color_gray));
        mProblemsText.setText(mTypeName);

        String problem = mWriteProblemEdit.getText().toString().trim();
        if (StringUtils.isEmpty(problem)) {
            setCommitFalse();
        } else {
            setCommitTrue();
        }
    }

    private void showSucceedDialog() {
        MTDialog dialog = new MTDialog(getActivity());
        dialog.setTitle("感谢！");
        dialog.setContentView(R.layout.question_feedback_dialog);
        dialog.setNegativeButton(getString(R.string.know), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                exit();
            }
        });
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    private void statiScontactUs() {
        exit();
    }

    private void exit() {
        if (null != getActivity()) {
            getActivity().finish();
        }
    }

    private void commitProblem() {
        if (!oneRequestFeedbackEnd) {
            return;
        }
        oneRequestFeedbackEnd = false;

        String contact = mContactEdit.getText().toString().trim();
        String content = mWriteProblemEdit.getText().toString();
        mPrecenter.commitProblem(mTypeId, contact, content);
    }

    @Override
    public void showProblemList(ProblemListBean listBean) {
        mProblemsText.setClickable(true);
        handleResult(listBean);
    }

    @Override
    public void onCommitSuccess() {
        oneRequestFeedbackEnd = true;
        showSucceedDialog();
    }
}
