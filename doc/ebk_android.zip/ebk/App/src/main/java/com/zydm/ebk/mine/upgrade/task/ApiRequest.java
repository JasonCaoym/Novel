package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.common.ParamKey;
import com.zydm.base.utils.StringUtils;
import com.zydm.ebk.mine.upgrade.FkErrorCode;

import java.util.HashMap;
import java.util.Map;

public class ApiRequest {

    /**
     * 数据加载模式: 遵守http缓存协商机制, 优先加载本地缓存, 本地缓存过期则访问服务器
     */
    public static final int REQ_MODE_LOCAL_CACHE_FIRST = 100;
    /**
     * /* 数据加载模式: 遵守http缓存协商机制, 向服务器确认本地缓存是否有效,收到304返回码则使用本地缓存
     */
    public static final int REQ_MODE_CONFIRM_WITH_SERVER = 101;
    /**
     * 数据加载模式: 强制更新数据,无视缓存协商机制
     */
    public static final int REQ_MODE_FORCE_UPDATE = 102;

    public static final int REQ_METHOD_GET = 1;
    public static final int REQ_METHOD_POST = 2;

    private int mErrorCode = FkErrorCode.UNKNOWN;
    private String mErrorMsg = "";
    private String mResponseData = null;
    private String mFullUrl = null;
    private String mUrlConst = null;
    private final HashMap<String, String> mParams = new HashMap<String, String>();
    private ApiTask mTask = null;
    private int mRequestMode = REQ_MODE_LOCAL_CACHE_FIRST;
    private int mRequestMethod = REQ_METHOD_POST;
    private int mCacheExpire = -1;
    private boolean mLoadFromCache = true;

    public ApiRequest(String urlConst) {
        this(urlConst, 0);
    }

    public ApiRequest(String urlConst, int cacheExpire) {
        this.mUrlConst = urlConst;
        this.mFullUrl = DomainHelper.fullUrl(urlConst);
        if (cacheExpire > 0) {
            this.mCacheExpire = cacheExpire;
        } else {
            setCacheExpire(DataUrlConst.getCacheExpiredTime(urlConst));
        }
    }

    protected String getFullUrl() {
        return mFullUrl;
    }

    public String getUrlConstant() {
        return mUrlConst;
    }

    public String getParam(String key) {
        return mParams.get(key);
    }

    public void addParam(String key, String value) {
        if (StringUtils.isBlank(value)) {
            return;
        }
        mParams.put(key, value);
    }

    public void addParam(String key, int value) {
        mParams.put(key, String.valueOf(value));
    }

    public void addParamAllowBlank(String key, String value) {
        if (StringUtils.isBlank(value)) {
            value = "";
        }
        mParams.put(key, value);
    }

    public void addParams(Map<String, String> params) {
        if (params == null) {
            return;
        }

        for (Map.Entry<String, String> entry : params.entrySet()) {
            if (!ParamKey.RESUME.equals(entry.getKey()) && StringUtils.isBlank(entry.getValue())) {
                continue;
            }
            mParams.put(entry.getKey(), entry.getValue());
        }
    }

    public int getErrorCode() {
        return mErrorCode;
    }

    public String getErrorMsg() {
        return mErrorMsg;
    }

    public String getResponseData() {
        return mResponseData;
    }

    /**
     * @param method default REQ_METHOD_GET
     * @see #REQ_METHOD_GET
     * @see #REQ_METHOD_POST
     */
    public void setRequestMethod(int method) {
        if (REQ_METHOD_POST == method) {
            mRequestMethod = method;
        }
    }

    /**
     * @param mode default REQ_MODE_LOCAL_CACHE_FIRST
     * @see #REQ_MODE_LOCAL_CACHE_FIRST
     * @see #REQ_MODE_CONFIRM_WITH_SERVER
     * @see #REQ_MODE_FORCE_UPDATE
     */
    public void setRequestMode(int mode) {
        mRequestMode = mode;
    }

    public boolean isLoadFromCache() {
        return mLoadFromCache;
    }

    protected int getRequestMethod() {
        return mRequestMethod;
    }

    public int getCacheExpire() {
        return mCacheExpire;
    }

    public void setCacheExpire(int cacheExpire) {
        this.mCacheExpire = cacheExpire;
    }

    protected int getRequestMode() {
        return mRequestMode;
    }

    protected HashMap<String, String> getParams() {
        return mParams;
    }

    protected boolean isCacheEnabled() {
        return mCacheExpire > 0;
    }

    protected void setTask(ApiTask task) {
        mTask = task;
    }

    protected ApiTask getTask() {
        return mTask;
    }

    protected void setErrorCode(int errorCode) {
        mErrorCode = errorCode;
    }

    protected void setErrorMsg(String errorMsg) {
        mErrorMsg = errorMsg;
    }

    protected void setResponseData(String responseData) {
        mResponseData = responseData;
    }

    protected void setDataSource(boolean fromCache) {
        mLoadFromCache = fromCache;
    }

    // for test
    public void setRespDataForTest(String responseData) {
        mResponseData = responseData;
        mErrorCode = FkErrorCode.OK;
    }

}
