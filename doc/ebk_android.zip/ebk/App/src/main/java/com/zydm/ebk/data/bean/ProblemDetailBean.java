package com.zydm.ebk.data.bean;

public class ProblemDetailBean {

    public String typeId;
    public String typeName;
}
