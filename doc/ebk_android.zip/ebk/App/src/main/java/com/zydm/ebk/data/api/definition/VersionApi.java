package com.zydm.ebk.data.api.definition;

import com.zydm.base.common.ParamKey;
import com.zydm.base.data.base.MtMap;
import com.zydm.base.data.net.ApiConfigs;
import com.zydm.base.data.net.BasePath;
import com.zydm.base.data.net.DataSrcBuilder;
import com.zydm.base.data.net.ExpTime;
import com.zydm.base.data.net.Param;
import com.zydm.ebk.data.bean.FeedBackMsgBean;
import com.zydm.ebk.mine.upgrade.UpdateInfoBean;

import io.reactivex.Completable;

@BasePath("/Api/Version/")
public interface VersionApi {

    Completable incrGrayCount();

    DataSrcBuilder<UpdateInfoBean> check(@Param(ParamKey.PACKAGE) String packageName,
                                         @Param(ParamKey.VERSION_CODE) String versionCode);

    @ApiConfigs(expTime = ExpTime.HALF_DAY)
    DataSrcBuilder<String> appCheck();
}
