package com.zydm.ebk.mine.upgrade.task;

import com.zydm.base.utils.ToastUtils;
import com.zydm.ebk.R;
import com.zydm.ebk.mine.upgrade.FkErrorCode;

import java.util.ArrayList;

public class BaseApiTask extends ApiTask {

    protected Object mTag;

    public BaseApiTask() {
    }

    public void setTag(Object tag) {
        this.mTag = tag;
    }

    public Object getTag() {
        return this.mTag;
    }

    @Override
    protected void onErrorCodeDefaultHandle(int errorCode, String errorMsg) {
        super.onErrorCodeDefaultHandle(errorCode, errorMsg);
        if (FkErrorCode.OK == errorCode) {
            return;
        }

        if (FkErrorCode.isNetWorkError(errorCode)) {
            ToastUtils.showLimited(R.string.toast_no_net);
            return;
        }
    }

    public boolean isEmpty() {
        return getAllRequest() == null || getAllRequest().size() == 0;
    }

    public void addReqParam(String key, String value) {
        ArrayList<ApiRequest> reqs = getAllRequest();
        for (ApiRequest apiRequest : reqs) {
            apiRequest.addParam(key, value);
        }
    }

    public void forceUpdate() {
        ArrayList<ApiRequest> reqs = getAllRequest();
        for (ApiRequest apiRequest : reqs) {
            apiRequest.setRequestMode(ApiRequest.REQ_MODE_FORCE_UPDATE);
        }
    }
}
