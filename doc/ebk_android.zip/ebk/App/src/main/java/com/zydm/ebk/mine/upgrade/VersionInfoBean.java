package com.zydm.ebk.mine.upgrade;


import java.io.Serializable;

public class VersionInfoBean implements Serializable {

    public int versionCode;
    public String versionName;
    public long size;
    public String link;
    public String md5;
    public String log;
    public int isGray;

    public String toString() {
        return "UpdateBean[versionCode:" + versionCode + ",versionName:" + versionName + ",link:" + link + ",md5:"
                + md5 + ";size:" + size + ";log:" + log + "]";
    }

    public boolean isGray() {
        return isGray != 0;
    }
}
