package com.zydm.ebk.mine.upgrade;

import com.zydm.base.common.Constants;

import java.io.Serializable;

public class UpdateInfoBean implements Serializable {

    public final static int NO_UPDATE = 0;
    public final static int NORMA_UPDATE = 1;
    public final static int FORCE_UPDATE = 2;
    public int result;
    public VersionInfoBean info;

    public boolean hasNewVersion(int curVersionCode) {
        return result != NO_UPDATE && info.versionCode > curVersionCode;
    }

    public boolean isForceUpdate() {
        return result == FORCE_UPDATE;
    }

    public String getLog() {
        return info == null ? Constants.EMPTY : info.log == null ? Constants.EMPTY : info.log;
    }

    public String getVersionName() {
        return info == null ? Constants.EMPTY : info.versionName == null ? Constants.EMPTY : info.versionName;
    }
}
