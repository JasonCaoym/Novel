package com.zydm.ebk.data.api;

import com.zydm.base.data.net.ApiFactory
import com.zydm.ebk.book.data.api.definition.QuestionApi
import com.zydm.ebk.data.api.definition.MessageApi
import com.zydm.ebk.data.api.definition.VersionApi

object Api {

    fun Question() = ApiFactory.getApiInstance(QuestionApi::class.java)

    fun message() = ApiFactory.getApiInstance(MessageApi::class.java)

    fun version() = ApiFactory.getApiInstance(VersionApi::class.java)
}