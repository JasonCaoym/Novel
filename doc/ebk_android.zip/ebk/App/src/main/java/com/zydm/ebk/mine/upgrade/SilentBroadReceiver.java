package com.zydm.ebk.mine.upgrade;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.zydm.base.common.Constants;
import com.zydm.base.utils.LogUtils;

public class SilentBroadReceiver extends BroadcastReceiver {

    public static final String TAG = "wifistatetest";

    @Override
    public void onReceive(Context context, Intent intent) {
        LogUtils.d(TAG, "SilentBroadReceiver onReceive");

        if (isWifiNetType(context)) {
            LogUtils.d(TAG, "wifi");
            UpgradeManager.getInstance().startSilentCheck(context);
        }

        String action = intent.getAction();
        if (UpgradeManager.ACTION_NOTIFICATION_DOWNLOAD_RECEIVER.equals(action)) {
            VersionInfoBean versionInfoBean = (VersionInfoBean) intent.getSerializableExtra(UpgradeManager.APK_INSTALL_INFO);
            if (null == versionInfoBean) {
                return;
            }
            UpgradeHelper.getInstance(context).tryHandleApkWithVersion(versionInfoBean, false);
        }
    }

    public boolean isWifiNetType(Context context) {

        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = manager.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            String type = networkInfo.getTypeName();
            if (type.equalsIgnoreCase(Constants.WIFI)) {
                return true;
            }
        }
        return false;
    }
}
