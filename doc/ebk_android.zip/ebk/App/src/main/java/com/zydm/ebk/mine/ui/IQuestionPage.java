package com.zydm.ebk.mine.ui;

import com.zydm.ebk.data.bean.ProblemListBean;

public interface IQuestionPage {

    void showProblemList(ProblemListBean listBean);

    void onCommitSuccess();
}
