package com.zydm.ebk.ui

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.ActivityCompat
import android.view.View
import android.widget.TabHost
import com.alibaba.android.arouter.facade.annotation.Route
import com.zydm.base.common.BaseApplication
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.tools.PhoneStatusManager
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.ui.fragment.BaseFragment
import com.zydm.base.utils.ToastUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.R
import com.zydm.ebk.book.ui.category.CategoryFragment
import com.zydm.ebk.book.ui.city.BookCityFragment
import com.zydm.ebk.mine.ui.MineFragment
import com.zydm.ebk.mine.upgrade.UpgradeManager
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.provider.router.RouterPath
import com.zymh.ebk.read.ui.bookshelf.BookShelfFragment
import kotlinx.android.synthetic.main.home_activity.*
import kotlinx.android.synthetic.main.home_tab_item.view.*

@Route(path = RouterPath.App.PATH_HOME)
class HomeActivity : BaseActivity() {
    private var mCurTab: Int = BOOK_CITY

    companion object {

        const val BOOK_CITY = 0
        const val CATEGORY = 1
        const val BOOKSHELF = 2
        const val MINE = 3
    }

    private val mOnTabChangedListener = TabHost.OnTabChangeListener { tabId ->
        mCurTab = tabId.toInt()
        if (mCurTab != BOOKSHELF) {
            val fragment = supportFragmentManager.findFragmentByTag(BOOKSHELF.toString())
            if (fragment != null) {
                (fragment as BookShelfFragment).quitEditMode()
            }
        }
        when (mCurTab) {
            BOOK_CITY -> StatisHelper.onEvent().bookstore(getPageName())
            CATEGORY -> StatisHelper.onEvent().classify()
            BOOKSHELF -> StatisHelper.onEvent().bookshelf()
            MINE -> StatisHelper.onEvent().home()
        }
    }

    private val mTabInfos = arrayOf(
            TabInfo(BookCityFragment::class.java, R.drawable.tab_book_city_selector, R.string.tab_book_city),
            TabInfo(CategoryFragment::class.java, R.drawable.tab_category_selector, R.string.tab_category),
            TabInfo(BookShelfFragment::class.java, R.drawable.tab_bookshelf_selector, R.string.tab_bookshelf),
            TabInfo(MineFragment::class.java, R.drawable.tab_mine_selector, R.string.tab_mine)
    )

    override fun initActivityConfig(activityConfig: ActivityConfig) {
        super.initActivityConfig(activityConfig)
        activityConfig.isStPage = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        UpgradeManager.getInstance().startBackgroundCheck(this@HomeActivity)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_activity)
        StatisHelper.onEvent().bookstore(intent.getParcelableExtra<BaseData>(DATA_KEY)?.from?: "启动页")
        initTab()
        PhoneStatusManager.getInstance().resetMtDeviceId()
        ActivityCompat.requestPermissions(this, arrayOf("android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE"), 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent == null) {
            return
        }
        StatisHelper.onEvent().bookstore(intent.getParcelableExtra<BaseData>(DATA_KEY)?.from
                ?: "启动页")
        tabhost.currentTab = BOOK_CITY
    }

    private fun initTab() {
        val mTabHost = tabhost
        mTabHost.setup(this, supportFragmentManager, android.R.id.tabcontent)
        for (i in mTabInfos.indices) {
            val tabInfo = mTabInfos[i]
            val tabSpec = mTabHost.newTabSpec("$i")
                    .setIndicator(createTabItemView(tabInfo))
            mTabHost.addTab(tabSpec, tabInfo.mFragmentClass, null)
        }
        mTabHost.setOnTabChangedListener(mOnTabChangedListener)
        mTabHost.setCurrentTab(BOOK_CITY)
    }

    private fun createTabItemView(tabInfo: TabInfo): View {
        val tabItemView = ViewUtils.inflateView(this, R.layout.home_tab_item)
        tabItemView.tab_name.setText(tabInfo.textRes)
        tabItemView.tab_icon.setImageResource(tabInfo.iconRes)
        return tabItemView
    }

    private var exitTime: Long = 0
    override fun onBackPressed() {
        if (mCurTab == BOOKSHELF) {
            val fragment = supportFragmentManager.findFragmentByTag(BOOKSHELF.toString())
            if (fragment != null) {
                val bookShelfFragment = fragment as BookShelfFragment
                if (bookShelfFragment.isEditMode) {
                    bookShelfFragment.quitEditMode()
                    return
                }
            }
        }
        if (System.currentTimeMillis() - exitTime > 3000) {
            ToastUtils.showLimited(getString(R.string.back_quit))
            exitTime = System.currentTimeMillis()
        } else {
            super.onBackPressed()
            BaseApplication.context.exit()
        }
    }

    data class TabInfo(val mFragmentClass: Class<out BaseFragment>, val iconRes: Int, val textRes: Int)
}
