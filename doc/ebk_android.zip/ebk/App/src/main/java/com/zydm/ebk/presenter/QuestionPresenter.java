package com.zydm.ebk.presenter;

import android.annotation.SuppressLint;

import com.zydm.base.rx.MtSchedulers;
import com.zydm.ebk.data.api.Api;
import com.zydm.ebk.data.bean.ProblemListBean;
import com.zydm.ebk.mine.ui.IQuestionPage;

import io.reactivex.functions.Action;
import io.reactivex.functions.Consumer;

public class QuestionPresenter {

    private IQuestionPage mPage;

    public QuestionPresenter(IQuestionPage page) {
        mPage = page;
    }

    @SuppressLint("CheckResult")
    public void getProblemList() {
        Api.INSTANCE.Question().getType().build().subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(new Consumer<ProblemListBean>() {
            @Override
            public void accept(ProblemListBean problemListBean) throws Exception {
                mPage.showProblemList(problemListBean);
            }
        });
    }

    @SuppressLint("CheckResult")
    public void commitProblem(String mTypeId, String contact, String content) {
        Api.INSTANCE.Question().addIssue(mTypeId, contact, content).subscribeOn(MtSchedulers.io()).observeOn(MtSchedulers.mainUi()).subscribe(new Action() {
            @Override
            public void run() throws Exception {
                mPage.onCommitSuccess();
            }
        });
    }
}
