package com.zydm.ebk.data.bean;

import java.util.List;

public class ProblemListBean {

    public List<ProblemDetailBean> list;

}
