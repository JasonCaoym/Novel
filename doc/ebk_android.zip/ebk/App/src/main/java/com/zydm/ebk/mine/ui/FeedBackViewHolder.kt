package com.zydm.ebk.mine.ui

import android.widget.ImageView
import com.zydm.base.ext.loadUrl
import com.zydm.base.ext.setVisible

import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.StringUtils
import com.zydm.base.utils.TimeUtils
import com.zydm.base.widgets.MsgExpandTextView
import com.zydm.ebk.R
import com.zydm.ebk.data.bean.FeedBackDetailBean
import com.zydm.ebk.mine.MineManager
import kotlinx.android.synthetic.main.item_private_feedback.view.*

@Suppress("PLUGIN_WARNING")
class FeedBackViewHolder : AbsItemView<FeedBackDetailBean>() {

    private lateinit var mTextviewexpandable: MsgExpandTextView
    private var isClicked = false
    private val mExpandStateChangeListener = MsgExpandTextView.ExpandStateChangeListener {
        isClicked = true;
        mItemView.red_img.setVisible(false)
        mItemData.isShrink = it
    }

    override fun onCreate() {
        setContentView(R.layout.item_private_feedback)
        mTextviewexpandable = mItemView.private_text_expand as MsgExpandTextView
        mTextviewexpandable.addExpandStateChangeListener(mExpandStateChangeListener)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        if (!StringUtils.isBlank(mItemData.time)) {
            val date = TimeUtils.parseTime(mItemData.time)
            mItemView.private_tv_date.text = StringUtils.formatUnixTime(date)
        }
        mItemView.red_img.setVisible(mPosition <= MineManager.FEEDBACK_NEW_NUM - 1 && !isClicked)

        if (mItemData.isFeedBack) {
            val feedback: FeedBackDetailBean.FeedbackBean? = mItemData.feedback
            if (feedback != null) {
                mTextviewexpandable.setFeedBackText(mItemData.content, feedback.time, feedback.typeName, feedback.content, mItemData.isShrink);
            }
        }
        val img = mItemView.user_face_img as ImageView
        img.loadUrl(mItemData.img)
    }
}
