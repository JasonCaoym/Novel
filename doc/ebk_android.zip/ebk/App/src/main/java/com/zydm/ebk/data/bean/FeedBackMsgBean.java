package com.zydm.ebk.data.bean;

import com.zydm.base.data.bean.ListBean;

public class FeedBackMsgBean extends ListBean<FeedBackDetailBean> {
    public int newCount;
}
