package com.zydm.ebk.data.api.definition;

import com.zydm.base.data.net.ApiConfigs;
import com.zydm.base.data.net.BasePath;
import com.zydm.base.data.net.DataSrcBuilder;
import com.zydm.base.data.net.ExpTime;
import com.zydm.ebk.data.bean.FeedBackMsgBean;

@BasePath("/Api/Message/")
public interface MessageApi {

    @ApiConfigs(expTime = ExpTime.ONE_SECOND)
    DataSrcBuilder<FeedBackMsgBean> feedBackHistory();
}
