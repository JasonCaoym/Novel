package com.zydm.ebk.provider.data.bean

import android.graphics.Bitmap

class ThreeAdBean {
    var title: String = ""
    var imgUrl: Array<String>? = null
    var resume: String = ""
    var brandIcon: Bitmap? = null
    var type: Int = 0
}