package com.zydm.ebk.provider.ad

import android.app.Activity
import android.view.ViewGroup
import com.zydm.ebk.provider.data.bean.AdConfig

class AdHelperAdapter(val mActivity: Activity): IAdHelper {

    private val mListenerSet = HashSet<ADListener>()
    private val mAdHelperMap = HashMap<Int, IAdHelper>()

    override fun addListener(adListener: ADListener) {
        mListenerSet.add(adListener)
        mAdHelperMap.values.forEach {
            it.addListener(adListener)
        }
    }

    override fun removeListener(adListener: ADListener) {
        mListenerSet.remove(adListener)
        mAdHelperMap.values.forEach {
            it.removeListener(adListener)
        }
    }

    override fun loadBannerAd(adParam: AdParam, containerView: ViewGroup) {
        getRealHelper(adParam.mConfig.source)?.loadBannerAd(adParam, containerView)
    }

    override fun loadBannerAd(adParam: AdParam, loadBannerAdListener: LoadBannerAdListener) {
        getRealHelper(adParam.mConfig.source)?.loadBannerAd(adParam, loadBannerAdListener)
    }

    override fun loadSplashAd(adParam: AdParam, containerView: ViewGroup) {
        getRealHelper(adParam.mConfig.source)?.loadSplashAd(adParam, containerView)
    }

    override fun loadInteractionAd(adParam: AdParam) {
        getRealHelper(adParam.mConfig.source)?.loadInteractionAd(adParam)
    }

    override fun loadNativeAd(adParam: AdParam, callback: NativeAdCallback) {
        getRealHelper(adParam.mConfig.source)?.loadNativeAd(adParam, callback)
    }

    private fun getRealHelper(source: Int): IAdHelper? {
        if (mAdHelperMap.containsKey(source)) {
            return mAdHelperMap[source]
        }

        val adHelper = when (source) {
            AdConfig.SOURCE_CSJ -> AdMgr.mTTPlatform?.createHelper(mActivity)
            AdConfig.SOURCE_GDT -> AdMgr.mGDTPlatform?.createHelper(mActivity)
            else -> null
        }
        if (adHelper != null) {
            mAdHelperMap[source] = adHelper
            mListenerSet.forEach {
                adHelper.addListener(it)
            }
        }
        return adHelper
    }
}