package com.zydm.ebk.provider.ad.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import com.zydm.base.ext.loadUrl
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.NativeAd
import com.zydm.ebk.provider.data.bean.AdConstants
import kotlinx.android.synthetic.main.ad_small_single.view.*


class SingleSmallHolder(var adBean: NativeAd, var parent: ViewGroup, val activity: Activity) {

    fun setData() {
        val rootView = LayoutInflater.from(activity).inflate(R.layout.ad_small_single, parent, true) as ViewGroup
        rootView.ad_small_title_tv.text = adBean.getTitle()
        rootView.ad_small_iv.loadUrl(adBean.getImageList()[0])
        rootView.small_brand_logo.setImageBitmap(adBean.getAdLogo())
        rootView.ad_small_resume_tv.text = adBean.getDescription()
        val type = ViewUtils.getString(if (adBean.getInteractionType() == AdConstants.INTERACTION_TYPE_DOWNLOAD) R.string.download_now else R.string.see_detail)
        rootView.ad_small_type_tv.text = type
        adBean.registerViewForInteraction(rootView, rootView, rootView.ad_small_type_tv)
    }
}
