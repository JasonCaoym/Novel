package com.zydm.ebk.provider.data

import com.zydm.ebk.provider.ad.IAdHelper

class TopAdData(val mIAdHelper: IAdHelper, val mAdPos: Int, val mStType: String = "")

public class AdData(val mIAdHelper: IAdHelper, val mAdPos: Int, val mStType: String = "")

public class AdNativeData(val mIAdHelper: IAdHelper, val mAdPos: Int, val mStType: String = "")