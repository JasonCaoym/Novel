package com.zydm.ebk.provider.ad.ui

import com.zydm.base.common.Constants
import com.zydm.base.tools.TooFastChecker
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.ebk.provider.data.AdNativeData
import kotlinx.android.synthetic.main.ad_item_view.view.*

class NativeAdItemView : AbsItemView<AdNativeData>() {

    private val mTooFastChecker = TooFastChecker(Constants.SECOND_5)

    override fun onCreate() {
        setContentView(R.layout.native_ad_item_view)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        val adParam = AdMgr.getAdParam(mItemData.mAdPos, mItemData.mStType)
        if (isPosChanged && !mTooFastChecker.isTooFast()) {
            mItemData.mIAdHelper.loadBannerAd(adParam, mItemView.ad_layout)
        }
    }
}