package com.zydm.ebk.provider.ad.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import com.zydm.base.ext.loadUrl
import com.zydm.base.ext.setVisible
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.NativeAd
import com.zydm.ebk.provider.data.bean.AdConstants
import kotlinx.android.synthetic.main.ad_interaction_view.view.*


class InteractionBigHolder(var adBean: NativeAd, var parent: ViewGroup, val activity: Activity) {

    fun setData(close: () -> Unit) {
        val rootView: ViewGroup =
            LayoutInflater.from(activity).inflate(R.layout.ad_interaction_view, parent, true) as ViewGroup;
        if (adBean.getImageMode() == AdConstants.IMG_VIEW) {
            rootView.ad_big_single_layout.setVisible(false)
            val adLayout = rootView.ad_gdt_layout
            adLayout.setVisible(true)

            adLayout.addView(adBean.getAdView())
            adLayout.post {
                adBean.render()
            }
        } else {
            rootView.ad_gdt_layout.setVisible(false)
            rootView.ad_big_single_layout.setVisible(true)

            rootView.ad_big_title_tv.text = adBean.getTitle()
            rootView.ad_big_iv.loadUrl(adBean.getImageList()[0])
            rootView.ad_big_brand_logo.loadUrl(adBean.getIcon())
            val type = ViewUtils.getString(if (adBean.getInteractionType() == AdConstants.INTERACTION_TYPE_DOWNLOAD) R.string.download_now else R.string.see_detail)
            rootView.ad_big_type_tv.text = type
            adBean.registerViewForInteraction(rootView, rootView, rootView.ad_big_type_tv)
        }
        rootView.close_btn.setOnClickListener {
            close()
        }
    }
}
