package com.zydm.ebk.provider.data.bean

class AdBean {
    var id = ""
    var limit = 0
    var pos = 0 //广告位
    var enableDays = 0
}

class AdConfig {

    companion object {

        const val TYPE_IMPEL = 1;      //激励视频
        const val TYPE_BANNER = 2;     //banner
        const val TYPE_LAUNCHING = 3;  //开屏
        const val TYPE_INSERT_SCREEN = 4;  //插屏
        const val TYPE_FULL_SCREEN = 5;   //全屏视频
        const val TYPE_INFORMATION_FLOW = 6;  //信息流

        const val SOURCE_CSJ = 1;   //穿山甲
        const val SOURCE_BAI_DU = 2;  //百度
        const val SOURCE_GDT = 3  //广点通
    }


    var id = ""
    var source = 0
    var slotId = ""
    var isOriginal = 0//是否原生广告 1是
    var type = 0 //广告类型
    var height = 0
        get() = if (field <= 0) 1920 else field
    var width = 0
        get() = if (field <= 0) 1080 else field

    fun isOriginal_(): Boolean {
        return isOriginal == 1
    }

    override fun toString(): String {
        return "AdConfig(id='$id', source=$source, slotId='$slotId', isOriginal=$isOriginal, type=$type)"
    }
}