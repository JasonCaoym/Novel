package com.zydm.ebk.provider.ad

import android.view.ViewGroup

object AdUtils {

    fun destroyAd(adContainer: ViewGroup?) {
        adContainer?.destroyAd()
    }
}

fun ViewGroup.destroyAd() {

    val child = getChildAt(0) ?: return

    val tag = child.tag ?: return

    if (tag is NativeAd) {
        tag.destroy()
    }
}