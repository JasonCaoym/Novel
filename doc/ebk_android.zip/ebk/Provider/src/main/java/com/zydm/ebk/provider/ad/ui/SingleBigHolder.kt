package com.zydm.ebk.provider.ad.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import com.zydm.base.ext.loadUrl
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.NativeAd
import com.zydm.ebk.provider.data.bean.AdConstants
import kotlinx.android.synthetic.main.ad_big_single.view.*


class SingleBigHolder(var adBean: NativeAd, var parent: ViewGroup, val activity: Activity) {

    fun setData() {
        val rootView: ViewGroup =
            LayoutInflater.from(activity).inflate(R.layout.ad_big_single, parent, true) as ViewGroup;
        rootView.ad_big_title_tv.text = adBean.getTitle()
        rootView.ad_big_iv.loadUrl(adBean.getImageList()[0])
        rootView.ad_big_brand_logo.loadUrl(adBean.getIcon())
        val type = ViewUtils.getString(if (adBean.getInteractionType() == AdConstants.INTERACTION_TYPE_DOWNLOAD) R.string.download_now else R.string.see_detail)
        rootView.ad_big_type_tv.text = type
        adBean.registerViewForInteraction(rootView, rootView, rootView.ad_big_type_tv)
    }
}
