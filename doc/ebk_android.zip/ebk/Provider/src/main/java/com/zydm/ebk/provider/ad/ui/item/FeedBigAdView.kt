package com.zydm.ebk.provider.ad.ui.item

import android.view.ViewGroup
import com.zydm.base.ext.loadUrl
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.data.bean.AdConstants
import kotlinx.android.synthetic.main.ad_big_single.view.*


class FeedBigAdView: AbsItemView<FeedBigImgAD>() {

    override fun onCreate() {
        setContentView(R.layout.ad_big_single)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        val adBean = mItemData.mAd
        mItemView.ad_big_iv.loadUrl(adBean.getImageList()[0])
        mItemView.ad_big_brand_logo.loadUrl(adBean.getIcon())
        val type = ViewUtils.getString(if (adBean.getInteractionType() == AdConstants.INTERACTION_TYPE_DOWNLOAD) R.string.download_now else R.string.see_detail)
        mItemView.ad_big_type_tv.text = type
        adBean.registerViewForInteraction(mItemView as ViewGroup, mItemView, mItemView.ad_big_type_tv)
    }
}
