package com.zydm.ebk.provider.ad.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.zydm.base.utils.ViewUtils;
import com.zydm.ebk.provider.R;
import com.zydm.ebk.provider.ad.AdMgr;
import com.zydm.ebk.provider.ad.AdParam;
import com.zydm.ebk.provider.ad.AdUtils;
import com.zydm.ebk.provider.ad.IAdHelper;
import com.zydm.ebk.provider.ad.NativeAd;
import com.zydm.ebk.provider.ad.NativeAdCallback;
import com.zydm.ebk.provider.data.bean.AdConfig;
import com.zydm.ebk.provider.data.bean.AdConstants;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class AutoScrollAdView extends FrameLayout {

    private final Activity mActivity;
    private AdParam mAdParam;
    private FrameLayout mAdRoot1;
    private FrameLayout mAdRoot2;
    private FrameLayout mCurAdRoot;
    private IAdHelper mAdHelper;
    private OnHeightConfirmedListener mListener;
    private int mAdHeight;
    private Timer timer = new Timer();
    private TimerTask task = new TimerTask() {
        @Override
        public void run() {
            post(new Runnable() {
                @Override
                public void run() {
                    final FrameLayout needRemove = mCurAdRoot;
                    final FrameLayout needShow = mCurAdRoot == mAdRoot1 ? mAdRoot2 : mAdRoot1;
                    if (needShow.getChildCount() != 0) {
                        AdUtils.INSTANCE.destroyAd(needShow);
                        needShow.removeAllViews();
                    }
                    mAdHelper.loadNativeAd(mAdParam, new NativeAdCallback() {
                        @Override
                        public void callback(@NotNull ArrayList<NativeAd> ads) {

                        }

                        @Override
                        public void callback(@NotNull NativeAd ad) {
                            int mode = ad.getImageMode();
                            if (mode != AdConstants.IMG_SMALL && mode != AdConstants.IMG_VIEW) {
                                setVisibility(INVISIBLE);
                                return;
                            }
                            mCurAdRoot = needShow;
                            if (mode == AdConstants.IMG_SMALL) {
                                SingleSmallHolder holder = new SingleSmallHolder(ad, needShow, mActivity);
                                holder.setData();
                                setNightMode(mIsNightMode);
                            } else {
                                View adView = ad.getAdView();
                                if (needShow.getChildCount() > 0 && needShow.getChildAt(0) == adView) {
                                    return;
                                }

                                if (needShow.getChildCount() > 0) {
                                    AdUtils.INSTANCE.destroyAd(needShow);

                                    needShow.removeAllViews();
                                }

                                if (adView.getParent() != null) {
                                    ((ViewGroup) adView.getParent()).removeView(adView);
                                }

                                needShow.addView(adView);
                                ad.render();
                            }

                            ValueAnimator animator = ValueAnimator.ofFloat(0.0f, -getWidth());
                            animator.setDuration(400);
                            animator.setInterpolator(new DecelerateInterpolator());
                            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                                @Override
                                public void onAnimationUpdate(ValueAnimator animation) {
                                    needRemove.setTranslationX((Float) animation.getAnimatedValue());
                                    needShow.setTranslationX((Float) animation.getAnimatedValue() + getWidth());
                                }
                            });
                            animator.addListener(new AnimatorListenerAdapter() {
                                @Override
                                public void onAnimationEnd(Animator animation) {
                                    bringChildToFront(mCurAdRoot);
                                    needRemove.setTranslationX(getWidth());
                                }
                            });
                            animator.start();
                        }
                    });
                }
            });

        }
    };
    private boolean mIsNightMode;
    private boolean mSupportNight = true;

    public AutoScrollAdView(@NonNull Context context) {
        this(context, null);
    }

    public AutoScrollAdView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, -1);
    }

    public AutoScrollAdView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mActivity = (Activity) context;
    }

    public void supportNightMode(boolean support) {
        mSupportNight = support;
    }


    public void init(IAdHelper adHelper, AdParam adParam, boolean isNightMode) {
        mAdHelper = adHelper;
        mAdParam = adParam;
        mIsNightMode = isNightMode;
        if (adParam == null || !AdMgr.INSTANCE.isShowAd(adParam.getMAdPos())) {
            setVisibility(INVISIBLE);
            mListener.onHeightConfirm(0);
            timer.cancel();
            return;
        }
        int type = mAdParam.getMConfig().getType();
        if (mAdParam.getMConfig().isOriginal_() && type != AdConfig.TYPE_BANNER && type != AdConfig.TYPE_INFORMATION_FLOW) {
            setVisibility(INVISIBLE);
            mListener.onHeightConfirm(0);
            return;
        }
        setVisibility(VISIBLE);
        if (mAdParam.getMConfig().isOriginal_()) {
            mAdRoot1 = new FrameLayout(getContext());
            mAdRoot2 = new FrameLayout(getContext());
            addView(mAdRoot1, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            addView(mAdRoot2, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            mListener.onHeightConfirm(ViewUtils.dp2px(70));
            ViewUtils.setViewHeight(this, ViewUtils.dp2px(70));
        } else {
            AdConfig config = adParam.getMConfig();
            int width = ViewUtils.getPhonePixels()[0];
            mAdHeight = (int) (width * ((float) config.getHeight() / (float) config.getWidth()));
            ViewUtils.setViewSize(this, width, mAdHeight);
            mListener.onHeightConfirm(mAdHeight);
        }
        loadAd();
    }

    private void loadAd() {
        if (!mAdParam.getMConfig().isOriginal_()) {
            mAdHelper.loadBannerAd(mAdParam, this);
        } else {
            mAdHelper.loadNativeAd(mAdParam, new NativeAdCallback() {
                @Override
                public void callback(@NotNull ArrayList<NativeAd> ads) {

                }

                @Override
                public void callback(@NotNull NativeAd ad) {
                    int mode = ad.getImageMode();
                    if (mode != AdConstants.IMG_SMALL && mode != AdConstants.IMG_VIEW) {
                        setVisibility(INVISIBLE);
                        return;
                    }
                    if (mode == AdConstants.IMG_SMALL) {
                        SingleSmallHolder holder = new SingleSmallHolder(ad, mAdRoot2, mActivity);
                        holder.setData();
                        setNightMode(mIsNightMode);
                    } else {
                        View adView = ad.getAdView();
                        if (mAdRoot2.getChildCount() > 0 && mAdRoot2.getChildAt(0) == adView) {
                            return;
                        }

                        if (mAdRoot2.getChildCount() > 0) {
                            AdUtils.INSTANCE.destroyAd(mAdRoot2);

                            mAdRoot2.removeAllViews();
                        }

                        if (adView.getParent() != null) {
                            ((ViewGroup) adView.getParent()).removeView(adView);
                        }

                        mAdRoot2.addView(adView);
                        ad.render();
                    }
                    mCurAdRoot = mAdRoot2;
                    mAdRoot1.setTranslationX(getWidth());
                    timer.schedule(task, 35 * 1000, 35 * 1000);
                }
            });
        }
    }

    public void setOnHeightConfirmListener(OnHeightConfirmedListener listener) {
        mListener = listener;
    }

    public interface OnHeightConfirmedListener {
        void onHeightConfirm(int height);
    }

    public void setNightMode(boolean isNightMode) {
        if (mAdRoot1 == null || mAdRoot2 == null) {
            return;
        }
        if (!mSupportNight) {
            return;
        }
        mIsNightMode = isNightMode;
        if (getVisibility() == GONE) {
            return;
        }

        if (!mAdParam.getMConfig().isOriginal_()) {
            return;
        }
        if (mAdParam.getMConfig().getSource() == AdConfig.SOURCE_GDT) {
            return;
        }
        setNightMode(mAdRoot1, isNightMode);
        setNightMode(mAdRoot2, isNightMode);
    }

    private void setNightMode(FrameLayout adRoot, boolean isNightMode) {
        if (adRoot.getChildCount() == 0) {
            return;
        }
        TextView title = adRoot.findViewById(R.id.ad_small_title_tv);
        RelativeLayout adlayout = adRoot.findViewById(R.id.ad_small_single_layout);
        TextView resume = adRoot.findViewById(R.id.ad_small_resume_tv);
        if (title != null) {
            title.setTextColor(ViewUtils.getColor(isNightMode ? R.color.standard_black_third_level_color_c5 : R.color.standard_black_first_level_color_c3));
        }
        if (resume != null) {
            resume.setTextColor(ViewUtils.getColor(isNightMode ? R.color.standard_black_third_level_color_c5 : R.color.standard_black_second_level_color_c4));
        }
        if (adlayout != null) {
            adlayout.setBackgroundColor(ViewUtils.getColor(isNightMode ? R.color.standard_black_second_level_color_c4 : R.color.white));
        }
    }

    public void destroy() {
        timer.cancel();
        destroyAd();
    }

    public void destroyAd() {
        AdUtils.INSTANCE.destroyAd(mAdRoot1);
        AdUtils.INSTANCE.destroyAd(mAdRoot2);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        destroyAd();
    }
}
