package com.zydm.ebk.provider.data.bean

class AdConstants {
    companion object {
        const val INTERACTION_TYPE_BROWSER = 2
        const val INTERACTION_TYPE_LANDING_PAGE = 3
        const val INTERACTION_TYPE_DOWNLOAD = 4
        const val INTERACTION_TYPE_DIAL = 5
        const val INTERACTION_TYPE_UNKNOWN = -1

        const val IMG_SMALL = 2
        const val IMG_BIG = 3
        const val IMG_GROUP = 4
        const val IMG_VIEW = 5
    }
}