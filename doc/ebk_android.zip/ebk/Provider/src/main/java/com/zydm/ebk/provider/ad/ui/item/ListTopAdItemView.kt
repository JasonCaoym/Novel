package com.zydm.ebk.provider.ad.ui.item

import android.graphics.Color
import android.view.ViewGroup
import com.zydm.base.common.Constants
import com.zydm.base.tools.TooFastChecker
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.ebk.provider.ad.OnAdLoadedListener
import com.zydm.ebk.provider.ad.loadAdWhitContainer
import com.zydm.ebk.provider.data.TopAdData
import kotlinx.android.synthetic.main.ad_item_view.view.*

class ListTopAdItemView : AbsItemView<TopAdData>() {

    private val mTooFastChecker = TooFastChecker(Constants.SECOND_5)

    override fun onCreate() {
        setContentView(R.layout.list_top_ad_item_view)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        if (!isPosChanged || mTooFastChecker.isTooFast()) {
            return
        }

        val adParam = AdMgr.getAdParam(mItemData.mAdPos, mItemData.mStType)
        val adLayout = mItemView.ad_layout
        if (adParam.mConfig.isOriginal_()) {

            adLayout.removeAllViews()

            val layoutParams = adLayout.layoutParams
            layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            layoutParams.width = ViewGroup.LayoutParams.MATCH_PARENT
            adLayout.requestLayout()
            mItemData.mIAdHelper.loadAdWhitContainer(adParam, adLayout, mActivity, object : OnAdLoadedListener{
                override fun onAdLoad(imageMode: Int) {
                    adLayout.getChildAt(0).setBackgroundColor(Color.WHITE)
                }

            })


        } else {
            val config = adParam.mConfig
            val width = ViewUtils.getPhonePixels()[0]
            val height = width * (config.height / config.width.toFloat())
            ViewUtils.setViewSize(adLayout, width, height.toInt())
            mItemData.mIAdHelper.loadBannerAd(adParam, adLayout)
        }
    }
}