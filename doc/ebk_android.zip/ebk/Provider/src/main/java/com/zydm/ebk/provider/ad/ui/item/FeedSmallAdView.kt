package com.zydm.ebk.provider.ad.ui.item

import android.graphics.Color
import android.view.ViewGroup
import com.zydm.base.ext.loadUrl
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.ebk.provider.data.bean.AdConstants
import kotlinx.android.synthetic.main.ad_small_single.view.*


class FeedSmallAdView : AbsItemView<FeedSmallImgAD>() {

    override fun onCreate() {
        setContentView(R.layout.ad_small_single)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        val adBean = mItemData.mAd
        mItemView.ad_small_title_tv.text = adBean.getTitle()
        mItemView.ad_small_iv.loadUrl(adBean.getImageList()[0])
        mItemView.small_brand_logo.setImageBitmap(adBean.getAdLogo())
        mItemView.ad_small_resume_tv.text = adBean.getDescription()
        val type = ViewUtils.getString(if (adBean.getInteractionType() == AdConstants.INTERACTION_TYPE_DOWNLOAD) R.string.download_now else R.string.see_detail)
        mItemView.ad_small_type_tv.text = type
        adBean.registerViewForInteraction(mItemView as ViewGroup, mItemView, mItemView.ad_small_type_tv)

        if (adBean.getAdParam().mAdPos == AdMgr.AD_SUB_LIST_TOP) {
            mItemView.ad_small_single_layout.setBackgroundColor(Color.WHITE)
            mItemView.setPadding(0, ViewUtils.dp2px(6f), 0, ViewUtils.dp2px(6f))
        } else {
            mItemView.ad_small_single_layout.setBackgroundColor(ViewUtils.getColor(R.color.ad_bg))
            mItemView.setPadding(0, 0, 0, 0)
        }
    }
}
