package com.zydm.ebk.provider.ad.ui.item

import android.view.ViewGroup
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import kotlinx.android.synthetic.main.ad_item_view.view.*

class BannerItemView : AbsItemView<BannerADItemData>() {

    override fun onCreate() {
        setContentView(R.layout.list_top_ad_item_view)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        val adLayout = mItemView.ad_layout
        val adView = mItemData.mAdView
        if (adLayout.getChildAt(0) == adView) {
            return
        }

        val config = mItemData.mAdParam.mConfig
        val width = ViewUtils.getPhonePixels()[0]
        val height = width * (config.height / config.width.toFloat())
        ViewUtils.setViewSize(adLayout, width, height.toInt())

        adLayout.removeAllViews()
        if (adView.parent is ViewGroup) {
            (adView.parent as ViewGroup).removeView(adView)
        }
        adLayout.addView(adView)
    }
}