package com.zydm.ebk.provider.ad

import android.app.Activity
import com.alibaba.android.arouter.facade.template.IProvider

interface IAdPlatform: IProvider {

    fun initPlatform(activity: Activity)

    fun createHelper(activity: Activity): IAdHelper
}
