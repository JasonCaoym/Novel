package com.zydm.ebk.provider.ad

import android.view.View
import android.view.ViewGroup
import com.zydm.ebk.provider.data.bean.AdConfig

interface IAdHelper {
    fun loadBannerAd(adParam: AdParam, containerView: ViewGroup)

    fun loadBannerAd(adParam: AdParam, loadBannerAdListener: LoadBannerAdListener)

    fun loadSplashAd(adParam: AdParam, containerView: ViewGroup)

    fun loadInteractionAd(adParam: AdParam)

    fun addListener(adListener: ADListener)

    fun removeListener(adListener: ADListener)

    fun loadNativeAd(adParam: AdParam, callback: NativeAdCallback)
}

interface ADListener {

    fun onAdShow(param: AdParam) {

    }

    fun onAdClicked(param: AdParam, from: String) {

    }

    fun onAdDismiss(param: AdParam, reason: String) {

    }

    fun onAdError(param: AdParam, code: Int, msg: String) {

    }
}

interface LoadBannerAdListener {
    fun onLoadBanner(bannerADView: View?)
}

data class AdParam(
    var mConfig: AdConfig,
    var mAdPos: Int,
    var mLimit: Int,
    var mCount: Int = 1,
    var mFrom: String = "",
    var mNewUserDays: Int = 0,
    var mAdSpace: Int = 20
)