package com.zydm.ebk.provider.data

import com.zydm.base.data.net.ApiFactory
import com.zydm.ebk.provider.data.definition.AdApi

object CommonApi {

    fun Ad() = ApiFactory.getApiInstance(AdApi::class.java)
}
