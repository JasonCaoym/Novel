package com.zydm.ebk.provider.ad.ui

import android.app.Activity
import android.view.LayoutInflater
import android.view.ViewGroup
import com.zydm.base.ext.loadUrl
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.NativeAd
import com.zydm.ebk.provider.data.bean.AdConstants
import kotlinx.android.synthetic.main.ad_small_three.view.*


class ThreeHolder(var adBean: NativeAd, var parent: ViewGroup, val activity: Activity) {

    fun setData() {
        val rootView = LayoutInflater.from(activity).inflate(R.layout.ad_small_three, parent, true) as ViewGroup
        rootView.ad_three_title_tv.text = adBean.getTitle()
        rootView.ad_iv_01.loadUrl(adBean.getImageList()[0])
        rootView.ad_iv_02.loadUrl(adBean.getImageList()[1])
        rootView.ad_iv_03.loadUrl(adBean.getImageList()[2])
        val width = (ViewUtils.getPhonePixels()[0] - ViewUtils.dp2px(16.0f) * 2 - ViewUtils.dp2px(2.0f) * 2) / 3.0f.toInt()
        ViewUtils.setViewSize(rootView.ad_iv_01, width, (width / 1.52f).toInt())
        ViewUtils.setViewSize(rootView.ad_iv_02, width, (width / 1.52f).toInt())
        ViewUtils.setViewSize(rootView.ad_iv_03, width, (width / 1.52f).toInt())

        rootView.three_brand_logo.setImageBitmap(adBean.getAdLogo())
        val type = ViewUtils.getString(if (adBean.getInteractionType() == AdConstants.INTERACTION_TYPE_DOWNLOAD) R.string.download_now else R.string.see_detail)
        rootView.ad_three_type_tv.text = type
        adBean.registerViewForInteraction(rootView, rootView, rootView.ad_three_type_tv)
    }
}
