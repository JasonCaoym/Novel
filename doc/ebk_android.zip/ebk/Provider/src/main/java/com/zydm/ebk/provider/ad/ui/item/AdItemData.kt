package com.zydm.ebk.provider.ad.ui.item

import android.view.View
import com.zydm.ebk.provider.ad.AdParam
import com.zydm.ebk.provider.ad.NativeAd

data class FeedSmallImgAD(val mAd: NativeAd)

data class FeedBigImgAD(val mAd: NativeAd)

data class FeedGroupImgAD(val mAd: NativeAd)

data class BannerADItemData(val mAdParam: AdParam, val mAdView: View)

data class FeedViewAD(val mAd: NativeAd)