package com.zydm.ebk.provider.data.definition

import com.zydm.base.common.ParamKey
import com.zydm.base.data.bean.ListBean
import com.zydm.base.data.net.*
import com.zydm.base.data.tools.DataUtils
import com.zydm.ebk.provider.data.bean.AdBean
import com.zydm.ebk.provider.data.bean.AdConfig

@BasePath("/Api/Ad/")
interface AdApi {

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getAdList(): DataSrcBuilder<ListBean<AdBean>>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getAdConfig(@Param(ParamKey.IDS) ids: String): DataSrcBuilder<ListBean<AdConfig>>

    fun freqCfg(): DataSrcBuilder<HashMap<String, Int>>
}