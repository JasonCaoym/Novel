package com.zydm.ebk.provider.ad

import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.ebk.provider.ad.ui.item.*

fun AdapterBuilder.putAdItemClass(): AdapterBuilder {
    return putItemClass(FeedGroupImgAdView::class.java)
            .putItemClass(FeedBigAdView::class.java)
            .putItemClass(BannerItemView::class.java)
            .putItemClass(FeedSmallAdView::class.java)
            .putItemClass(ListTopAdItemView::class.java)
            .putItemClass(AdListItemView::class.java)
}