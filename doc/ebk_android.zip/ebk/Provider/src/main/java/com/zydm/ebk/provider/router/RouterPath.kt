package com.zydm.ebk.provider.router

import com.zydm.base.common.ParamKey

/*
    模块路由 路径定义
 */
object RouterPath {

    const val KEY_BOOK_ID = ParamKey.BOOK_ID
    const val TARGET_SEQ_NUM = ParamKey.SEQ_NUM

    class Read {
        companion object {
            const val PATH_READ = "/read/read"
            const val PATH_DETAIL = "/read/detail"
        }
    }

    class GDTAd {
        companion object {
            const val PATH_AD_GDT_PLATFORM = "/gdt/ad"
        }
    }

    class TTAd {
        companion object {
            const val PATH_AD_TT_PLATFORM = "/tt/ad"
        }
    }

    class Book {
        companion object {
            const val PATH_SEARCH = "/book/search"
        }
    }


    class App {
        companion object {
            const val PATH_HOME = "/app/home"
        }
    }
}
