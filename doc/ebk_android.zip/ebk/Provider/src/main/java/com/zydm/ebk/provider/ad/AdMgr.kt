package com.zydm.ebk.provider.ad

import android.app.Activity
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.alibaba.android.arouter.launcher.ARouter
import com.zydm.base.common.BaseApplication
import com.zydm.base.common.BaseErrorCode
import com.zydm.base.common.Constants
import com.zydm.base.data.bean.ListBean
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.data.tools.JsonUtils
import com.zydm.base.ext.mapPacking
import com.zydm.base.rx.LoadException
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.utils.LogUtils
import com.zydm.base.utils.SPUtils
import com.zydm.base.utils.StringUtils
import com.zydm.base.utils.TimeUtils
import com.zydm.base.widgets.MTDialog
import com.zydm.ebk.provider.R
import com.zydm.ebk.provider.ad.ui.InteractionBigHolder
import com.zydm.ebk.provider.ad.ui.SingleBigHolder
import com.zydm.ebk.provider.ad.ui.SingleSmallHolder
import com.zydm.ebk.provider.ad.ui.ThreeHolder
import com.zydm.ebk.provider.ad.ui.item.*
import com.zydm.ebk.provider.data.CommonApi
import com.zydm.ebk.provider.data.bean.AdConfig
import com.zydm.ebk.provider.data.bean.AdConstants
import com.zydm.ebk.provider.router.RouterPath
import io.reactivex.Single
import io.reactivex.functions.BiFunction
import java.lang.NullPointerException
import java.util.*
import java.util.concurrent.TimeUnit


object AdMgr {

    private const val KEY_ALL_CONFIG = "AdMgr_AD_ALL_CONFIG"
    private const val KEY_INSTALL_TIME = "AdMgr_INSTALL_TIME"

    const val AD_SPLASH = 1 //启动页
    const val AD_BOOK_SHELF = 2//书架
    const val AD_SUB_LIST = 3//二级列表
    const val AD_DETAIL = 4//详情
    const val AD_READ_BOTTOM = 5//阅读页底部
    const val AD_READ_INTER_CUT = 6//阅读页插播
    const val AD_READ_SCREEN = 7//阅读页插屏
    const val AD_SUB_LIST_TOP = 9//二级列表顶部广告

    private const val TAG = "AdMgr"

    internal val mTTPlatform: IAdPlatform? by lazy {
        ARouter.getInstance().build(RouterPath.TTAd.PATH_AD_TT_PLATFORM).navigation() as IAdPlatform?
    }

    internal val mGDTPlatform: IAdPlatform? by lazy {
        ARouter.getInstance().build(RouterPath.GDTAd.PATH_AD_GDT_PLATFORM).navigation() as IAdPlatform?
    }

    private val mInstallTime: Long by lazy {
        var installTime = SPUtils.getLong(KEY_INSTALL_TIME, 0L)
        if (installTime == 0L) {
            installTime = System.currentTimeMillis()
            SPUtils.putLong(KEY_INSTALL_TIME, installTime)
        }
        installTime
    }
    private var mAppGoBackgroundTimestamp: Long = 0
    private var mToday: String = ""

    private var mAdConfig = HashMap<Int, AdParam>()
    private var mIsConfigLoaded = false

    fun clearCache() {
        nativeAdCache.clear()
    }

    fun initConfig() {
        val json = SPUtils.getString(KEY_ALL_CONFIG, "")
        LogUtils.d(TAG, "initConfig json: $json")

        if (!StringUtils.isBlank(json)) {
            val jsonData = JsonUtils.parseJson<JsonData>(json, JsonData::class.java)
            val today = TimeUtils.today()
            if (today == jsonData.today && jsonData.map.size > 0) {
                mToday = today
                mAdConfig = jsonData.map

                LogUtils.d(TAG, "initConfig mAdDefaultConfig: $mAdConfig")
                return
            }
        }

        loadConfig()
    }

    private fun loadConfig() {
        if (mIsConfigLoaded) {
            return
        }

        CommonApi.Ad().getAdList()
            .setCheckEmpty(true)
            .build()
            .flatMap { listBean ->
                val adList = listBean.list

                val idSet = HashSet<String>(adList.map { it.id })

                if (idSet.isEmpty()) {
                    throw LoadException(BaseErrorCode.DATA_EMPTY, "", "CommonApi.Ad().getAdList")
                }


                val configSingle = CommonApi.Ad().getAdConfig(JsonUtils.toJson(idSet)).build()
                val freqCfgSingle = CommonApi.Ad().freqCfg().build()
                    .onErrorReturnItem(HashMap())

                Single.zip(configSingle, freqCfgSingle, BiFunction<ListBean<AdConfig>, HashMap<String, Int>, Boolean> { configs, freqCfg ->
                    adList.forEach { ad ->
                        val config = configs.list.find { ad.id == it.id }
                        if (isValid(config, ad.pos)) {
                            val limit = if (ad.limit == 0) Int.MAX_VALUE else ad.limit
                            val freqCfg = freqCfg["${ad.pos}"] ?: 0
                            val minFreqCfg = if (ad.pos == AD_SUB_LIST) 5 else 3

                            val adParam = AdParam(config!!, ad.pos, limit, mAdSpace = Math.max(minFreqCfg, freqCfg), mNewUserDays = ad.enableDays)

                            mAdConfig[adParam.mAdPos] = adParam
                        } else {
                            LogUtils.d(TAG, "loadConfig invalid pos:${ad.pos} + config:$config")
                        }
                    }
                    mIsConfigLoaded = true
                    LogUtils.d(TAG, "loadConfig completed $mAdConfig")

                    mToday = TimeUtils.today()
                    saveConfig()
                    true
                })

            }
            .subscribe()
    }

    private fun isValid(config: AdConfig?, pos: Int): Boolean {
        if (config == null) {
            return false
        }

        if (config.source == AdConfig.SOURCE_CSJ) {
            val type = config.type
            return when (pos) {
                AD_SPLASH -> type == AdConfig.TYPE_LAUNCHING
                AD_READ_SCREEN -> type == AdConfig.TYPE_INSERT_SCREEN
                in arrayOf(
                    AD_SUB_LIST,
                    AD_DETAIL,
                    AD_READ_INTER_CUT,
                    AD_SUB_LIST_TOP,
                    AD_BOOK_SHELF,
                    AD_READ_BOTTOM
                ) -> {
                    type in arrayOf(AdConfig.TYPE_BANNER, AdConfig.TYPE_INFORMATION_FLOW)
                }
                else -> false
            }

        } else if (config.source == AdConfig.SOURCE_GDT) {
            val type = config.type
            return when (pos) {
                AD_SPLASH -> type == AdConfig.TYPE_LAUNCHING
                AD_READ_SCREEN -> type == AdConfig.TYPE_INSERT_SCREEN || config.isOriginal_()
                else -> config.isOriginal_()
            }
        }

        return false
    }

    fun saveConfig() {
        LogUtils.d(TAG, "saveConfig  $mAdConfig")
        SPUtils.putString(KEY_ALL_CONFIG, JsonUtils.toJson(JsonData(mToday, mAdConfig)))
    }

    fun initAdPlatform(activity: Activity) {
        mTTPlatform?.initPlatform(activity)
    }

    fun isShowAd(adPos: Int): Boolean {
        if (adPos < AD_SPLASH) {
            return false
        }

        val adParam = mAdConfig[adPos] ?: return false

        if (adParam.mLimit <= 0) {
            LogUtils.d(TAG, "isShowAd limit == 0  pos:$adPos")
            return false
        }


        val danWei: Int = if (BaseApplication.context.isTestEnv()) Constants.MINUTE_1 else Constants.DAY_1.toInt()
        var newUserDaY = danWei * adParam.mNewUserDays

        if (adPos == AD_SPLASH && newUserDaY <= 0) {
            newUserDaY = Constants.SECOND_10
        }

        if (System.currentTimeMillis() - mInstallTime < newUserDaY) {
            LogUtils.d(TAG, "isShowAd is newUser == ${adParam.mNewUserDays}  pos:$adPos")
            return false
        }

        if (adPos == AD_SPLASH) {
            val cooling = if (BaseApplication.context.isTestEnv()) 5000 else 90000
            if (SystemClock.elapsedRealtime() < mAppGoBackgroundTimestamp + cooling) {
                return false
            }
        }

        return true
    }

    fun onAppGoBackground() {
        LogUtils.d(TAG, "onAppGoBackground")
        mAppGoBackgroundTimestamp = SystemClock.elapsedRealtime()
    }

    fun createAdHelper(activity: Activity): IAdHelper {
        val adHelper = AdHelperAdapter(activity)
        adHelper.addListener(mAdListener)
        return adHelper
    }

    fun getAdParam(adPos: Int, from: String = "none"): AdParam {
        return mAdConfig[adPos]!!.copy(mFrom = from)
    }

    private val mAdListener = object : ADListener {
        override fun onAdShow(param: AdParam) {
            super.onAdShow(param)

            val adPos = param.mAdPos
            val adParamSrc = mAdConfig[adPos]!!
            adParamSrc.mLimit--
            LogUtils.d(TAG, "onAdShow: adPos:$adPos limit--  $adParamSrc")

            when (adPos) {
                AD_SPLASH -> StatisHelper.onEvent().openAd()
                AD_SUB_LIST -> StatisHelper.onEvent().listAdExposure(param.mFrom)
                AD_DETAIL -> StatisHelper.onEvent().detailAdExposure()
                AD_READ_BOTTOM -> StatisHelper.onEvent().readAdExposure()
                AD_READ_INTER_CUT -> StatisHelper.onEvent().readBottomAdExposure()
                AD_BOOK_SHELF -> StatisHelper.onEvent().bookshelfAdExposure()
                AD_READ_SCREEN -> StatisHelper.onEvent().screenAd()
                AD_SUB_LIST_TOP -> StatisHelper.onEvent().listTopAdExposure()
            }
        }

        override fun onAdClicked(param: AdParam, from: String) {
            super.onAdClicked(param, from)
            when (param.mAdPos) {
                AD_SPLASH -> StatisHelper.onEvent().openAdClick()
                AD_SUB_LIST -> StatisHelper.onEvent().listAdClick(param.mFrom)
                AD_DETAIL -> StatisHelper.onEvent().detailAdClick()
                AD_READ_BOTTOM -> StatisHelper.onEvent().readAdClick()
                AD_READ_INTER_CUT -> StatisHelper.onEvent().readBottomAdClick()
                AD_BOOK_SHELF -> StatisHelper.onEvent().bookshelfAdClick()
                AD_READ_SCREEN -> StatisHelper.onEvent().screenAdClick()
                AD_SUB_LIST_TOP -> StatisHelper.onEvent().listTopAdClick()
            }
        }

        override fun onAdDismiss(param: AdParam, reason: String) {
            super.onAdDismiss(param, reason)
            when {
                param.mAdPos == AD_SPLASH && "skip" == reason -> StatisHelper.onEvent().openAdSkip()
            }
        }
    }

    fun loadInteractionAd(adHelper: IAdHelper, adParam: AdParam, activity: Activity) {
        if (adParam.mConfig.isOriginal_()) {
            val dialog = MTDialog(activity)

            dialog.setCanceledOnTouchOutside(false)
            dialog.setCancelable(false)
            adHelper.loadNativeAd(adParam, object : NativeAdCallback {
                override fun callback(ad: NativeAd) {
                    LogUtils.d(TAG, "show loadInteractionAd $ad")
                    if (activity.isFinishing()) {
                        ad.destroy()
                        return
                    }
                    val layout = FrameLayout(activity)
                    dialog.setContentView(layout)
                    InteractionBigHolder(ad, layout, activity).setData {
                        dialog.cancel()
                    }

                    dialog.setOnDismissListener {
                        ad.destroy()
                    }

                    dialog.show()
                    dialog.findViewById(R.id.dialog_parent_layout)?.background = null
                }
            })

            adHelper.addListener(object : ADListener {
                override fun onAdClicked(param: AdParam, from: String) {
                    super.onAdClicked(param, from)
                    dialog.dismiss()
                }
            })
        } else {
            adHelper.loadInteractionAd(adParam)
        }
    }

    fun loadAdList(activity: Activity, adPos: Int, count: Int, from: String, adHelper: IAdHelper? = null): Single<ArrayList<Any>> {
        var helper = adHelper
        if (helper == null) {
            helper = createAdHelper(activity)
        }
        val adParam = getAdParam(adPos, from)
        if (adParam.mConfig.isOriginal_()) {
            adParam.mCount = count
            return Single.fromObservable<ArrayList<Any>> {
                helper.loadNativeAd(adParam, object : NativeAdCallback {
                    override fun callback(ads: ArrayList<NativeAd>?) {
                        val list = ArrayList<Any>()
                        if (DataUtils.isEmptyList(ads)) {
                            it.onError(NullPointerException())
                            return
                        }
                        ads!!.forEach { ad ->
                            val adData = when (ad.getImageMode()) {
                                AdConstants.IMG_BIG -> FeedBigImgAD(ad)
                                AdConstants.IMG_SMALL -> FeedSmallImgAD(ad)
                                AdConstants.IMG_GROUP -> FeedGroupImgAD(ad)
                                AdConstants.IMG_VIEW -> FeedViewAD(ad)
                                else -> null
                            }
                            if (adData != null) {
                                list.add(adData)
                            }
                        }

                        it.onNext(list)
                        it.onComplete()
                    }
                })
            }.timeout(8, TimeUnit.SECONDS)
        } else {
            var listSingle = Single.just(ArrayList<Any>())
            for (i in 0 until count) {
                val adSingle = Single.fromObservable<BannerADItemData> {
                    helper.loadBannerAd(adParam, object : LoadBannerAdListener {
                        override fun onLoadBanner(bannerADView: View?) {
                            if (bannerADView == null) {
                                it.onError(NullPointerException())
                                return
                            }
                            it.onNext(BannerADItemData(adParam, bannerADView))
                            it.onComplete()
                        }
                    })
                }.mapPacking()

                listSingle = Single.zip(listSingle, adSingle, BiFunction { t1, t2 ->
                    if (t2.data != null) {
                        t1.add(t2.data!!)
                    }
                    t1
                })
            }
            return listSingle.timeout(8, TimeUnit.SECONDS)
        }
    }
}

data class JsonData(var today: String, val map: HashMap<Int, AdParam>) {
    constructor() : this("", HashMap())
}

val nativeAdCache: HashMap<Int, LinkedList<NativeAd>> = HashMap()
fun IAdHelper.loadAdWhitContainer(
        adParam: AdParam,
        containerView: ViewGroup,
        activity: Activity,
        listener: OnAdLoadedListener? = null ) {

    if (adParam.mConfig.isOriginal_()) {
        adParam.mCount = 3
        val hashCode = activity.hashCode()
        var cache = nativeAdCache[hashCode]
        if (cache == null || cache.size == 0) {
            nativeAdCache.clear()
            cache = LinkedList()
            nativeAdCache[hashCode] = cache
            loadNativeAd(adParam, object : NativeAdCallback {
                override fun callback(ads: ArrayList<NativeAd>?) {
                    super.callback(ads)
                    if (ads != null && ads.size != 0) {
                        setAd(ads.removeAt(0), containerView, activity, listener)
                        cache.addAll(ads)
                    }
                }
            })
        } else {
            val nativeAd = cache.poll()
            setAd(nativeAd, containerView, activity, listener)
            if (cache.size == 0) {
                loadNativeAd(adParam, object : NativeAdCallback {
                    override fun callback(ads: ArrayList<NativeAd>?) {
                        super.callback(ads)
                        val newCache = LinkedList<NativeAd>()
                        if (ads != null && ads.size != 0) {
                            newCache.addAll(ads)
                        }
                        nativeAdCache[hashCode] = newCache
                    }
                })
            }
        }
    } else {
        loadBannerAd(adParam, containerView)
    }
}

fun setAd(ad: NativeAd, containerView: ViewGroup, activity: Activity, listener: OnAdLoadedListener?) {
    containerView.destroyAd()
    containerView.removeAllViews()
    LogUtils.d("setAd ", "containerView:hash=${containerView.hashCode()} + childCount:${containerView.getChildAt(0)}")
    when (ad.getImageMode()) {
        AdConstants.IMG_BIG -> SingleBigHolder(ad, containerView, activity).setData()
        AdConstants.IMG_SMALL -> SingleSmallHolder(ad, containerView, activity).setData()
        AdConstants.IMG_GROUP -> ThreeHolder(ad, containerView, activity).setData()
        AdConstants.IMG_VIEW -> {
            val adView = ad.getAdView()!!
            if (containerView.getChildCount() > 0 && containerView.getChildAt(0) === adView) {
                return
            }

            if (containerView.getChildCount() > 0) {
                containerView.destroyAd()

                containerView.removeAllViews()
            }

            if (adView.getParent() != null) {
                (adView.getParent() as ViewGroup).removeView(adView)
            }

            containerView.addView(adView)
            ad.render() // 调用render方法后sdk才会开始展示广告
        }
    }
    listener?.onAdLoad(ad.getImageMode())
}

interface OnAdLoadedListener {
    fun onAdLoad(imageMode: Int)
}