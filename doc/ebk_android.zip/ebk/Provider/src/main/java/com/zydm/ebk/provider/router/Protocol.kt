package com.zydm.ebk.provider.router

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BaseData(val from: String): Parcelable

