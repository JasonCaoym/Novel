package com.zydm.ebk.provider.ad

import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup

interface NativeAd {

    fun getAdParam(): AdParam

    fun getAdLogo(): Bitmap?

    fun getTitle(): String

    fun getDescription(): String

    fun getSource(): String

    fun getIcon(): String

    fun getImageList(): List<String>

    fun getInteractionType(): Int

    fun getImageMode(): Int

    fun registerViewForInteraction(var1: ViewGroup, clickView: View, creativeView: View)

    fun registerViewForInteraction(var1: ViewGroup, var2: List<View>, var3: List<View>)

    fun getAdView(): View?

    fun render()

    fun destroy()
}

interface NativeAdCallback {
    fun callback(ad: NativeAd) {

    }

    fun callback(ads: ArrayList<NativeAd>?) {
    }
}