package com.zydm.ebk.provider.data.bean

import android.graphics.Bitmap

class SingleSmallAdBean {

    var title: String = ""
    var imgUrl: String = ""
    var resume: String = ""
    var brandIcon: Bitmap? = null
    var type: Int = 0
}