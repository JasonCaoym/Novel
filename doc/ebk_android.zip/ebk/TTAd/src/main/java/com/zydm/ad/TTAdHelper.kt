package com.zydm.ad

import android.app.Activity
import android.graphics.Bitmap
import android.os.Handler
import android.view.View
import android.view.ViewGroup
import com.androidquery.callback.AQuery2
import com.bytedance.sdk.openadsdk.*
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.utils.LogUtils
import com.zydm.base.utils.ToastUtils
import com.zydm.ebk.provider.ad.*
import com.zydm.ebk.provider.data.bean.AdConfig


class TTAdHelper(private val mTTAdNative: TTAdNative, private val mActivity: Activity) : IAdHelper {

    private val TAG = "TTAdHelper"

    private val mListenerSet = HashSet<ADListener>()
    private val mAQuery by lazy {
        AQuery2(mActivity);
    }

    override fun addListener(adListener: ADListener) {
        mListenerSet.add(adListener)
    }

    override fun removeListener(adListener: ADListener) {
        mListenerSet.remove(adListener)
    }

    override fun loadBannerAd(adParam: AdParam, loadBannerAdListener: LoadBannerAdListener) {
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(adParam.mConfig.width, adParam.mConfig.height)
            .build()

        mTTAdNative.loadBannerAd(adSlot, object : TTAdNative.BannerAdListener {
            override fun onBannerAdLoad(ad: TTBannerAd) {
                LogUtils.d(TAG, "loadBannerAd $ad")
//                if (adParam.mIsAutoChange) {
//                    ad.setSlideIntervalTime(30 * 1000)
//                }
                val bannerView = ad.getBannerView()

                if (bannerView == null) {
                    loadBannerAdListener.onLoadBanner(null)
                    onAdError(adParam, -100, "ad is null")
                    return
                }

                loadBannerAdListener.onLoadBanner(bannerView)

                ad.setBannerInteractionListener(object : TTBannerAd.AdInteractionListener {
                    override fun onAdClicked(view: View, type: Int) {
                        onAdClicked(adParam)
                    }

                    override fun onAdShow(view: View, type: Int) {
                        onAdShow(adParam)
                    }
                })

            }

            override fun onError(code: Int, message: String?) {
                onAdError(adParam, code, message)
                loadBannerAdListener.onLoadBanner(null)
            }

        })
    }

    override fun loadBannerAd(adParam: AdParam, containerView: ViewGroup) {
        containerView.removeAllViews()
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(adParam.mConfig.width, adParam.mConfig.height)
            .build()

        mTTAdNative.loadBannerAd(adSlot, object : TTAdNative.BannerAdListener {
            override fun onBannerAdLoad(ad: TTBannerAd) {
                LogUtils.d(TAG, "loadBannerAd $ad")
//                if (adParam.mIsAutoChange) {
//                    ad.setSlideIntervalTime(30 * 1000)
//                }
                val bannerView = ad.getBannerView()

                if (bannerView == null) {
                    onAdError(adParam, -100, "ad is null")
                    return
                }

                containerView.removeAllViews()
                containerView.addView(bannerView)

                ad.setBannerInteractionListener(object : TTBannerAd.AdInteractionListener {
                    override fun onAdClicked(view: View, type: Int) {
                        onAdClicked(adParam)
                    }

                    override fun onAdShow(view: View, type: Int) {
                        onAdShow(adParam)
                    }
                })


                ad.setShowDislikeIcon(object : TTAdDislike.DislikeInteractionCallback {
                    override fun onSelected(position: Int, value: String) {
//                        ToastUtils.show("点击 $value")
                        this@TTAdHelper.loadBannerAd(adParam, containerView)
//                        TToast.show(mContext, "点击 $value")
//                        //用户选择不喜欢原因后，移除广告展示
//                        mBannerContainer.removeAllViews()
                    }

                    override fun onCancel() {
//                        ToastUtils.show("点击取消")
                    }
                })
            }

            override fun onError(code: Int, message: String?) {
                onAdError(adParam, code, message)
            }

        })
    }

    private var mHasLoaded = false

    private val mHandler = Handler()
    override fun loadSplashAd(adParam: AdParam, containerView: ViewGroup) {
        var width = adParam.mConfig.width
        var height = adParam.mConfig.height
        if (width <= 0 || height <= 0) {
            width = 1080
            height = 1920
        }
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(width, height)
            .build()

        mTTAdNative.loadSplashAd(adSlot, object : TTAdNative.SplashAdListener {
            override fun onError(p0: Int, message: String) {
                mHasLoaded = true;
                showToast(message);
                onAdError(adParam, p0, message)
            }

            override fun onTimeout() {
                mHasLoaded = true;
                onAdError(adParam, -100, "timeout")
            }

            override fun onSplashAdLoad(ad: TTSplashAd?) {
                mHasLoaded = true
                mHandler.removeCallbacksAndMessages(null)
                if (ad == null) {
                    onAdError(adParam, -101, "ad is null")
                    return
                }
                //获取SplashView
                val view = ad.getSplashView()

                containerView.removeAllViews()
                //把SplashView 添加到ViewGroup中
                containerView.addView(view)
                //设置SplashView的交互监听器
                ad.setSplashInteractionListener(object : TTSplashAd.AdInteractionListener {
                    override fun onAdClicked(view: View, type: Int) {
//                        Log.d(FragmentActivity.TAG, "onAdClicked")
                        onAdClicked(adParam)
                    }

                    override fun onAdShow(view: View, type: Int) {
//                        Log.d(FragmentActivity.TAG, "onAdShow")
                        onAdShow(adParam)
                    }

                    override fun onAdSkip() {
//                        Log.d(FragmentActivity.TAG, "onAdSkip")
                        onAdDismiss(adParam, "skip")

                    }

                    override fun onAdTimeOver() {
//                        Log.d(FragmentActivity.TAG, "onAdTimeOver")
                        onAdDismiss(adParam, "time over")
                    }
                })
            }
        }, 5000)
    }

    override fun loadInteractionAd(adParam: AdParam) {
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(adParam.mConfig.width, adParam.mConfig.height)
            .build()
        mTTAdNative.loadInteractionAd(adSlot, object : TTAdNative.InteractionAdListener {
            override fun onError(code: Int, message: String?) {
                onAdError(adParam, code, message)
            }

            override fun onInteractionAdLoad(ttInteractionAd: TTInteractionAd) {

                ttInteractionAd.setAdInteractionListener(object : TTInteractionAd.AdInteractionListener {
                    override fun onAdClicked() {
//                        Log.d(FragmentActivity.TAG, "被点击")
                        onAdClicked(adParam)
                    }

                    override fun onAdShow() {
//                        Log.d(FragmentActivity.TAG, "被展示")
                        onAdShow(adParam)
                    }

                    override fun onAdDismiss() {
//                        Log.d(FragmentActivity.TAG, "插屏广告消失")
                        onAdDismiss(adParam, "user cancel")
                    }
                })

                //弹出插屏广告
                if (mActivity.isFinishing) {
                    return
                }
                ttInteractionAd.showInteractionAd(mActivity)
            }
        })
    }

    override fun loadNativeAd(adParam: AdParam, callback: NativeAdCallback) {
        if (adParam.mConfig.type == AdConfig.TYPE_BANNER) {
            loadNativeBanner(adParam, callback)
        } else if (adParam.mConfig.type == AdConfig.TYPE_INFORMATION_FLOW) {
            loadFeedAd(adParam, callback)
        } else if (adParam.mConfig.type == AdConfig.TYPE_INSERT_SCREEN) {
            loadNativeInteractionAd(adParam, callback)
        }
    }

    private fun loadFeedAd(adParam: AdParam, callback: NativeAdCallback) {
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(640, 320)
            .setAdCount(adParam.mCount) //请求广告数量为1到3条
            .build()

        mTTAdNative.loadFeedAd(adSlot, object : TTAdNative.FeedAdListener {
            override fun onError(code: Int, message: String) {
                onAdError(adParam, code, message)
                callback.callback(null)
            }

            override fun onFeedAdLoad(ads: List<TTFeedAd>?) {
                if (DataUtils.isEmptyData(ads)) {
                    onAdError(adParam, -100, "ad is null")
                    callback.callback(null)
                    return
                }

                LogUtils.d(TAG, "ads.size: ${ads?.size}")
                val list = ArrayList<NativeAd>()
                ads!!.forEach {
                    list.add(transform(adParam, it))
                    LogUtils.d(TAG, "ad imageMode: ${it.imageMode}")
                }
                callback.callback(list)
                callback.callback(list[0])
            }
        })

    }

    private fun loadNativeBanner(adParam: AdParam, callback: NativeAdCallback) {
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(640, 320)
            .setNativeAdType(AdSlot.TYPE_BANNER) //请求原生广告时候，请务必调用该方法，设置参数为TYPE_BANNER或TYPE_INTERACTION_AD
            .setAdCount(adParam.mCount)
            .build()

        mTTAdNative.loadNativeAd(adSlot, object : TTAdNative.NativeAdListener {
            override fun onError(code: Int, message: String) {
                onAdError(adParam, code, message)
                callback.callback(null)
            }

            override fun onNativeAdLoad(ads: List<TTNativeAd>) {
                if (DataUtils.isEmptyData(ads)) {
                    onAdError(adParam, -100, "ad is null")
                    callback.callback(null)
                    return
                }

                val list = ArrayList<NativeAd>()
                ads.forEach {
                    list.add(transform(adParam, it))
                }

                callback.callback(list)
                callback.callback(list[0])
            }
        })
    }

    private fun loadNativeInteractionAd(adParam: AdParam, callback: NativeAdCallback) {
        val adSlot = AdSlot.Builder()
            .setCodeId(adParam.mConfig.slotId)
            .setSupportDeepLink(true)
            .setImageAcceptedSize(1080, 1920)
            .setNativeAdType(AdSlot.TYPE_INTERACTION_AD)//请求原生广告时候，请务必调用该方法，设置参数为TYPE_BANNER或TYPE_INTERACTION_AD
            .build()

        mTTAdNative.loadNativeAd(adSlot, object : TTAdNative.NativeAdListener {
            override fun onError(code: Int, message: String) {
                onAdError(adParam, code, message)
                callback.callback(null)
            }

            override fun onNativeAdLoad(ads: List<TTNativeAd>) {
                if (DataUtils.isEmptyData(ads)) {
                    onAdError(adParam, -100, "ad is null")
                    callback.callback(null)
                    return
                }
                val list = ArrayList<NativeAd>()
                ads.forEach {
                    list.add(transform(adParam, it))
                }

                callback.callback(list)
                callback.callback(list[0])
            }
        })
    }

    private fun transform(adParam: AdParam, nativeAd: TTNativeAd): NativeAd {

        val listener = object : TTNativeAd.AdInteractionListener {
            override fun onAdClicked(view: View, ad: TTNativeAd?) {
                if (ad != null) {
                    onAdClicked(adParam, "")
                }
            }

            override fun onAdCreativeClick(view: View, ad: TTNativeAd?) {
                if (ad != null) {
                    onAdClicked(adParam, "CreativeClick")
                }
            }

            override fun onAdShow(ad: TTNativeAd?) {
                if (ad != null) {
                    onAdShow(adParam)
                }
            }
        }

        return object : NativeAd {

            override fun getAdParam(): AdParam {
                return adParam
            }

            override fun getAdLogo(): Bitmap? {
                return nativeAd.adLogo
            }

            override fun getSource(): String {
                return nativeAd.source
            }

            override fun getTitle(): String {
                return nativeAd.title
            }

            override fun getDescription(): String {
                return nativeAd.description
            }

            override fun getIcon(): String {
                return nativeAd.icon?.imageUrl ?: ""
            }

            override fun getImageList(): List<String> {
                if (nativeAd.imageList == null) {
                    return ArrayList<String>()
                }
                return nativeAd.imageList.map { it.imageUrl }
            }

            override fun getInteractionType(): Int {
                return nativeAd.interactionType
            }

            override fun getImageMode(): Int {
                return nativeAd.imageMode
            }

            override fun registerViewForInteraction(var1: ViewGroup, clickView: View, creativeView: View) {
                val list = ArrayList<View>()
                list.add(clickView)
                val list2 = ArrayList<View>()
                list2.add(creativeView)
                registerViewForInteraction(var1, list, list2)
            }

            override fun registerViewForInteraction(var1: ViewGroup, var2: List<View>, var3: List<View>) {
                nativeAd.registerViewForInteraction(var1, var2, var3, listener)
            }

            override fun getAdView(): View {
                return nativeAd.adView
            }

            override fun render() {

            }

            override fun destroy() {

            }
        }
    }

    private fun showToast(message: String) {
        ToastUtils.show(message)
    }

    private fun onAdShow(adParam: AdParam) {
        LogUtils.d(TAG, "onAdShow  adParam $adParam")
        mListenerSet.forEach {
            it.onAdShow(adParam)
        }
    }

    private fun onAdClicked(adParam: AdParam, from: String = "") {
        LogUtils.d(TAG, "onAdClicked  adParam $adParam")
        mListenerSet.forEach {
            it.onAdClicked(adParam, from)
        }
    }

    private fun onAdDismiss(adParam: AdParam, reason: String) {
        LogUtils.d(TAG, "onAdDismiss  adParam $adParam")
        mListenerSet.forEach {
            it.onAdDismiss(adParam, reason)
        }
    }

    private fun onAdError(adParam: AdParam, code: Int, msg: String?) {
        LogUtils.d(TAG, "onAdError  adParam $adParam")
        mListenerSet.forEach {
            it.onAdError(adParam, code, msg ?: "")
        }
    }
}