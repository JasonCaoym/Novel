package com.zydm.ad

import android.app.Activity
import android.content.Context
import com.alibaba.android.arouter.facade.annotation.Route
import com.bytedance.sdk.openadsdk.TTAdManager
import com.bytedance.sdk.openadsdk.TTAdManagerFactory
import com.zydm.ebk.provider.ad.IAdHelper
import com.zydm.ebk.provider.ad.IAdPlatform
import com.zydm.ebk.provider.router.RouterPath

@Route(path = RouterPath.TTAd.PATH_AD_TT_PLATFORM)
class TTPlatform: IAdPlatform {
    private var mTtAdManager: TTAdManager? = null

    override fun init(context: Context) {
    }

    override fun initPlatform(activity: Activity) {
        if (mTtAdManager != null) {
            mTtAdManager?.requestPermissionIfNecessary(activity)
            return
        }
        mTtAdManager = TTAdManagerFactory.getInstance(activity.application)
        mTtAdManager?.setAppId("5005175")
        mTtAdManager?.setName("蜜之看书")

        mTtAdManager?.requestPermissionIfNecessary(activity)
    }

    override fun createHelper(activity: Activity): IAdHelper {
        if (mTtAdManager == null) {
            initPlatform(activity)
        }
        return TTAdHelper(mTtAdManager!!.createAdNative(activity), activity)
    }
}