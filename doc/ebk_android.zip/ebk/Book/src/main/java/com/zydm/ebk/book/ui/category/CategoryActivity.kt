package com.zydm.ebk.book.ui.category

import android.os.Bundle
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.ebk.book.R

class CategoryActivity: BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.empty_activity)

        var fragment = supportFragmentManager
                .findFragmentById(R.id.content_frame)

        if (fragment !is CategoryFragment) {
            fragment = CategoryFragment()
            val transaction = supportFragmentManager.beginTransaction()
            transaction.add(R.id.content_frame, fragment)
            transaction.commit()
        }
    }

    override fun initActivityConfig(activityConfig: ActivityConfig) {
        super.initActivityConfig(activityConfig)
        activityConfig.isStPage = false
    }
}