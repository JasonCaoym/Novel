package com.zydm.ebk.book.ui.category

import android.content.Context
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.MotionEvent
import com.zydm.base.utils.LogUtils

class MyViewPager: ViewPager {

    private val TAG = "MyViewPager"

    var mOnDispatchTouchDownEventListener: OnDispatchTouchDownEventListener? = null

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)

    private var x = 0
    private var y = 0

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when(ev.action) {
            MotionEvent.ACTION_DOWN -> {
                x = ev.getX().toInt()
                y = ev.getY().toInt()
                LogUtils.d(TAG, "ACTION_DOWN x: $x  y: $y")
            }
            MotionEvent.ACTION_UP -> {
                val xUp = ev.getX().toInt()
                val  yUp = ev.getY().toInt()
                LogUtils.d(TAG, "ACTION_UP x: $x  y: $y")
                if (yUp < y && Math.abs(xUp - x) < Math.abs(yUp - y)) {
                    mOnDispatchTouchDownEventListener?.onDownEvent()
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    interface OnDispatchTouchDownEventListener {
        fun onDownEvent()
    }
}