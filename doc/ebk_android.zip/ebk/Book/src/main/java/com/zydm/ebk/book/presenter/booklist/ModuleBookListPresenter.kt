package com.zydm.ebk.book.presenter.booklist

import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.presenter.booklist.base.AbsBookListPresenter
import com.zydm.ebk.book.presenter.view.IBookListPage
import com.zydm.base.common.ParamKey
import io.reactivex.Single

class ModuleBookListPresenter(val mPage: IBookListPage, val mModuleId: String) : AbsBookListPresenter(mPage) {

    override fun getListDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<BookListBean> {
        return Api.Recommend().booksByModuleId(mModuleId)
                .addReqParam(ParamKey.CURSOR, getCursor(isLoadMore))
                .setForceUpdate(isForceUpdate)
                .build()
    }
}