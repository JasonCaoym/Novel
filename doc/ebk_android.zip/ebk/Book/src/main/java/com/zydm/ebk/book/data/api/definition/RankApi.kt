package com.zydm.ebk.book.data.api.definition

import com.zydm.base.common.ParamKey
import com.zydm.base.data.net.*
import com.zydm.ebk.book.data.bean.BookListBean

/**
 * Created by yan on 2017/3/17.
 */
@BasePath("/Api/Rank/")
interface RankApi {

    companion object {
        const val TYPE_HOT = 1
        const val TYPE_FINISH = 2
    }

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun weekHot(@Param(ParamKey.TYPE) type: Int): DataSrcBuilder<BookListBean>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun weekRise(): DataSrcBuilder<BookListBean>
}
