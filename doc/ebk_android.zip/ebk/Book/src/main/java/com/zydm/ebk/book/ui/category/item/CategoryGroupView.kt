package com.zydm.ebk.book.ui.category.item

import android.graphics.Color
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.presenter.CategoryGroup
import kotlinx.android.synthetic.main.category_group_layout.view.*

class CategoryGroupView : AbsItemView<CategoryGroup>() {
    override fun onCreate() {
        setContentView(R.layout.category_group_layout)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        val groupText = mItemView.group_name
        groupText.isActivated = mItemData.isBoy

        if (mItemData.isBoy) {
            groupText.setText(R.string.category_boy)
            groupText.setTextColor(Color.parseColor("#5A88FF"))
        } else {
            groupText.setText(R.string.category_girl)
            groupText.setTextColor(Color.parseColor("#F6274F"))

        }
    }
}
