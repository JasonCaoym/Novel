package com.zydm.ebk.book.ui.list

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.util.TypedValue
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.utils.ViewUtils
import com.zydm.base.widgets.AbsFragmentPagerAdapter
import com.zydm.ebk.book.R
import com.zydm.ebk.book.data.bean.FixedModuleBean
import com.zydm.ebk.book.presenter.booklist.base.FixedModuleArgs
import kotlinx.android.synthetic.main.selected_tab_activity.*
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView

class SelectedActivity: BaseActivity() {

    private val mTabTitle = arrayOf(R.string.selected_boy, R.string.selected_girl)
    private val mDataId = arrayOf(FixedModuleBean.ID_MALE, FixedModuleBean.ID_FEMALE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.selected_tab_activity)
        initTab()
        initViewPager()
    }

    private fun initTab() {
        val commonNavigator = CommonNavigator(this)
        commonNavigator.adapter = object : CommonNavigatorAdapter() {

            override fun getCount(): Int {
                return mTabTitle.size
            }

            override fun getTitleView(p0: Context?, index: Int): IPagerTitleView {
                val titleView = SimplePagerTitleView(this@SelectedActivity)
                titleView.normalColor = ViewUtils.getColor(R.color.standard_text_color_black)
                titleView.setPadding(ViewUtils.dp2px(18f), 0, ViewUtils.dp2px(18f), 0)
                titleView.selectedColor = ViewUtils.getColor(R.color.standard_text_color_red)
                titleView.setText(mTabTitle[index])
                titleView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f)
                titleView.setOnClickListener{
                    view_pager.currentItem = index
                }
                return titleView
            }

            override fun getIndicator(p0: Context?): IPagerIndicator? {
                return null
            }
        }
        magic_indicator.navigator = commonNavigator
    }

    private fun initViewPager() {
        view_pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(state: Int) {
                magic_indicator.onPageScrollStateChanged(state)
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                magic_indicator.onPageScrolled(position, positionOffset, positionOffsetPixels)
            }

            override fun onPageSelected(position: Int) {
                magic_indicator.onPageSelected(position)
            }
        })

        view_pager.adapter = object : AbsFragmentPagerAdapter(supportFragmentManager, mTabTitle.size) {
            override fun getItem(position: Int): Fragment {
                val listFragment = BookListFragment()
                listFragment.setArgs(FixedModuleArgs(ViewUtils.getString(mTabTitle[position]), mDataId[position]))
                return listFragment
            }

        }
    }

    override fun initActivityConfig(activityConfig: ActivityConfig) {
        super.initActivityConfig(activityConfig)
        activityConfig.isStPage = false
    }
}