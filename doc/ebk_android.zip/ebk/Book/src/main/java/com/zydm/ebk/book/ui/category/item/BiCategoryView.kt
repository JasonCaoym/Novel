package com.zydm.ebk.book.ui.category.item

import android.view.View
import android.widget.TextView
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.data.bean.CategoryBean
import kotlinx.android.synthetic.main.category_item.view.*

class BiCategoryView: AbsItemView<ArrayList<CategoryBean>>() {

    private val ids = arrayOf(R.id.category_1, R.id.category_2)

    override fun onCreate() {
        setContentView(R.layout.category_2_layout)
        ids.forEachIndexed { index, i ->
            val view = mItemView.findViewById<View>(i)
            view.setOnClickListener(this)
            view.setTag(index)
        }
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        ids.forEachIndexed { index, i ->
            val view = mItemView.findViewById<View>(i)
            val subCategoryLayout = view.sub_category_layout

            if (index < mItemData.size) {
                view.isEnabled = true
                view.name.visibility = View.VISIBLE
                view.icon.visibility = View.VISIBLE
                subCategoryLayout.visibility = View.VISIBLE

                val categoryBean = mItemData[index]
                view.name.text = categoryBean.name
                for (j in 0 until subCategoryLayout.childCount) {
                    val subText = subCategoryLayout.getChildAt(j) as TextView
                    val sub = DataUtils.getItem(categoryBean.subList, j)
                    if (sub != null) {
                        subText.text = sub.name
                    } else {
                        subText.text = ""
                    }
                }
            } else {
                view.isEnabled = false
                view.name.visibility = View.GONE
                view.icon.visibility = View.GONE
                subCategoryLayout.visibility = View.GONE
            }
        }

    }

    override fun onClick(view: View) {
        super.onClick(view)
        val categoryBean = mItemData[view.tag as Int]

        StatisHelper.onEvent().classifyClick(categoryBean.name)

        ActivityHelper.gotoCategoryBookList(mActivity, categoryBean)
    }

}
