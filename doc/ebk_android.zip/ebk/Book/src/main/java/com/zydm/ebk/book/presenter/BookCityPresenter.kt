package com.zydm.ebk.book.presenter

import com.zydm.base.common.ParamKey
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.bean.BookItemBean
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.data.bean.ModuleBean
import com.zydm.ebk.book.presenter.view.IBookCityPage
import io.reactivex.Single
import io.reactivex.functions.BiFunction

class BookCityPresenter(val mPage: IBookCityPage) : AbsPagePresenter<ArrayList<*>>(mPage) {

    override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<ArrayList<*>> {
        val bannerSingle = Api.Banner().getList()
                .setForceUpdate(isForceUpdate)
                .build()

//        val ids = JsonUtils.getJsonArrayStr(FixedModuleBean.ID_POPULAR, FixedModuleBean.ID_NEW, FixedModuleBean.ID_GREAT)
//        val fixedModulesSingle = Api.Recommend().choiceness(ids)
//                .setForceUpdate(isForceUpdate)
//                .build()

        val recommendSingle = getRecommendSingle(isForceUpdate)

        return Single.zip(bannerSingle, recommendSingle, BiFunction { t1, t3 ->
            val list = ArrayList<Any>()
            list.add(t1)
            list.add(EntrancesData())
//            list.add(t2)
            list.addAll(t3)
            list
        })
    }

    private fun getRecommendSingle(isForceUpdate: Boolean): Single<ArrayList<*>> {

        data class ModuleBooks(val module: ModuleBean, var books: ArrayList<BookItemBean>? = null)

        return Api.Recommend().getModules()
                .setForceUpdate(isForceUpdate)
                .build()
                .map { it.map { item -> ModuleBooks(item) } }
                .flatMap { it ->
                    var resultSingle = Single.just(it)

                    for (module in it) {
                        val bookSingle = Api.Recommend().booksByModuleId(module.module.moduleId)
                                .setForceUpdate(isForceUpdate)
                                .addReqParam(ParamKey.COUNT, "${module.module.itemCount()}")
                                .build()
                                .onErrorReturnItem(BookListBean())

                        resultSingle = resultSingle.zipWith(bookSingle, BiFunction { t1, t2 ->
                            module.books = t2.list
                            t1
                        })
                    }
                    resultSingle

                }.map {
                    val list = ArrayList<Any>()
                    it.forEachIndexed { index, moduleBooks ->
                        if (DataUtils.isEmptyList(moduleBooks.books)) {
                            return@forEachIndexed
                        }

                        moduleBooks.module.mIsFirst = index == 0

                        list.add(moduleBooks.module)
                        val books = moduleBooks.books!!
                        if (moduleBooks.module.isVerticalStyle()) {
                            list.addAll(books)
                        } else {
                            list.add(books)
                        }

                        books.forEachIndexed { j, book ->
                            book.mRecommendStStr = "${moduleBooks.module.name}_${index+1}_${j+1}"
                        }
                    }
                    list
                }
    }

    override fun onPageDataUpdated(pageData: ArrayList<*>, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        mPage.showPage(pageData)
    }
}

