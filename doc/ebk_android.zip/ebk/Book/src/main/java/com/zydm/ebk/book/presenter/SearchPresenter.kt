package com.zydm.ebk.book.presenter

import com.zydm.base.common.Constants
import com.zydm.base.common.ParamKey
import com.zydm.base.data.bean.ListBean
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.tools.TooFastChecker
import com.zydm.base.utils.SPUtils
import com.zydm.base.utils.StringUtils
import com.zydm.base.utils.ToastUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.api.definition.RecommendApi
import com.zydm.base.ext.addSingleTop
import com.zydm.base.ext.trimToSize
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.utils.LogUtils
import com.zydm.ebk.book.presenter.view.ISearchPageView
import io.reactivex.Single
import io.reactivex.functions.BiFunction

class SearchPresenter(private val mPage: ISearchPageView) : AbsPagePresenter<ListBean<*>>(mPage) {

    companion object {
        const val LOAD_TYPE_MAIN = 1
        const val LOAD_TYPE_SUGGESTION = 2
        const val LOAD_TYPE_BOOK_LIST = 3

        private const val HISTORY_KEY = "search_keyword_history_key"
    }

    private val MAX_HISTORY_COUNT = 10;

    var mLoadedType = LOAD_TYPE_MAIN
    var mLoadingType = LOAD_TYPE_MAIN
        private set
    val mMainData: SearchMainData = SearchMainData()
    private var mKeyword = ""
    private var mSuggestionKeyword = ""

    private var mTooFastChecker = TooFastChecker(Constants.MILLIS_300)
    var mStType: String = ""

    override fun onPageCreated() {
        super.onPageCreated()
        val historySet = SPUtils.getStringSet(HISTORY_KEY)
        mMainData.mHistory.clear()
        mMainData.mHistory.addAll(historySet)
        mMainData.mHistory.trimToSize(MAX_HISTORY_COUNT)
    }

    override fun onPageDestroy() {
        super.onPageDestroy()
        if (mMainData.mHistory.isEmpty()) {
            SPUtils.remove(HISTORY_KEY)
        } else {
            SPUtils.putStringSet(HISTORY_KEY, HashSet<String>(mMainData.mHistory))
        }
    }

    override fun loadPageData(isForceUpdate: Boolean): Boolean {
        mPageComposite.clear()
        return super.loadPageData(isForceUpdate)
    }

    fun loadMain() {
        mLoadingType = LOAD_TYPE_MAIN
        if (mMainData.isLoaded()) {
            notifyShowMain()
            return
        }

        loadPageData(false)
    }

    override fun isNeedLoadPageData(): Boolean {
        return true
    }

    fun loadSuggestion(keyword: String) {
        LogUtils.d(TAG, "loadSuggestion $keyword")
        if (StringUtils.isBlank(keyword)) {
            notifyShowMain()
            return
        }

        if (mTooFastChecker.isTooFast()) {
            return
        }

        val keywordTrim = keyword.trim()
        if (keywordTrim == mKeyword) {
            return
        }
        mLoadingType = LOAD_TYPE_SUGGESTION
        mSuggestionKeyword = keywordTrim
        loadPageData(false)
    }

    fun search(keyword: String, stType: String) {
        LogUtils.d(TAG, "search $keyword")
        if (StringUtils.isBlank(keyword)) {
            ToastUtils.show(R.string.search_note)
            return
        }

        mStType = stType
        StatisHelper.onEvent().searchTypeClick(stType)

        mLoadingType = LOAD_TYPE_BOOK_LIST
        val keywordTrim = keyword.trim()
        mKeyword = keywordTrim

        mTooFastChecker.startTime()
        mPage.setKeyWord(keywordTrim)

        mMainData.mHistory.addSingleTop(keywordTrim)
        mMainData.mHistory.trimToSize(MAX_HISTORY_COUNT)
        loadPageData(false)
    }

    override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<out ListBean<*>> {
        return when (mLoadingType) {
            LOAD_TYPE_MAIN -> getMainSingle()
            LOAD_TYPE_SUGGESTION -> getSuggestionSingle(mSuggestionKeyword)
            LOAD_TYPE_BOOK_LIST -> getBookListSingle(mKeyword, isLoadMore)
            else -> throw RuntimeException()
        }
    }

    override fun onPageDataUpdated(pageData: ListBean<*>, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        mPage.showPage(pageData.list)
    }

    private fun getMainSingle(): Single<ListBean<*>> {
        val recBooksSingle = Api.Recommend().recBooks(4, RecommendApi.TYPE_SEARCH).build()
        val recWordsSingle = Api.Search().getRecWords().build()
        return Single.zip(recBooksSingle, recWordsSingle, BiFunction { t1, t2 ->
            mMainData.mRecBooks = t1.list
            mMainData.mRecWords = t2
            mMainData.toListBean()
        })
    }

    private fun getBookListSingle(keyword: String, isLoadMore: Boolean): Single<out ListBean<*>> {
        return Api.Search().books(keyword)
                .addReqParam(ParamKey.CURSOR, getCursor(isLoadMore))
                .build()
    }

    private fun getSuggestionSingle(keyword: String): Single<out ListBean<*>> {
        return Api.Search().suggestion(keyword)
                .build()
    }

    fun deleteHistory(historyWord: String) {
        if (mMainData.mHistory.remove(historyWord)) {
            notifyShowMain()
        }
    }

    fun clearHistory() {
        mMainData.mHistory.clear()
        notifyShowMain()
    }

    private fun notifyShowMain() {
        mLoadingType = LOAD_TYPE_MAIN
        mPage.showPage(mMainData.toListBean().list)
        pageData = mMainData.toListBean()
    }
}