package com.zydm.ebk.book.ui.city.item

import android.content.Context
import android.widget.ImageView
import com.youth.banner.Banner
import com.youth.banner.BannerConfig
import com.youth.banner.Transformer
import com.youth.banner.loader.ImageLoader
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.GlideUtils
import com.zydm.base.utils.ToastUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.data.bean.BannerItemBean
import com.zydm.ebk.book.data.bean.BannerListBean
import com.zydm.ebk.provider.router.BaseData
import kotlinx.android.synthetic.main.book_city_banner_layout.view.*

class BannerView : AbsItemView<BannerListBean>() {

    private lateinit var mBanner: Banner
    var mPageName: String = ""
    override fun onCreate() {
        setContentView(R.layout.book_city_banner_layout)
        initBanner()

    }

    private fun initBanner() {
        mBanner = mItemView.banner
        mBanner.setImageLoader(BannerImageLoader())
        mBanner.setBannerAnimation(Transformer.Accordion)
        mBanner.setDelayTime(2000)
        //设置指示器位置（当banner模式中有指示器时）
        mBanner.setIndicatorGravity(BannerConfig.RIGHT)
        mBanner.setOnBannerListener {

            val banner = mItemData.list[it]

            StatisHelper.onEvent().bannerClick(it, banner.linkType, banner.link, banner.subject)

            onBannerClick(banner)
        }
        //banner设置方法全部调用完毕时最后调用
    }

    private fun onBannerClick(banner: BannerItemBean) {
        when (banner.linkType) {
            BannerItemBean.LINK_TYPE_WEB -> ActivityHelper.gotoWeb(mActivity, banner.link)
            BannerItemBean.LINK_TYPE_BOOK -> ActivityHelper.gotoBookDetails(mActivity, banner.link, BaseData(mPageName))
            BannerItemBean.LINK_TYPE_READ -> ActivityHelper.gotoRead(mActivity, banner.link, banner.seqNum, BaseData(mPageName))
            else -> ToastUtils.show("暂不支持！")
        }
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        if (!isDataChanged) {
            return
        }

        val urlList = ArrayList<String>()
        for (bannerItemBean in mItemData.list) {
            urlList.add(bannerItemBean.imgUrl)
        }
        mBanner.setImages(urlList)
        mBanner.start()

    }
}

class BannerImageLoader : ImageLoader() {
    override fun displayImage(context: Context, path: Any, imageView: ImageView) {
        GlideUtils.loadImage(context, path.toString(), imageView)
    }
}