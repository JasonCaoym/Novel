package com.zydm.ebk.book.ui.search.item

import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.presenter.SearchBookEmpty

class SearchBookEmptyView: AbsItemView<SearchBookEmpty>() {

    override fun onCreate() {
        setContentView(R.layout.search_book_empty)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
    }

}
