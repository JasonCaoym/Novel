package com.zydm.ebk.book.presenter

import com.zydm.base.data.bean.ListBean
import com.zydm.base.data.tools.DataUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.data.bean.BookItemBean
import com.zydm.ebk.book.data.bean.RecWordsBean

class EntrancesData

data class CategoryGroup(val isBoy: Boolean)

class SearchMainData {
    var mRecBooks: ArrayList<BookItemBean>? = null
    var mRecWords: RecWordsBean? = null
    val mHistory = ArrayList<String>()

    fun toListBean(): ListBean<Any> {
        val listBean = ListBean<Any>()
        val list = listBean.list

        if (!DataUtils.isEmptyList(mRecBooks)) {
            list.add(SearchLabel(R.string.rec_book))
            list.add(mRecBooks!!)
        }

        if (!DataUtils.isEmptyData(mRecWords)) {
            list.add(mRecWords!!)
        }

        if (mHistory.isNotEmpty()) {
            list.add(SearchLabel(R.string.search_history, true))
            list.addAll(mHistory)
        }
        return listBean
    }

    fun isLoaded(): Boolean {
        return !DataUtils.isEmptyList(mRecBooks) || !DataUtils.isEmptyData(mRecWords)
    }
}

class SearchLabel(val labelTextRes: Int, val isShowBtn: Boolean = false)

class SearchBookEmpty()

