package com.zydm.ebk.book.data.bean

import com.zydm.base.data.bean.ListBean

class BannerItemBean {

    companion object {
        const val LINK_TYPE_WEB = 1
        const val LINK_TYPE_BOOK = 2
        const val LINK_TYPE_READ = 3
    }

    var id = ""
    var subject = ""
    var linkType = 0
    var link = ""
    var seqNum = 1
    var imgUrl = ""

    fun getBookId() = link

}

class BannerListBean : ListBean<BannerItemBean>()
