package com.zydm.ebk.book.presenter.booklist.base

import com.zydm.ebk.book.presenter.booklist.*
import com.zydm.ebk.book.presenter.view.IBookListPage
import java.lang.NullPointerException

object ListPresenterFactory {

    fun createPresenter(listPage: IBookListPage, data: Any?): AbsBookListPresenter {
        return when(data) {
            is CategoryArgs -> CategoryBookListPresenter(listPage, data.categoryId, data.subId, data.type)
            is CompleteArgs -> CompleteBookListPresenter(listPage)
            is FixedModuleArgs -> FixedModuleBookListPresenter(listPage, data.mModuleId)
            is ModuleArgs -> ModuleBookListPresenter(listPage, data.mModuleId)
            is RankArgs -> RankBookListPresenter(listPage, data.mPos)
            is NewArgs -> NewBookListPresenter(listPage)
            else -> throw NullPointerException("data is $data")
        }
    }
}