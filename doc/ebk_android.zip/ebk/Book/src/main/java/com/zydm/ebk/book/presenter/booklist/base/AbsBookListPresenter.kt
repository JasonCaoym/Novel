package com.zydm.ebk.book.presenter.booklist.base

import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.addSubListNotEmpty
import com.zydm.base.ext.mapPacking
import com.zydm.base.ext.subList1
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.utils.LogUtils
import com.zydm.base.utils.StringUtils
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.presenter.view.IBookListPage
import com.zydm.ebk.provider.ad.AdMgr
import com.zydm.ebk.provider.ad.ui.item.FeedViewAD
import io.reactivex.Single
import io.reactivex.functions.BiFunction

abstract class AbsBookListPresenter(private val mPage: IBookListPage) : AbsPagePresenter<BookListBean>(mPage) {

    var mTopAd: Any? = null
        private set

    private var mListAd = ArrayList<Any>()

    private val BOOK_ROW_COUNT = 4

    final override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<out BookListBean> {
        if (isForceUpdate && !isLoadMore) {
            destoryOldAd()
        }
        return getListDataSrc(isForceUpdate, isLoadMore)
                .zipTopAd()
                .zipListAd(if (!isLoadMore) 0 else mPage.getListSize())
    }

    private fun destoryOldAd() {
        if (mTopAd is FeedViewAD) {
            (mTopAd as FeedViewAD).mAd.destroy()
        }
        mTopAd = null
        mListAd.forEach {
            if (it is FeedViewAD) {
                it.mAd.destroy()
            }
        }
        mListAd.clear()
    }

    override fun onPageDestroy() {
        super.onPageDestroy()
        destoryOldAd()
    }

    abstract fun getListDataSrc(forceUpdate: Boolean, loadMore: Boolean): Single<out BookListBean>

    override fun onPageDataUpdated(pageData: BookListBean, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        onPageDataUpdated(pageData)
        val pageList = ArrayList<Any>()

        val topAd = mTopAd
        if (topAd != null) {
            pageList.add(topAd)
        }

        val srcList = pageData.list
        var startIndex = 0

        if (!StringUtils.isBlank(pageData.gridName)) {
            pageList.add(pageData.gridName)

            if (pageList.addSubListNotEmpty(srcList, startIndex, startIndex + BOOK_ROW_COUNT)) {
                startIndex += BOOK_ROW_COUNT
                if (pageList.addSubListNotEmpty(srcList, startIndex, startIndex + BOOK_ROW_COUNT)) {
                    startIndex += BOOK_ROW_COUNT
                }
            }
        }

        if (!StringUtils.isBlank(pageData.listName)) {
            pageList.add(pageData.listName)
        }

        val subList = srcList.subList1(startIndex, srcList.size)

        if (AdMgr.isShowAd(AdMgr.AD_SUB_LIST)) {
            val adParam = AdMgr.getAdParam(AdMgr.AD_SUB_LIST)
            val newList = ArrayList<Any>()

            val adSpace = getAdSpace()
            subList.forEachIndexed { index, bookItemBean ->
                newList.add(bookItemBean)
                if ((index + 1) % adSpace == 0) {
                    val adIndex = (index + 1) / adSpace
                    if (adIndex < mListAd.size) {
                        newList.add(mListAd[adIndex])
                    }
                }
            }
            pageList.addAll(newList)
        } else {
            pageList.addAll(subList)
        }

        mPage.showPage(pageList)
    }

    open fun onPageDataUpdated(pageData: BookListBean) {

    }

    private fun Single<out BookListBean>.zipTopAd(): Single<out BookListBean> {
        if (!AdMgr.isShowAd(AdMgr.AD_SUB_LIST_TOP)) {
            return this
        }

        val loadAdList = AdMgr.loadAdList(mPage.activity, AdMgr.AD_SUB_LIST_TOP, 1, mPage.pageName)
                .mapPacking()

        return this.zipWith(loadAdList, BiFunction { t1, t2 ->
            if (!DataUtils.isEmptyList(t2.data)) {
                mTopAd = t2.data!![0]
            }
            t1
        })
    }

    fun getAdSpace(): Int {
        var adSpace = 5
        if (AdMgr.isShowAd(AdMgr.AD_SUB_LIST)) {
            val adParam = AdMgr.getAdParam(AdMgr.AD_SUB_LIST)
            adSpace = adParam.mAdSpace
        }
        return Math.max(adSpace, 5)
    }

    private fun Single<out BookListBean>.zipListAd(curListSize: Int): Single<out BookListBean> {
        if (!AdMgr.isShowAd(AdMgr.AD_SUB_LIST)) {
            return this
        }

        val adSize = curListSize / (getAdSpace() + 1) + 2
        LogUtils.d(TAG, "curListSize: $curListSize  adSize $adSize  mListAd.size ${mListAd.size}")
        if (adSize <= mListAd.size) {
            return this
        }

        val loadAdList = AdMgr.loadAdList(mPage.activity, AdMgr.AD_SUB_LIST, 3, mPage.pageName)
                .mapPacking()

        return this.zipWith(loadAdList, BiFunction { t1, t2 ->
            if (!DataUtils.isEmptyList(t2.data)) {
                mListAd.addAll(t2.data!!)
            }
            t1
        })
    }
}