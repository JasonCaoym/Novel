package com.zydm.ebk.book.common

import android.app.Activity
import android.content.Intent
import com.alibaba.android.arouter.launcher.ARouter
import com.zydm.base.R
import com.zydm.base.data.tools.JsonUtils
import com.zydm.base.ui.BaseActivityHelper
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.ui.activity.web.WebActivity
import com.zydm.ebk.book.data.bean.CategoryBean
import com.zydm.ebk.book.ui.category.CategoryActivity
import com.zydm.ebk.book.ui.category.CategoryBookListActivity
import com.zydm.ebk.book.ui.list.BookListActivity
import com.zydm.ebk.book.ui.list.RankActivity
import com.zydm.ebk.book.ui.list.SelectedActivity
import com.zydm.ebk.book.ui.search.SearchActivity
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.provider.router.RouterPath

object ActivityHelper {
    fun gotoWeb(activity: Activity, url: String) {
        BaseActivityHelper.gotoWebActivity(activity, WebActivity.Data(url, ""))
    }

    fun gotoRead(activity: Activity, bookId: String, seqNum: Int, data: BaseData) {
        ARouter.getInstance().build(RouterPath.Read.PATH_READ)
                .withString(RouterPath.KEY_BOOK_ID, bookId)
                .withInt(RouterPath.TARGET_SEQ_NUM, seqNum)
                .withParcelable(BaseActivity.DATA_KEY, data)
                .navigation()
    }

    fun gotoRead(activity: Activity, bookId: String, data: BaseData) {
        ARouter.getInstance().build(RouterPath.Read.PATH_READ)
                .withString(RouterPath.KEY_BOOK_ID, bookId)
                .withParcelable(BaseActivity.DATA_KEY, data)
                .navigation()
    }

    fun gotoBookDetails(activity: Activity, bookId: String, data: BaseData) {
        ARouter.getInstance().build(RouterPath.Read.PATH_DETAIL)
                .withString(RouterPath.KEY_BOOK_ID, bookId)
                .withParcelable(BaseActivity.DATA_KEY, data)
                .navigation()
    }

    fun gotoBookList(activity: Activity, data: BookListProtocol) {
        val intent = Intent(activity, BookListActivity::class.java)
        intent.putExtra(BaseActivity.DATA_KEY, data)
        activity.startActivity(intent)
    }

    fun gotoCategory(activity: Activity) {
        val intent = Intent(activity, CategoryActivity::class.java)
        activity.startActivity(intent)
    }

    fun gotoRank(activity: Activity) {
        val intent = Intent(activity, RankActivity::class.java)
        activity.startActivity(intent)
    }

    fun gotoJingXuan(activity: Activity) {
        val intent = Intent(activity, SelectedActivity::class.java)
        activity.startActivity(intent)
    }

    fun gotoSearch(activity: Activity, data: BaseData) {
        val intent = Intent(activity, SearchActivity::class.java)
        intent.putExtra(BaseActivity.DATA_KEY, data)
        activity.startActivity(intent)
    }

    fun gotoCategoryBookList(activity: Activity, categoryBean: CategoryBean) {
        val intent = Intent(activity, CategoryBookListActivity::class.java)
        intent.putExtra(BaseActivity.DATA_KEY, JsonUtils.toJson(categoryBean))
        activity.startActivity(intent)
    }

    private fun startActivity(activity: Activity, intent: Intent) {
        activity.startActivity(intent)
        activity.overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }
}