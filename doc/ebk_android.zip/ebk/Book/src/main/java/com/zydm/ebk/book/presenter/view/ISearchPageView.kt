package com.zydm.ebk.book.presenter.view

import com.zydm.base.presenter.view.IPageView

interface ISearchPageView : IPageView {

    fun showPage(pageData: ArrayList<*>)

    fun setKeyWord(keyword: String)

}
