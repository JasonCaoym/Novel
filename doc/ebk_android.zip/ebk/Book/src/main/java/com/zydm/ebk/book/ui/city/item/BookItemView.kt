package com.zydm.ebk.book.ui.city.item

import android.view.View
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.loadUrl
import com.zydm.base.ext.setHtmlText
import com.zydm.base.ext.setVisible
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.StringUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.data.bean.BookItemBean
import com.zydm.ebk.book.ui.list.RankActivity
import com.zydm.ebk.provider.router.BaseData
import kotlinx.android.synthetic.main.book_item_view.view.*

class BookItemView : AbsItemView<BookItemBean>() {

    private var mIsInRank = false
    var mPageName: String = ""

    override fun onCreate() {
        setContentView(R.layout.book_item_view)
        mItemView.setOnClickListener(this)
        mIsInRank = mActivity is RankActivity
        mItemView.book_rank_pos.setVisible(mIsInRank)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.book_cover.loadUrl(mItemData.bookCover)
        mItemView.book_resume.setHtmlText(mItemData.resume)
        mItemView.book_author.setHtmlText(mItemData.author)
        mItemView.book_name.setHtmlText(mItemData.bookName)

        val categoryName = DataUtils.getItem(mItemData.category, 0)?.name ?: ""
        if (StringUtils.isBlank(categoryName)) {
            mItemView.book_category.visibility = View.GONE
        } else {
            mItemView.book_category.visibility = View.VISIBLE
            mItemView.book_category.text = categoryName
        }

        if (mIsInRank) {
            setRankPost()
        }
    }

    private fun setRankPost() {
        val rankPos = mItemView.book_rank_pos
        rankPos.text = "${mItemData.mRank + 1}"

        val textColor = if (mItemData.mRank > 2) {
            ViewUtils.getColor(R.color.standard_text_color_light_gray)
        } else {
            ViewUtils.getColor(R.color.standard_text_color_gold)
        }
        rankPos.setTextColor(textColor)
    }

    override fun onClick(view: View) {
        super.onClick(view)

        if (!StringUtils.isBlank(mItemData.mRecommendStStr)) {
            StatisHelper.onEvent().recommendClick(mItemData.mRecommendStStr)
        }

        ActivityHelper.gotoBookDetails(mActivity, mItemData.bookId, BaseData(mPageName))
    }
}
