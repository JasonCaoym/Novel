package com.zydm.ebk.book.data.api

import com.zydm.base.data.net.ApiFactory
import com.zydm.ebk.book.data.api.definition.*

object Api {

    fun Banner() = ApiFactory.getApiInstance(BannerApi::class.java)

    fun Recommend() = ApiFactory.getApiInstance(RecommendApi::class.java)

    fun Book() = ApiFactory.getApiInstance(BookApi::class.java)

    fun Search() = ApiFactory.getApiInstance(SearchApi::class.java)

    fun Rank() = ApiFactory.getApiInstance(RankApi::class.java)
}