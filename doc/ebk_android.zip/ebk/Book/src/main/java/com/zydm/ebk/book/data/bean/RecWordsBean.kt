package com.zydm.ebk.book.data.bean

import com.zydm.base.data.bean.ListBean

class RecWordsBean: ListBean<String>() {
    val total = 0
}
