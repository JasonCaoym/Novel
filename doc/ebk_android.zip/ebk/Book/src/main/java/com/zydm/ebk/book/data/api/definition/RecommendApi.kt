package com.zydm.ebk.book.data.api.definition

import com.zydm.base.data.net.*
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.data.bean.FixedModuleListBean
import com.zydm.ebk.book.data.bean.ModuleBean
import com.zydm.base.common.ParamKey

/**
 * Created by yan on 2017/3/17.
 */
@BasePath("/Api/Recommend/")
interface RecommendApi {

    companion object {
        //for recBooks
        const val TYPE_BOOKSHELF = 1
        const val TYPE_SEARCH = 2
        const val REC_BOOK_TYPE_SHELF = 1
        const val REC_BOOK_TYPE_SEARCH = 2
        const val REC_TEXT_TYPE_SHELF = 1
    }

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getModules(): DataSrcBuilder<ArrayList<ModuleBean>>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun booksByModuleId(@Param(ParamKey.MODULE_ID) moduleId: String): DataSrcBuilder<BookListBean>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun choiceness(@Param(ParamKey.IDS) ids: String): DataSrcBuilder<FixedModuleListBean>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun choicenessBooks(@Param(ParamKey.ID) id: String): DataSrcBuilder<BookListBean>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun new(): DataSrcBuilder<BookListBean>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun finish(): DataSrcBuilder<BookListBean>

    fun recBooks(@Param(ParamKey.COUNT) count: Int, @Param(ParamKey.TYPE) type: Int): DataSrcBuilder<BookListBean>
}
