package com.zydm.ebk.book.ui.search.item

import com.zydm.base.ext.setVisible
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.presenter.SearchLabel
import kotlinx.android.synthetic.main.search_label_item.view.*

class SearchLabelView: AbsItemView<SearchLabel>() {

    override fun onCreate() {
        setContentView(R.layout.search_label_item)
        mItemView.history_delete_all.setOnClickListener(this)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.title.setText(mItemData.labelTextRes)
        mItemView.history_delete_all.setVisible(mItemData.isShowBtn)
    }
}
