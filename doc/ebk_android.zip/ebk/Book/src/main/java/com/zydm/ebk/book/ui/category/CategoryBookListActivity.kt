package com.zydm.ebk.book.ui.category

import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.util.TypedValue
import android.view.View
import android.widget.TextView
import com.zydm.base.data.tools.JsonUtils
import com.zydm.base.ext.onClick
import com.zydm.base.ext.setVisible
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.tools.DelayTask
import com.zydm.base.tools.Supplier
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.utils.LogUtils
import com.zydm.base.utils.ViewUtils
import com.zydm.base.widgets.AbsFragmentPagerAdapter
import com.zydm.base.widgets.FlowLayout
import com.zydm.ebk.book.R
import com.zydm.ebk.book.data.bean.CategoryBean
import com.zydm.ebk.book.data.bean.CategorySubBean
import com.zydm.ebk.book.presenter.booklist.CategoryBookListPresenter
import com.zydm.ebk.book.presenter.booklist.base.CategoryArgs
import com.zydm.ebk.book.ui.list.BookListFragment
import com.zydm.ebk.book.ui.list.OnScrollTopListener
import kotlinx.android.synthetic.main.category_book_list_activity.*
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView

class CategoryBookListActivity: BaseActivity() {

    private val mTabTitle = arrayOf(R.string.category_hot, R.string.category_new)
    private val mTabType = arrayOf(1, 3)

    private lateinit var mCategoryBean: CategoryBean

    private lateinit var mCurSubCategory: CategorySubBean

    private var mIsShowSub = true

    private val mDTsdk =  DelayTask()

    private var mCloseByUserTime = 0L

    private val mSubIdSupplier by lazy {
        object : Supplier<String> {
            override fun get(): String {
                return mCurSubCategory.subId
            }
        }
    }

    private val mAdapter by lazy {
        object : AbsFragmentPagerAdapter(supportFragmentManager, mTabTitle.size) {
            override fun getItem(position: Int): Fragment {
                val listFragment = BookListFragment()
                listFragment.setArgs(CategoryArgs(mCategoryBean.name, mCategoryBean.id, mSubIdSupplier.get(), mTabType[position]))

                if (mIsShowSub) {
                    listFragment.mOnScrollTopListener = object : OnScrollTopListener {
                        override fun onScrollTop() {
                            if (SystemClock.elapsedRealtime() < mCloseByUserTime) {
                                return
                            }
                            LogUtils.d(TAG, "onScrollTop")
                            mDTsdk.cancel()
                            mDTsdk.doDelay(Runnable {
                                LogUtils.d(TAG, "onScrollTop sub_category_layout")
                                showSub(sub_category_layout)
                            }, 50)
                        }
                    }
                }

                return listFragment
            }
        }
    }

    override fun initActivityConfig(activityConfig: ActivityConfig) {
        super.initActivityConfig(activityConfig)
        activityConfig.isStPage = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.category_book_list_activity)
        initDataAndTitle()
        initTab()
        initViewPager()
    }

    private fun initDataAndTitle() {
        val json = intent.getStringExtra(BaseActivity.DATA_KEY)
        mCategoryBean = JsonUtils.parseJson<CategoryBean>(json, CategoryBean::class.java)
        mCurSubCategory = CategorySubBean()
        if (mCategoryBean.subList.size <= 1) {
            mIsShowSub = false
            sub_category_btn.setVisible(false)
            hideSub(sub_category_layout)
        } else {
            mIsShowSub = true
            sub_category_btn.setVisible(true)
            mCategoryBean.subList.add(0, mCurSubCategory)
            initSubCategory()
        }

        page_title.text = mCategoryBean.name
    }

    private fun initTab() {
        val commonNavigator = CommonNavigator(this)
        commonNavigator.adapter = object : CommonNavigatorAdapter() {

            override fun getCount(): Int {
                return mTabTitle.size
            }

            override fun getTitleView(p0: Context?, index: Int): IPagerTitleView {
                val titleView = SimplePagerTitleView(this@CategoryBookListActivity)
                titleView.normalColor = ViewUtils.getColor(R.color.standard_text_color_light_gray)
                titleView.setPadding(ViewUtils.dp2px(11f), 0, ViewUtils.dp2px(11f), 0)
                titleView.selectedColor = ViewUtils.getColor(R.color.standard_text_color_black)
                titleView.setText(mTabTitle[index])
                titleView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16f)
                titleView.setOnClickListener{
                    view_pager.currentItem = index
                }
                return titleView
            }

            override fun getIndicator(p0: Context?): IPagerIndicator? {
                return null
            }
        }
        magic_indicator.navigator = commonNavigator
    }

    private fun initViewPager() {
        view_pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(state: Int) {
                magic_indicator.onPageScrollStateChanged(state)
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
                magic_indicator.onPageScrolled(position, positionOffset, positionOffsetPixels)
            }

            override fun onPageSelected(position: Int) {
                magic_indicator.onPageSelected(position)
            }
        })

        view_pager.adapter = mAdapter
        view_pager.mOnDispatchTouchDownEventListener = object : MyViewPager.OnDispatchTouchDownEventListener{
            override fun onDownEvent() {
                hideSub(sub_category_layout)
            }
        }
    }

    private fun initSubCategory() {
        val layout = sub_category_layout

        sub_category_btn.onClick {
            if (layout.visibility == View.VISIBLE) {
                mCloseByUserTime = SystemClock.elapsedRealtime() + 500
                hideSub(layout)
            } else {
                showSub(layout)
            }
        }

        mCategoryBean.subList.forEach {categorySubBean ->
            val view = ViewUtils.inflateView(activity, R.layout.category_sub_item, layout) as TextView
            view.text = categorySubBean.name
            if (categorySubBean == mCurSubCategory) {
                view.setTextColor(ViewUtils.getColor(R.color.standard_text_color_red))
            }

            layout.addView(view)

            view.setOnClickListener {
                val oldIndex = mCategoryBean.subList.indexOf(mCurSubCategory)
                (layout.getChildAt(oldIndex) as TextView).setTextColor(ViewUtils.getColor(R.color.standard_text_color_gray))

                (it as TextView).setTextColor(ViewUtils.getColor(R.color.standard_text_color_red))

                mCurSubCategory = categorySubBean
                val pagePresenter = (mAdapter.curFragment as BookListFragment).mPresenter as CategoryBookListPresenter
                pagePresenter.loadBuySubId(mSubIdSupplier.get())

                StatisHelper.onEvent().classifyListClick("${mCategoryBean.name}_${mCurSubCategory.name}", ViewUtils.getString(mTabTitle[view_pager.currentItem]))
            }
        }
    }

    private fun showSub(layout: FlowLayout) {
        sub_category_btn.setImageResource(R.mipmap.icon_arrow_up_red)
        layout.setVisible(true)
    }

    private fun hideSub(layout: FlowLayout) {
        sub_category_btn.setImageResource(R.mipmap.icon_arrow_down_red)
        layout.setVisible(false)
    }
}