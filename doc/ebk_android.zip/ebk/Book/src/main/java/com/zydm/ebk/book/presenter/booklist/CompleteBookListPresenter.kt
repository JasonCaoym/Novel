package com.zydm.ebk.book.presenter.booklist

import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.data.bean.FixedModuleBean
import com.zydm.ebk.book.presenter.booklist.base.AbsBookListPresenter
import com.zydm.ebk.book.presenter.view.IBookListPage
import com.zydm.base.common.ParamKey
import io.reactivex.Single
import io.reactivex.functions.BiFunction

class CompleteBookListPresenter(val mPage: IBookListPage) : AbsBookListPresenter(mPage) {

    override fun getListDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<BookListBean> {
        val newSingle = Api.Recommend().finish()
                .addReqParam(ParamKey.CURSOR, getCursor(isLoadMore))
                .setForceUpdate(isForceUpdate)
                .build()

        if (isLoadMore) {
            return newSingle
        }

        val recommendSingle = Api.Recommend().choicenessBooks(FixedModuleBean.ID_FINISH)
                .addReqParam(ParamKey.COUNT, "8")
                .setForceUpdate(isForceUpdate)
                .build()

        return recommendSingle.zipWith(newSingle, BiFunction { t1, t2 ->
            t1.list.addAll(t2.list)
            t1.nextCursor = t2.nextCursor
            t1
        })
    }
}