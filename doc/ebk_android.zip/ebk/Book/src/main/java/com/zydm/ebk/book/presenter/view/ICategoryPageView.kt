package com.zydm.ebk.book.presenter.view

import com.zydm.base.presenter.view.IPageView

interface ICategoryPageView: IPageView {
    fun showPage(pageData: ArrayList<*>)

}
