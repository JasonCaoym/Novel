package com.zydm.ebk.book.presenter.booklist

import com.zydm.base.common.ParamKey
import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.api.definition.RankApi
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.presenter.booklist.base.AbsBookListPresenter
import com.zydm.ebk.book.presenter.view.IBookListPage
import com.zydm.ebk.book.ui.list.RankActivity
import io.reactivex.Single

class RankBookListPresenter(val mPage: IBookListPage, val mRankPos: Int) : AbsBookListPresenter(mPage) {

    override fun getListDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<BookListBean> {
        return when (mRankPos) {
            RankActivity.POS_hot -> getHotSingle(isForceUpdate, isLoadMore)
//            RankActivity.POS_finish -> getFinishSingle(isForceUpdate, isLoadMore)
            RankActivity.POS_up -> getUpSingle(isForceUpdate, isLoadMore)
            else -> Single.just(BookListBean())
        }
    }

    private fun getHotSingle(forceUpdate: Boolean, loadMore: Boolean): Single<BookListBean> {
        return Api.Rank().weekHot(RankApi.TYPE_HOT)
                .setForceUpdate(forceUpdate)
                .addReqParam(ParamKey.CURSOR, getCursor(loadMore))
                .build()
    }

    private fun getFinishSingle(forceUpdate: Boolean, loadMore: Boolean): Single<BookListBean> {
        return Api.Rank().weekHot(RankApi.TYPE_FINISH)
                .setForceUpdate(forceUpdate)
                .addReqParam(ParamKey.CURSOR, getCursor(loadMore))
                .build()
    }

    private fun getUpSingle(forceUpdate: Boolean, loadMore: Boolean): Single<BookListBean> {
        return Api.Rank().weekRise()
                .setForceUpdate(forceUpdate)
                .addReqParam(ParamKey.CURSOR, getCursor(loadMore))
                .build()
    }

    override fun onPageDataUpdated(pageData: BookListBean) {
        pageData.list.mapIndexed { index, bookItemBean ->
            bookItemBean.mRank = index
        }
    }
}