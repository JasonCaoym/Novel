package com.zydm.ebk.book.ui.city

import android.os.Bundle
import android.view.View
import com.zydm.base.ext.onClick
import com.zydm.base.ext.setVisible
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.ui.fragment.AbsPageFragment
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.ui.item.ItemListener
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.presenter.BookCityPresenter
import com.zydm.ebk.book.presenter.view.IBookCityPage
import com.zydm.ebk.book.ui.category.CategoryActivity
import com.zydm.ebk.book.ui.city.item.*
import com.zydm.ebk.provider.router.BaseData
import kotlinx.android.synthetic.main.book_city_fragment.*
import kotlinx.android.synthetic.main.title_with_search_layout.*

class BookCityFragment : AbsPageFragment(), IBookCityPage {

    private val mAdapter by lazy {
        AdapterBuilder()
                .putItemClass(BannerView::class.java, mBannerItemsListener)
                .putItemClass(EntrancesView::class.java)
                .putItemClass(FixedModuleView::class.java)
                .putItemClass(ModuleItemView::class.java)
                .putItemClass(BookItemView::class.java, mBookItemsListener)
                .putItemClass(BooksView::class.java, mBookListener)
                .builderListAdapter(activity!!)
    }

    private val mPresenter by lazy {
        BookCityPresenter(this)
    }

    private val mBookItemsListener by lazy {
        object : ItemListener<BookItemView> {
            override fun onCreate(itemView: BookItemView) {
                super.onCreate(itemView)
                itemView.mPageName = ViewUtils.getString(R.string.book_city)
            }
        }
    }

    private val mBookListener by lazy {
        object : ItemListener<BooksView> {
            override fun onCreate(itemView: BooksView) {
                super.onCreate(itemView)
                itemView.mPageName = ViewUtils.getString(R.string.book_city)
            }
        }
    }

    private val mBannerItemsListener by lazy {
        object : ItemListener<BannerView> {
            override fun onCreate(itemView: BannerView) {
                super.onCreate(itemView)
                itemView.mPageName = ViewUtils.getString(R.string.book_city)
            }
        }
    }

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<*> {
        setContentView(R.layout.book_city_fragment)
        return mPresenter
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity is CategoryActivity) {
            toolbar_back.setVisible(true)
            toolbar_back.setOnClickListener(activity as CategoryActivity)
            title_text.setVisible(false)
        } else {
            toolbar_back.setVisible(false)
            title_text.setVisible(true)
            title_text.setText(R.string.book_city)
        }
        list_view.adapter = mAdapter
        search_text.onClick {
            ActivityHelper.gotoSearch(activity!!, BaseData(pageName))
        }
    }

    override fun showPage(pageData: ArrayList<*>) {
        mAdapter.setData(pageData)
    }

    override fun getPageName(): String {
        return ViewUtils.getString(R.string.book_city)
    }
}
