package com.zydm.ebk.book.presenter

import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.api.definition.BookApi
import com.zydm.base.ext.addSubListNotEmpty
import com.zydm.ebk.book.presenter.view.ICategoryPageView
import io.reactivex.Single
import io.reactivex.functions.BiFunction

class CategoryPresenter(private val mPage: ICategoryPageView): AbsPagePresenter<ArrayList<*>>(mPage) {

    override fun getPageDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<ArrayList<*>> {
        val boySingle = Api.Book().category(BookApi.PARENT_ID_BOY)
            .setForceUpdate(true)
            .build()

        val girlSingle = Api.Book().category(BookApi.PARENT_ID_GIRL)
            .setForceUpdate(true)
            .build()

        return Single.zip(boySingle, girlSingle, BiFunction { t1, t2 ->
            val list = ArrayList<Any>()
            if (!t1.isEmpty()) {
                list.add(CategoryGroup(true))
                val boyCategoryList = t1.list
                for (i in 0..(boyCategoryList.size/2)) {
                    val startIndex = i*2
                    list.addSubListNotEmpty(boyCategoryList, startIndex, startIndex+2)
                }
            }

            if (!t2.isEmpty()) {
                list.add(CategoryGroup(false))
                val girlCategoryList = t2.list
                for (i in 0..(girlCategoryList.size/2)) {
                    val startIndex = i*2
                    list.addSubListNotEmpty(girlCategoryList, startIndex, startIndex+2)
                }
            }
            list
        })
    }

    override fun onPageDataUpdated(pageData: ArrayList<*>, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        mPage.showPage(pageData)
    }
}