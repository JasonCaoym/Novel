package com.zydm.ebk.book.ui.category

import android.os.Bundle
import android.view.View
import com.zydm.base.ext.onClick
import com.zydm.base.ext.setVisible
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.ui.fragment.AbsPageFragment
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.presenter.CategoryPresenter
import com.zydm.ebk.book.presenter.view.ICategoryPageView
import com.zydm.ebk.book.ui.category.item.BiCategoryView
import com.zydm.ebk.book.ui.category.item.CategoryGroupView
import com.zydm.ebk.provider.router.BaseData
import kotlinx.android.synthetic.main.book_city_fragment.*
import kotlinx.android.synthetic.main.title_with_search_layout.*

class CategoryFragment: AbsPageFragment(), ICategoryPageView {

    private val mPresenter by lazy {
        CategoryPresenter(this)
    }

    private val mAdapter by lazy {
        AdapterBuilder()
            .putItemClass(CategoryGroupView::class.java)
            .putItemClass(BiCategoryView::class.java)
            .builderListAdapter(activity!!)
    }

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<*> {
        setContentView(R.layout.category_fragment)
        return mPresenter
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (activity is CategoryActivity) {
            toolbar_back.setVisible(true)
            toolbar_back.setOnClickListener(activity as CategoryActivity)
            title_text.setVisible(false)
        } else {
            toolbar_back.setVisible(false)
            title_text.setVisible(true)
            title_text.setText(R.string.category)
        }

        list_view.adapter = mAdapter
        search_text.onClick {
            ActivityHelper.gotoSearch(activity!!, BaseData(pageName))
        }
    }

    override fun getPageName(): String {
        return ViewUtils.getString(R.string.category)
    }

    override fun showPage(pageData: ArrayList<*>) {
        mAdapter.setData(pageData)
    }

    override fun initFragmentConfig(fragmentConfig: FragmentConfig) {
        super.initFragmentConfig(fragmentConfig)
        fragmentConfig.isStPage = false
    }
}
