package com.zydm.ebk.book.data.api.definition

import com.zydm.base.common.ParamKey
import com.zydm.base.data.bean.ListBean
import com.zydm.base.data.net.BasePath
import com.zydm.base.data.net.DataSrcBuilder
import com.zydm.base.data.net.DomainType
import com.zydm.base.data.net.Param
import com.zydm.ebk.book.data.bean.BookItemBean
import com.zydm.ebk.book.data.bean.RecWordsBean

/**
 * Created by yan on 2017/3/17.
 */
@BasePath(value = "/Api/Search/", domainType = DomainType.SEARCH)
interface SearchApi {

    fun books(@Param(ParamKey.KEYWORD) keyword: String): DataSrcBuilder<ListBean<BookItemBean>>

    fun suggestion(@Param(ParamKey.KEYWORD) keyword: String): DataSrcBuilder<ListBean<String>>

    fun getRecWords(): DataSrcBuilder<RecWordsBean>
}
