package com.zydm.ebk.book.presenter.view

import com.zydm.base.presenter.view.IPageView

interface IBookCityPage: IPageView {
    fun showPage(pageData: ArrayList<*>)
}