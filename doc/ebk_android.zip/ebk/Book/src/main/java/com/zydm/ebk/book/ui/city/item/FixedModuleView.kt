package com.zydm.ebk.book.ui.city.item

import android.view.View
import android.widget.ImageView
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.loadUrl
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.common.BookListProtocol
import com.zydm.ebk.book.data.bean.FixedModuleListBean
import kotlinx.android.synthetic.main.book_city_fixed_module_vertical.view.*

class FixedModuleView : AbsItemView<FixedModuleListBean>() {



    private val mIds = arrayOf(
        R.id.fixed_module_1,
        R.id.fixed_module_2,
        R.id.fixed_module_3
    )

    override fun onCreate() {
        setContentView(R.layout.book_city_fixed_modules_layout)
        mIds.forEachIndexed { index, id ->
            val view = mItemView.findViewById<View>(id)
            view.setOnClickListener(this)
            view.setTag(index)
        }
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mIds.forEachIndexed { index, id ->
            val view = mItemView.findViewById<View>(id)
            val data = DataUtils.getItem(mItemData.list, index)
            if (data != null) {
                view.visibility = View.VISIBLE
                view.icon1.loadUrl(data.coverList[0])
                view.icon2.loadUrl(data.coverList[1])
                val img3 = view.findViewById<ImageView>(R.id.icon3)
                if (img3 != null) {
                    img3.loadUrl(data.coverList[2])
                }
                view.resume.text = data.resume
                view.title.text = data.name
            } else {
                view.visibility = View.INVISIBLE
            }
        }

    }

    override fun onClick(view: View) {
        super.onClick(view)
        val bean = mItemData.list[view.tag as Int]
        ActivityHelper.gotoBookList(mActivity, BookListProtocol(BookListProtocol.TYPE_FIXED_MODULE, bean.id, bean.name))
    }
}
