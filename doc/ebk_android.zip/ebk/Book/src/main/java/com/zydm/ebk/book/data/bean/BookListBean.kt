package com.zydm.ebk.book.data.bean

import com.zydm.base.data.bean.ListBean

class BookListBean : ListBean<BookItemBean>() {

    var gridName = ""
    var listName = ""
}
