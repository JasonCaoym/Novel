package com.zydm.ebk.book.data.api.definition

import com.zydm.base.data.net.*
import com.zydm.ebk.book.data.bean.BannerListBean
import com.zydm.base.common.ParamKey

/**
 * Created by yan on 2017/3/17.
 */
@BasePath("/Api/Banner/")
interface BannerApi {

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun getList(@Param(ParamKey.MAX) max: Int = 0): DataSrcBuilder<BannerListBean>
}
