package com.zydm.ebk.book.data.bean

import com.zydm.base.data.bean.ListBean

class FixedModuleBean {

    companion object {
        const val ID_MALE = "1"    //  男生精选
        const val ID_FEMALE = "2"  //  女生精选
        const val ID_FINISH = "3"  //  完结
        const val ID_NEW = "4"     //   新书
    }

    var id = ""
    var name = ""
    var resume = ""
    var coverList = ArrayList<String>()
}

class FixedModuleListBean : ListBean<FixedModuleBean>()