package com.zydm.ebk.book.ui.city.item

import android.view.View
import android.widget.TextView
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.ViewUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.common.BookListProtocol
import com.zydm.ebk.book.data.bean.FixedModuleBean
import com.zydm.ebk.book.presenter.EntrancesData
import kotlinx.android.synthetic.main.book_city_entrances_layout.view.*

class EntrancesView: AbsItemView<EntrancesData>() {

    override fun onCreate() {
        setContentView(R.layout.book_city_entrances_layout)
        mItemView.entrances_category.setOnClickListener(this)
        mItemView.entrances_complete.setOnClickListener(this)
        mItemView.entrances_rank.setOnClickListener(this)
        mItemView.entrances_select.setOnClickListener(this)
        mItemView.entrances_new.setOnClickListener(this)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {

    }

    override fun onClick(view: View) {
        super.onClick(view)

        if (view is TextView) {
            StatisHelper.onEvent().quickClick(view.text.toString())
        }

        when(view.id) {
            R.id.entrances_category -> ActivityHelper.gotoCategory(mActivity)
            R.id.entrances_complete -> ActivityHelper.gotoBookList(mActivity, BookListProtocol(BookListProtocol.TYPE_FINISH, FixedModuleBean.ID_FINISH, ViewUtils.getString(R.string.entrances_complete)))
            R.id.entrances_rank -> ActivityHelper.gotoRank(mActivity)
            R.id.entrances_select -> ActivityHelper.gotoJingXuan(mActivity)
            R.id.entrances_new -> ActivityHelper.gotoBookList(mActivity, BookListProtocol(BookListProtocol.TYPE_NEW, FixedModuleBean.ID_NEW, ViewUtils.getString(R.string.entrances_new)))
        }
    }
}
