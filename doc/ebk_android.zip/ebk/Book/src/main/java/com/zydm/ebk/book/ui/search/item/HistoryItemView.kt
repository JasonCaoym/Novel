package com.zydm.ebk.book.ui.search.item

import android.view.View
import com.zydm.base.ext.setHtmlText
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import kotlinx.android.synthetic.main.search_history_item.view.*

class HistoryItemView : AbsItemView<String>() {

    lateinit var mDeleteBtn: View
        private set

    override fun onCreate() {
        setContentView(R.layout.search_history_item)
        mDeleteBtn = mItemView.history_delete
        mDeleteBtn.setOnClickListener(this)
        mItemView.root_layout.setOnClickListener(this)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.history_keyword.setHtmlText(mItemData)
    }

    fun isHistory() = mDeleteBtn.visibility == View.VISIBLE
}
