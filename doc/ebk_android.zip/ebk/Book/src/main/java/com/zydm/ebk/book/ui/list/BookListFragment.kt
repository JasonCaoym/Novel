package com.zydm.ebk.book.ui.list

import android.os.Bundle
import android.view.View
import android.widget.AbsListView
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.base.ui.fragment.AbsPageFragment
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.ui.item.ItemListener
import com.zydm.base.utils.LogUtils
import com.zydm.base.widgets.refreshview.PullableListView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.presenter.booklist.base.AbsBookListPresenter
import com.zydm.ebk.book.presenter.booklist.base.BaseArgs
import com.zydm.ebk.book.presenter.booklist.base.ListPresenterFactory
import com.zydm.ebk.book.presenter.view.IBookListPage
import com.zydm.ebk.book.ui.city.item.BookItemView
import com.zydm.ebk.book.ui.city.item.BooksView
import com.zydm.ebk.book.ui.list.item.TextItemView
import com.zydm.ebk.provider.ad.putAdItemClass
import kotlinx.android.synthetic.main.book_city_fragment.*

class BookListFragment : AbsPageFragment(), IBookListPage {

    var mOnScrollTopListener: OnScrollTopListener? = null

    private val mAdapter by lazy {
        AdapterBuilder()
                .putItemClass(BookItemView::class.java, mBookItemsListener)
                .putItemClass(BooksView::class.java, mBookListener)
                .putItemClass(TextItemView::class.java)
                .putAdItemClass()
                .builderListAdapter(activity!!)
    }

    private val mBookItemsListener by lazy {
        object : ItemListener<BookItemView> {
            override fun onCreate(itemView: BookItemView) {
                super.onCreate(itemView)
                itemView.mPageName = pageName
            }
        }
    }

    private val mBookListener by lazy {
        object : ItemListener<BooksView> {
            override fun onCreate(itemView: BooksView) {
                super.onCreate(itemView)
                itemView.mPageName = pageName
            }
        }
    }

    lateinit var mPresenter: AbsBookListPresenter
    private lateinit var mPageName: String

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<*> {
        setContentView(R.layout.book_list_fragment)
        mPresenter = createPresenter()
        return mPresenter
    }

    private fun createPresenter(): AbsBookListPresenter {
        val args = getArgs()
        mPageName = args?.pageName?:""
        return ListPresenterFactory.createPresenter(this, args)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        list_view.adapter = mAdapter
        list_view.setOnScrollListener(object : AbsListView.OnScrollListener{
            override fun onScroll(p0: AbsListView?, p1: Int, p2: Int, p3: Int) {
                if (isVisibleToUser && list_view is PullableListView && list_view.isReadyForPullDown) {
                    mOnScrollTopListener?.onScrollTop()
                    LogUtils.d(TAG, "onScroll ${this@BookListFragment}")
                }
            }

            override fun onScrollStateChanged(p0: AbsListView?, p1: Int) {
            }
        })
    }

    override fun getPageName(): String {
        return mPageName
    }

    override fun showPage(pageData: ArrayList<*>) {
        mAdapter.setData(pageData)
    }

    override fun showEmpty() {
        val mTopAd = mPresenter.mTopAd
        if (mTopAd != null) {
            val pageList = ArrayList<Any>()
            pageList.add(mTopAd)
            mAdapter.setData(pageList)
        } else {
            super.showEmpty()
        }

    }

    override fun getListSize(): Int {
        return mAdapter.count
    }

    fun setArgs(args: BaseArgs) {
        val bundle = Bundle()
        bundle.putParcelable(BaseActivity.DATA_KEY, args)
        arguments = bundle
    }

    fun getArgs(): BaseArgs? {
        return arguments?.getParcelable(BaseActivity.DATA_KEY)
    }
}

interface OnScrollTopListener {
    fun onScrollTop()
}
