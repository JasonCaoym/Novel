package com.zydm.ebk.book.ui.list

import android.os.Bundle
import com.zydm.base.ui.activity.BaseActivity
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.BookListProtocol
import com.zydm.ebk.book.presenter.booklist.base.*
import kotlinx.android.synthetic.main.book_list_activity.*

class BookListActivity: BaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.book_list_activity)

        var listFragment = supportFragmentManager
                .findFragmentById(R.id.content_frame)

        if (listFragment !is BookListFragment) {
            listFragment = BookListFragment()
            listFragment.setArgs(createPresenter(page_title.text.toString())!!)
            val transaction = supportFragmentManager.beginTransaction()
            transaction.add(R.id.content_frame, listFragment)
            transaction.commit()
        }
    }

    private fun createPresenter(pageName: String): BaseArgs? {
        val bookListProtocol = intent.getParcelableExtra<BookListProtocol>(BaseActivity.DATA_KEY)
        page_title.text = bookListProtocol.moduleName

        val moduleId = bookListProtocol.type
        return when(moduleId) {
            BookListProtocol.TYPE_FINISH -> CompleteArgs(pageName)
            BookListProtocol.TYPE_NEW -> NewArgs(pageName)
            BookListProtocol.TYPE_MODULE -> ModuleArgs(pageName, bookListProtocol.moduleId)
            BookListProtocol.TYPE_FIXED_MODULE -> FixedModuleArgs(pageName, bookListProtocol.moduleId)
            else -> null
        }
    }

    override fun initActivityConfig(activityConfig: ActivityConfig) {
        super.initActivityConfig(activityConfig)
        activityConfig.isStPage = false
    }

}