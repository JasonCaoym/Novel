package com.zydm.ebk.book.presenter.booklist.base

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
open class BaseArgs(open var pageName: String): Parcelable

@Parcelize
data class CategoryArgs(override var pageName: String,
                        val categoryId: String,
                        val subId: String,
                        val type: Int ): BaseArgs(pageName)

@Parcelize
data class CompleteArgs(override var pageName: String): BaseArgs(pageName)

@Parcelize
data class FixedModuleArgs(override var pageName: String,
                           val mModuleId: String): BaseArgs(pageName)

@Parcelize
data class ModuleArgs(override var pageName: String,
                      val mModuleId: String): BaseArgs(pageName)

@Parcelize
data class RankArgs(override var pageName: String,
                      val mPos: Int): BaseArgs(pageName)


@Parcelize
data class NewArgs(override var pageName: String): BaseArgs(pageName)

