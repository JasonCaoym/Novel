package com.zydm.ebk.book.common

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BookListProtocol(val type: Int, val moduleId: String = "", val moduleName: String = "") : Parcelable {
    companion object {
        const val TYPE_NEW = 1
        const val TYPE_FINISH = 2
        const val TYPE_FIXED_MODULE = 3
        const val TYPE_MODULE = 4
    }


}