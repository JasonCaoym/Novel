package com.zydm.ebk.book.presenter.booklist

import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.presenter.booklist.base.AbsBookListPresenter
import com.zydm.ebk.book.presenter.view.IBookListPage
import com.zydm.base.common.ParamKey
import io.reactivex.Single

class FixedModuleBookListPresenter(val mPage: IBookListPage, val mModuleId: String): AbsBookListPresenter(mPage) {

    override fun getListDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<BookListBean> {
        return Api.Recommend().choicenessBooks(mModuleId)
                .addReqParam(ParamKey.COUNT, if (isLoadMore) "10" else "20")
                .addReqParam(ParamKey.CURSOR, getCursor(isLoadMore))
                .setForceUpdate(isForceUpdate)
                .build()
    }
}