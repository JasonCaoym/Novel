package com.zydm.ebk.book.ui.city.item

import android.view.View
import com.zydm.base.ext.setVisible
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.common.BookListProtocol
import com.zydm.ebk.book.data.bean.ModuleBean
import kotlinx.android.synthetic.main.book_city_module_item_view.view.*

class ModuleItemView: AbsItemView<ModuleBean>() {
    override fun onCreate() {
        setContentView(R.layout.book_city_module_item_view)
        mItemView.show_more.setOnClickListener(this)
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.module_title.text = mItemData.name
        if (mItemData.mIsFirst) {
            mItemView.div2.setVisible(true)
            mItemView.div6.setVisible(false)
        } else {
            mItemView.div2.setVisible(false)
            mItemView.div6.setVisible(true)
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        ActivityHelper.gotoBookList(mActivity, BookListProtocol(BookListProtocol.TYPE_MODULE, mItemData.moduleId, mItemData.name))
    }
}