package com.zydm.ebk.book.ui.search.item

import com.zydm.base.ext.setVisible
import com.zydm.base.ui.item.AbsItemView
import com.zydm.ebk.book.R
import com.zydm.ebk.book.data.bean.RecWordsBean
import kotlinx.android.synthetic.main.search_rec_word_item_view.view.*
import kotlinx.android.synthetic.main.search_rec_words_view.view.*

class RecWordsView : AbsItemView<RecWordsBean>() {
    override fun onCreate() {
        setContentView(R.layout.search_rec_words_view)
        val gridView = mItemView.words_layout
        for (i in 0 until gridView.childCount) {
            gridView.getChildAt(i).setOnClickListener(this)
        }
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        mItemView.title.setText(R.string.hot_search)
        val gridView = mItemView.words_layout
        for (i in 0 until gridView.childCount) {
            val wordView = gridView.getChildAt(i)
            if (i < mItemData.list.size) {
                wordView.setVisible(true)
                val keyword = mItemData.list[i]
                wordView.tag = keyword

                wordView.index.text = "${i + 1}"
                wordView.index.background.level = i
                wordView.word.text = keyword
            } else {
                wordView.setVisible(false)
            }
        }
    }
}
