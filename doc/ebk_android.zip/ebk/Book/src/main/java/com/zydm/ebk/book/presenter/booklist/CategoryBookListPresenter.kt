package com.zydm.ebk.book.presenter.booklist

import com.zydm.base.common.ParamKey
import com.zydm.base.rx.LoadException
import com.zydm.base.tools.Supplier
import com.zydm.ebk.book.data.api.Api
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.presenter.booklist.base.AbsBookListPresenter
import com.zydm.ebk.book.presenter.view.IBookListPage
import io.reactivex.Single

class CategoryBookListPresenter(val mPage: IBookListPage,
                                private val mCategoryId: String,
                                private var mSubId: String,
                                private val mType: Int): AbsBookListPresenter(mPage) {

    var mCurSubId: String = ""

    override fun getListDataSrc(isForceUpdate: Boolean, isLoadMore: Boolean): Single<BookListBean> {
        return Api.Book().booksByCategory(mCategoryId, mSubId, mType)
                .addReqParam(ParamKey.CURSOR, getCursor(isLoadMore))
                .setForceUpdate(isForceUpdate)
                .build()
                .doOnSuccess {
                    mCurSubId = mSubId
                }
    }

    fun loadBuySubId(subId: String) {
        mSubId = subId
        loadPageData(false)
    }

    override fun isNeedLoadPageData(): Boolean {
        return super.isNeedLoadPageData() || mCurSubId != mSubId
    }

    override fun onPageDataUpdated(pageData: BookListBean, isByForceUpdate: Boolean, isLoadMore: Boolean) {
        super.onPageDataUpdated(pageData, isByForceUpdate, isLoadMore)
        mCurSubId = mSubId
    }

    override fun interceptLoadPageDataError(error: LoadException) {
        super.interceptLoadPageDataError(error)
        mCurSubId = mSubId
    }
}