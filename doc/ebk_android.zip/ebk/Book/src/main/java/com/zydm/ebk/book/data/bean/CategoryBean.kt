package com.zydm.ebk.book.data.bean

class CategoryBean {

    var id: String = ""
    var name: String = ""
    var subList = ArrayList<CategorySubBean>()
}

class CategorySubBean {
    var subId: String = "0"
    var name: String = "全部"
}
