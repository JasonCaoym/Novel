package com.zydm.ebk.book.ui.search

import android.os.Bundle
import android.text.Editable
import android.view.View
import android.view.inputmethod.EditorInfo
import com.alibaba.android.arouter.facade.annotation.Route
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.onClick
import com.zydm.base.ext.setVisible
import com.zydm.base.presenter.AbsPagePresenter
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.activity.AbsPageActivity
import com.zydm.base.ui.item.AdapterBuilder
import com.zydm.base.ui.item.ItemListener
import com.zydm.base.utils.KeyboardUtils
import com.zydm.base.utils.StringUtils
import com.zydm.base.widgets.DefaultTextWatcher
import com.zydm.base.widgets.refreshview.PullToRefreshLayout
import com.zydm.ebk.book.R
import com.zydm.ebk.book.presenter.SearchBookEmpty
import com.zydm.ebk.book.presenter.SearchPresenter
import com.zydm.ebk.book.presenter.view.ISearchPageView
import com.zydm.ebk.book.ui.city.item.BookItemView
import com.zydm.ebk.book.ui.city.item.BooksView
import com.zydm.ebk.book.ui.search.item.HistoryItemView
import com.zydm.ebk.book.ui.search.item.RecWordsView
import com.zydm.ebk.book.ui.search.item.SearchBookEmptyView
import com.zydm.ebk.book.ui.search.item.SearchLabelView
import com.zydm.ebk.provider.router.BaseData
import com.zydm.ebk.provider.router.RouterPath
import com.zydm.statistics.motong.MtStConst
import kotlinx.android.synthetic.main.search_activity.*

@Route(path = RouterPath.Book.PATH_SEARCH)
class SearchActivity : AbsPageActivity(), ISearchPageView {

    private var mSetKeyWord: String = ""

    private val mPresenter by lazy {
        SearchPresenter(this)
    }

    private val mRecWordsItemListener by lazy {
        object : ItemListener<RecWordsView> {
            override fun onCreate(itemView: RecWordsView) {
                super.onCreate(itemView)
            }

            override fun onClick(itemView: RecWordsView, view: View) {
                if (view.tag is String) {
                    mPresenter.search(view.tag as String, "热门搜索")
                }
            }
        }
    }

    private val mHistoryItemListener by lazy {
        object : ItemListener<HistoryItemView> {

            override fun onSetDate(itemView: HistoryItemView) {
                super.onSetDate(itemView)
                itemView.mDeleteBtn.setVisible(mPresenter.mLoadingType == SearchPresenter.LOAD_TYPE_MAIN)
            }

            override fun onClick(itemView: HistoryItemView, view: View) {
                val keyword = StringUtils.htmlToString(itemView.mItemData)
                when (view.id) {
                    R.id.root_layout -> mPresenter.search(keyword, if (itemView.isHistory()) "历史搜索" else MtStConst.VALUE_SEARCH_BY_THINK)
                    R.id.history_delete -> mPresenter.deleteHistory(keyword)
                }
            }
        }
    }

    private val mHistoryDeleteAllListener by lazy {
        object : ItemListener<SearchLabelView> {
            override fun onCreate(itemView: SearchLabelView) {
                super.onCreate(itemView)
            }

            override fun onClick(itemView: SearchLabelView, view: View) {
                when (view.id) {
                    R.id.history_delete_all -> mPresenter.clearHistory()
                }
            }
        }
    }

    private val mAdapter by lazy {
        AdapterBuilder()
                .putItemClass(BooksView::class.java)
                .putItemClass(RecWordsView::class.java, mRecWordsItemListener)
                .putItemClass(SearchLabelView::class.java, mHistoryDeleteAllListener)
                .putItemClass(HistoryItemView::class.java, mHistoryItemListener)
                .putItemClass(BookItemView::class.java, mBookItemsListener)
                .putItemClass(SearchBookEmptyView::class.java)
                .builderListAdapter(activity)
    }

    private val mBookItemsListener by lazy {
        object : ItemListener<BookItemView> {
            override fun onCreate(itemView: BookItemView) {
                super.onCreate(itemView)
                itemView.mPageName = mPresenter.mStType
            }
        }
    }

    override fun onCreatePage(savedInstanceState: Bundle?): AbsPagePresenter<*> {
        setContentView(R.layout.search_activity)
        initView()
        initEditText()
        initListView()

        StatisHelper.onEvent().search(intent.getParcelableExtra<BaseData>(DATA_KEY).from)
        return mPresenter
    }

    private fun initView() {
        cancel_btn.onClick {
            cancelSearch()
        }
    }

    private fun cancelSearch() {
        search_edit.setText("")
        KeyboardUtils.hideKeyboard(this, search_edit)
        search_edit.clearFocus()
        mPresenter.loadMain()
    }

    private fun initListView() {
        list_view.adapter = mAdapter
        list_view.setOnTouchListener { _, _ ->
            KeyboardUtils.hideKeyboard(this, search_edit)
            false
        }
    }

    private fun initEditText() {
        search_edit.imeOptions = EditorInfo.IME_ACTION_SEARCH;
        search_edit.setSingleLine()

        search_edit.addTextChangedListener(object : DefaultTextWatcher() {
            override fun afterTextChanged(s: Editable?) {
                val keyword = s.toString().trim()
                cancel_btn.setVisible(!StringUtils.isBlank(keyword))
                if (mSetKeyWord == keyword) {
                    mSetKeyWord = ""
                    return
                }
                mPresenter.loadSuggestion(keyword)
            }
        })

        search_edit.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_FLAG_NO_ENTER_ACTION) {
                mPresenter.search(search_edit.text.toString(), MtStConst.VALUE_SEARCH_BY_KEYWORD)
            }
            true
        }
    }

    override fun onInitPullLayout(pullLayout: PullToRefreshLayout?) {
        super.onInitPullLayout(pullLayout)
        pullLayout?.setCanPullDown(false)
    }

    override fun showPage(pageData: ArrayList<*>) {
        mAdapter.setData(pageData)
    }

    override fun setKeyWord(keyword: String) {
        mSetKeyWord = keyword
        search_edit.setText(keyword)
    }

    override fun showEmpty() {
        if (mPresenter.mLoadingType == SearchPresenter.LOAD_TYPE_BOOK_LIST) {
            val emptyList = ArrayList<Any>()
            emptyList.add(SearchBookEmpty())
            if (!DataUtils.isEmptyData(mPresenter.mMainData.mRecBooks)) {
                emptyList.add(mPresenter.mMainData.mRecBooks!!)
            }
            showPage(emptyList)
        }
    }

    override fun onBackPressed() {
        if (mPresenter.mLoadingType != SearchPresenter.LOAD_TYPE_MAIN) {
            cancelSearch()
            return
        }
        super.onBackPressed()
    }
}
