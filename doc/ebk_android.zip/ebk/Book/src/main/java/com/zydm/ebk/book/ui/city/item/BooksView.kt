package com.zydm.ebk.book.ui.city.item

import android.view.View
import com.zydm.base.data.tools.DataUtils
import com.zydm.base.ext.loadUrl
import com.zydm.base.statistics.umeng.StatisHelper
import com.zydm.base.ui.item.AbsItemView
import com.zydm.base.utils.StringUtils
import com.zydm.ebk.book.R
import com.zydm.ebk.book.common.ActivityHelper
import com.zydm.ebk.book.data.bean.BookItemBean
import com.zydm.ebk.provider.router.BaseData
import kotlinx.android.synthetic.main.books_horizontal_layout_item.view.*

class BooksView : AbsItemView<ArrayList<BookItemBean>>() {

    var mPageName: String = ""
    private val ids = arrayOf(
            R.id.book_1,
            R.id.book_2,
            R.id.book_3,
            R.id.book_4
    )

    override fun onCreate() {
        setContentView(R.layout.books_horizontal_layout)
        ids.forEachIndexed { index, id ->
            val view = mItemView.findViewById<View>(id)
            view.setOnClickListener(this)
            view.setTag(index)
        }
    }

    override fun onSetData(isFirstSetData: Boolean, isPosChanged: Boolean, isDataChanged: Boolean) {
        ids.forEachIndexed { index, id ->
            val view = mItemView.findViewById<View>(id)
            val data = DataUtils.getItem(mItemData, index)
            if (data != null) {
                view.visibility = View.VISIBLE
                view.book_cover.loadUrl(data.bookCover)
                view.book_name.text = data.bookName
                view.isEnabled = true
            } else {
                view.visibility = View.INVISIBLE
                view.isEnabled = false
            }
        }
    }

    override fun onClick(view: View) {
        super.onClick(view)
        val bookItemBean = mItemData[view.tag as Int]

        if (!StringUtils.isBlank(bookItemBean.mRecommendStStr)) {
            StatisHelper.onEvent().recommendClick(bookItemBean.mRecommendStStr)
        }

        ActivityHelper.gotoBookDetails(mActivity, bookItemBean.bookId, BaseData(mPageName))
    }
}
