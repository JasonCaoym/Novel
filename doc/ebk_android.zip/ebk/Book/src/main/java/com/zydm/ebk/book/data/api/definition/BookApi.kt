package com.zydm.ebk.book.data.api.definition

import com.zydm.base.data.bean.ListBean
import com.zydm.base.data.net.*
import com.zydm.ebk.book.data.bean.BookListBean
import com.zydm.ebk.book.data.bean.CategoryBean
import com.zydm.base.common.ParamKey

@BasePath("/Api/Book/")
interface BookApi {

    companion object {
        const val PARENT_ID_BOY = 1
        const val PARENT_ID_GIRL = 2

        const val TYPE_HOT = 1
        const val TYPE_FINISH = 2
        const val TYPE_NEW = 3
    }

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun category(@Param(ParamKey.PARENT_ID) parentId: Int = 0): DataSrcBuilder<ListBean<CategoryBean>>

    @ApiConfigs(expTime = ExpTime.ONE_HOUR)
    fun booksByCategory(@Param(ParamKey.CATEGORY_ID) categoryId: String,
                        @Param(ParamKey.SUB_ID) subId: String,
                        @Param(ParamKey.TYPE) type: Int): DataSrcBuilder<BookListBean>
}
