package com.zymh.ebk.read.dao;

import android.os.Looper;
import android.support.annotation.NonNull;

import com.zydm.base.common.BaseApplication;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;
import io.reactivex.ObservableOnSubscribe;

public class BookShelfHelper {
    private static volatile BookShelfHelper sInstance;
    private static DaoSession daoSession;
    private static BookShelfBeanDao shelfBookBeanDao;
    private ArrayList<ShelfDaoObserver> mObservers = new ArrayList<>();

    public static BookShelfHelper getsInstance() {
        if (sInstance == null) {
            synchronized (BookShelfHelper.class) {
                if (sInstance == null) {
                    sInstance = new BookShelfHelper();
                    daoSession = DaoDbHelper.getInstance().getSession();
                    shelfBookBeanDao = daoSession.getBookShelfBeanDao();
                }
            }
        }
        return sInstance;
    }

    public void addObserver(ShelfDaoObserver observer) {
        if (!mObservers.contains(observer)) {
            mObservers.add(observer);
        }
    }

    public void removeObserver(ShelfDaoObserver observer) {
        mObservers.remove(observer);
    }

    public void saveBook(BookShelfBean bookBean) {
        shelfBookBeanDao.insertOrReplace(bookBean);
        ShelfEvent event = new ShelfEvent();
        event.mType = ShelfEvent.TYPE_ADD;
        event.mChangeList.add(bookBean);
        notifyObserver(event);
    }

    public void saveBooks(List<BookShelfBean> bookBeans) {
        shelfBookBeanDao.insertOrReplaceInTx(bookBeans);
        ShelfEvent event = new ShelfEvent();
        event.mType = ShelfEvent.TYPE_ADD;
        event.mChangeList.addAll(bookBeans);
        notifyObserver(event);
    }

    private void notifyObserver(final ShelfEvent event) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            excute(event);
        } else {
            BaseApplication.handler.post(new Runnable() {
                @Override
                public void run() {
                    excute(event);
                }
            });
        }
    }

    private void excute(ShelfEvent event) {
        if (mObservers == null) {
            return;
        }
        for (ShelfDaoObserver observer : mObservers) {
            observer.onShelfChange(event);
        }
    }

    public void saveBookWithAsync(final BookShelfBean bookBean) {
        daoSession.startAsyncSession().runInTx(new Runnable() {
            @Override
            public void run() {
                shelfBookBeanDao.insertOrReplace(bookBean);
                ShelfEvent event = new ShelfEvent();
                event.mType = ShelfEvent.TYPE_ADD;
                event.mChangeList.add(bookBean);
                notifyObserver(event);
            }
        });
    }

    public void saveBooksWithAsync(final List<BookShelfBean> bookBeans) {
        daoSession.startAsyncSession().runInTx(new Runnable() {
            @Override
            public void run() {
                shelfBookBeanDao.insertOrReplaceInTx(bookBeans);
                ShelfEvent event = new ShelfEvent();
                event.mType = ShelfEvent.TYPE_ADD;
                event.mChangeList.addAll(bookBeans);
                notifyObserver(event);
            }
        });
    }

    public Observable<String> removeBookInRx(final BookShelfBean bookBean) {
        return Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> e) throws Exception {
                shelfBookBeanDao.delete(bookBean);
                e.onNext("删除成功");
                ShelfEvent event = new ShelfEvent();
                event.mType = ShelfEvent.TYPE_REMOVE;
                event.mChangeList.add(bookBean);
                notifyObserver(event);
            }
        });
    }

    public Observable<String> removeBooksInRx(final List<BookShelfBean> bookBeans, final boolean notify) {
        return Observable.create(new ObservableOnSubscribe<String>() {
            @Override
            public void subscribe(ObservableEmitter<String> e) throws Exception {
                String[] keys = new String[bookBeans.size()];
                for (int i = 0; i < bookBeans.size(); i++) {
                    keys[i] = shelfBookBeanDao.getKey(bookBeans.get(i));
                }
                shelfBookBeanDao.deleteByKeyInTx(keys);
                if (notify) {
                    ShelfEvent event = new ShelfEvent();
                    event.mType = ShelfEvent.TYPE_REMOVE;
                    event.mChangeList.addAll(bookBeans);
                    notifyObserver(event);
                }
                e.onNext("删除成功");
            }
        });
    }

    public BookShelfBean findBookById(String bookId) {
        return shelfBookBeanDao.queryBuilder().where(BookShelfBeanDao.Properties.BookId.eq(bookId)).unique();
    }

    public void updateBook(BookShelfBean shelfBean) {
        shelfBookBeanDao.update(shelfBean);
    }

    public List<BookShelfBean> findAllBooks() {
        return shelfBookBeanDao
                .queryBuilder()
                .orderDesc(BookShelfBeanDao.Properties.AddTime)
                .list();
    }

    public interface ShelfDaoObserver {
        void onShelfChange(@NonNull ShelfEvent event);
    }
}
