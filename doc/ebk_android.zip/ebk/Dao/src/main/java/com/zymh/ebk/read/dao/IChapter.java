package com.zymh.ebk.read.dao;

public interface IChapter {
    String getTitle();
    boolean isSelect();
    boolean isRead();
}
