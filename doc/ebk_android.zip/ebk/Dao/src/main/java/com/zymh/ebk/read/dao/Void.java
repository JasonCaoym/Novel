package com.zymh.ebk.read.dao;

public final class Void {
}
