package com.zymh.ebk.read.dao;

import android.os.Parcel;
import android.os.Parcelable;

import com.zydm.base.data.base.IIdGetter;

import org.greenrobot.greendao.annotation.Entity;
import org.greenrobot.greendao.annotation.Id;
import org.greenrobot.greendao.annotation.Generated;
import org.greenrobot.greendao.annotation.Transient;

@Entity
public class BookShelfBean implements IIdGetter, Parcelable {

    @Id
    public String bookId;
    public String bookName = "";
    public String bookCover = "";
    public String resume = "";
    public int chapterCount = 0;
    public long wordCount = 0;
    public boolean isFinish = false;
    public long updateTime = 0;
    public long currTime = 0;
    public long addTime = 0;
    public String author = "";

    @Transient
    public boolean mIsUpdate;

    @Transient
    public boolean mIsSelect;

    @Transient
    public boolean mIsInShelf;

    @Transient
    public boolean mIsEditMode;

    protected BookShelfBean(Parcel in) {
        bookId = in.readString();
        bookName = in.readString();
        bookCover = in.readString();
        resume = in.readString();
        chapterCount = in.readInt();
        wordCount = in.readLong();
        isFinish = in.readByte() != 0;
        updateTime = in.readLong();
        currTime = in.readLong();
        addTime = in.readLong();
        author = in.readString();
        mIsUpdate = in.readByte() != 0;
        mIsSelect = in.readByte() != 0;
        mIsInShelf = in.readByte() != 0;
        mIsEditMode = in.readByte() != 0;
    }

    @Generated(hash = 1143830554)
    public BookShelfBean(String bookId, String bookName, String bookCover, String resume,
            int chapterCount, long wordCount, boolean isFinish, long updateTime,
            long currTime, long addTime, String author) {
        this.bookId = bookId;
        this.bookName = bookName;
        this.bookCover = bookCover;
        this.resume = resume;
        this.chapterCount = chapterCount;
        this.wordCount = wordCount;
        this.isFinish = isFinish;
        this.updateTime = updateTime;
        this.currTime = currTime;
        this.addTime = addTime;
        this.author = author;
    }

    @Generated(hash = 1462228839)
    public BookShelfBean() {
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(bookId);
        dest.writeString(bookName);
        dest.writeString(bookCover);
        dest.writeString(resume);
        dest.writeInt(chapterCount);
        dest.writeLong(wordCount);
        dest.writeByte((byte) (isFinish ? 1 : 0));
        dest.writeLong(updateTime);
        dest.writeLong(currTime);
        dest.writeLong(addTime);
        dest.writeString(author);
        dest.writeByte((byte) (mIsUpdate ? 1 : 0));
        dest.writeByte((byte) (mIsSelect ? 1 : 0));
        dest.writeByte((byte) (mIsInShelf ? 1 : 0));
        dest.writeByte((byte) (mIsEditMode ? 1 : 0));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<BookShelfBean> CREATOR = new Creator<BookShelfBean>() {
        @Override
        public BookShelfBean createFromParcel(Parcel in) {
            return new BookShelfBean(in);
        }

        @Override
        public BookShelfBean[] newArray(int size) {
            return new BookShelfBean[size];
        }
    };

    @Override
    public String getId() {
        return bookId;
    }

    public String getBookId() {
        return this.bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return this.bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getBookCover() {
        return this.bookCover;
    }

    public void setBookCover(String bookCover) {
        this.bookCover = bookCover;
    }

    public String getResume() {
        return this.resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }

    public int getChapterCount() {
        return this.chapterCount;
    }

    public void setChapterCount(int chapterCount) {
        this.chapterCount = chapterCount;
    }

    public long getWordCount() {
        return this.wordCount;
    }

    public void setWordCount(long wordCount) {
        this.wordCount = wordCount;
    }

    public boolean getIsFinish() {
        return this.isFinish;
    }

    public void setIsFinish(boolean isFinish) {
        this.isFinish = isFinish;
    }

    public long getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(long updateTime) {
        this.updateTime = updateTime;
    }

    public long getCurrTime() {
        return this.currTime;
    }

    public void setCurrTime(long currTime) {
        this.currTime = currTime;
    }

    public long getAddTime() {
        return this.addTime;
    }

    public void setAddTime(long addTime) {
        this.addTime = addTime;
    }

    public String getAuthor() {
        return this.author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }
}
