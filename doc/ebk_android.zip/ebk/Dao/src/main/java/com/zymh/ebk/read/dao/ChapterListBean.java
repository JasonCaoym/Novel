package com.zymh.ebk.read.dao;


import com.zydm.base.data.bean.ListBean;

public class ChapterListBean extends ListBean<ChapterBean> {
    public BookRecordBean mOwnBook;
    public int mGroupIndex;
}
